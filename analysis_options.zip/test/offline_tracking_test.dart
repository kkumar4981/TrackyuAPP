import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fieldforce_hrms/trackyu/api.dart';
import 'package:fieldforce_hrms/trackyu/controller.dart';
import 'trackyu_integration_test.dart' show Adapter, MemoryVault, reply;

void main() {
  test(
    'offline refresh preserves duty and encrypted session cache; a punch waits for reconciliation',
    () async {
      var offline = false;
      var gps = 0;
      final vault = MemoryVault();
      final token =
          'x.${base64UrlEncode(utf8.encode(jsonEncode({'exp': DateTime.now().add(const Duration(hours: 2)).millisecondsSinceEpoch ~/ 1000})))}.x';
      vault.value = jsonEncode({
        'server': 'https://qa.example/api',
        'token': token,
        'user': {'SM_USER_ID': 'QA'},
      });
      final dio = Dio()
        ..httpClientAdapter = Adapter((r) {
          if (offline) {
            throw DioException(
              requestOptions: r,
              type: DioExceptionType.connectionError,
            );
          }
          if (r.path == 'AttendanceProfile/mine') {
            return reply({'mode': 'Field'});
          }
          if (r.path == 'FieldAttendance/state') {
            return reply({
              'workDate': '2026-11-07',
              'serverTimeUtc': DateTime.now().toUtc().toIso8601String(),
              'attendance': {
                'id': 77,
                'punchInUtc': DateTime.now()
                    .toUtc()
                    .subtract(const Duration(hours: 1))
                    .toIso8601String(),
                'punchOutUtc': null,
              },
            });
          }
          if (r.path == 'FieldAttendance/punch-out') {
            return reply({
              'id': 77,
              'punchInUtc': DateTime.now()
                  .toUtc()
                  .subtract(const Duration(hours: 1))
                  .toIso8601String(),
              'punchOutUtc': DateTime.now().toUtc().toIso8601String(),
            });
          }
          throw StateError('Unexpected call: ${r.path}');
        });
      TrackyuController controller() => TrackyuController(
        TrackyuApi(
          'https://qa.example/api',
          client: dio,
          deviceIdentity: () async => {'deviceId': 'qa-offline-test-phone'},
        ),
        vault: vault,
        locate: () async {
          gps++;
          return {'latitude': 28.6139, 'longitude': 77.2090, 'accuracyMeters': 10.0, 'capturedAtUtc': DateTime.now().toUtc().toIso8601String()};
        },
      );
      final first = controller();
      await first.initialize();
      expect(first.onDuty, isTrue);
      expect(first.offline, isFalse);
      offline = true;
      await expectLater(first.refresh(), throwsA(isA<ApiFailure>()));
      expect(first.loggedIn, isTrue);
      expect(first.onDuty, isTrue);
      expect(first.stateKnown, isTrue);
      expect(first.offline, isTrue);
      await first.punch();
      expect(gps, 1);
      expect(first.onDuty, isFalse);
      expect(first.pendingPunches.length, 1);
      final reopened = controller();
      await reopened.initialize();
      expect(reopened.loggedIn, isTrue);
      expect(reopened.onDuty, isFalse);
      expect(reopened.offline, isTrue);
      expect(reopened.employeeId, 'QA');
      offline = false;
      await reopened.refresh();
      expect(reopened.offline, isFalse);
      expect(reopened.onDuty, isFalse);
      first.dispose();
      reopened.dispose();
    },
  );

  test(
    'day change or cutoff detects offline and auto punches out',
    () async {
      final vault = MemoryVault();
      final token =
          'x.${base64UrlEncode(utf8.encode(jsonEncode({'exp': DateTime.now().add(const Duration(hours: 24)).millisecondsSinceEpoch ~/ 1000})))}.x';
      // Yesterday's punch
      final yesterdayUtc = DateTime.now().toUtc().subtract(const Duration(days: 1, hours: 2));
      vault.value = jsonEncode({
        'server': 'https://qa.example/api',
        'token': token,
        'user': {'SM_USER_ID': 'QA_DAY_CHANGE'},
        'attendanceCache': {
          'isField': true,
          'workDate': '2026-11-01',
          'attendance': {
            'id': 99,
            'punchInUtc': yesterdayUtc.toIso8601String(),
            'punchOutUtc': null,
          },
        },
      });

      final dio = Dio()..httpClientAdapter = Adapter((r) => throw DioException(requestOptions: r, type: DioExceptionType.connectionError));
      final c = TrackyuController(
        TrackyuApi('https://qa.example/api', client: dio, deviceIdentity: () async => {'deviceId': 'test-phone'}),
        vault: vault,
        locate: () async => {'latitude': 28.5, 'longitude': 77.1, 'accuracyMeters': 5.0, 'capturedAtUtc': DateTime.now().toUtc().toIso8601String()},
      );

      await c.initialize();
      expect(c.offline, isTrue);
      // Because workDate was in the past and day changed, initialize triggers checkDayChangeAndCutoff
      expect(c.onDuty, isFalse);
      expect(c.attendance?['punchOutUtc'], isNotNull);
      expect(c.attendance?['autoPunchOut'], isTrue);
      expect(c.pendingPunches.any((p) => p['out'] == true), isTrue);
      c.dispose();
    },
  );

  test(
    'signOut while on duty auto records offline punch-out and preserves pending queue',
    () async {
      final vault = MemoryVault();
      final token =
          'x.${base64UrlEncode(utf8.encode(jsonEncode({'exp': DateTime.now().add(const Duration(hours: 4)).millisecondsSinceEpoch ~/ 1000})))}.x';
      vault.value = jsonEncode({
        'server': 'https://qa.example/api',
        'token': token,
        'user': {'SM_USER_ID': 'QA_LOGOUT'},
        'attendanceCache': {
          'isField': true,
          'workDate': DateTime.now().toLocal().toIso8601String().split('T').first,
          'attendance': {
            'id': 105,
            'punchInUtc': DateTime.now().toUtc().subtract(const Duration(minutes: 30)).toIso8601String(),
            'punchOutUtc': null,
          },
        },
      });

      final dio = Dio()..httpClientAdapter = Adapter((r) => throw DioException(requestOptions: r, type: DioExceptionType.connectionError));
      final c = TrackyuController(
        TrackyuApi('https://qa.example/api', client: dio, deviceIdentity: () async => {'deviceId': 'test-phone'}),
        vault: vault,
        locate: () async => {'latitude': 28.5, 'longitude': 77.1, 'accuracyMeters': 5.0, 'capturedAtUtc': DateTime.now().toUtc().toIso8601String()},
      );

      await c.initialize();
      expect(c.onDuty, isTrue);
      await c.signOut(autoPunchOut: true);
      expect(c.loggedIn, isFalse);
      // Pending punches must be preserved in vault
      expect(vault.pendingPunches, isNotNull);
      expect(vault.pendingPunches!.contains('"out":true'), isTrue);
      c.dispose();
    },
  );
}
