package com.fieldforce.fieldforce_hrms
import android.app.Instrumentation
import android.os.Bundle
import org.json.JSONObject
import java.time.Instant
import java.util.UUID
import java.security.KeyStore

/** Runs against a dedicated disposable database and key; never changes employee tracking. */
class TrackingInstrumentation: Instrumentation(){
 override fun onCreate(arguments:Bundle?){super.onCreate(arguments);start()}
 override fun onStart(){
  val name="qa_tracking_${UUID.randomUUID()}.db";val alias="qa_trackyu_${UUID.randomUUID()}";var db:TrackingStore?=null
  val result=Bundle();var resultCode=-1
  try{
   val user="QA_QUEUE_ONLY";val now=System.currentTimeMillis()
   fun point(offset:Long)=JSONObject().put("id",UUID.randomUUID().toString()).put("mode","Field").put("attendanceId",1).put("capturedAtUtc",Instant.ofEpochMilli(now+offset).toString()).put("latitude",19.07612345).put("longitude",72.87771234).put("accuracyMeters",5)
   val first=point(-60000);val second=point(-30000);db=TrackingStore(targetContext,name,alias)
   db.saveConfig(JSONObject().put("trackingKey","qa-secret-not-plaintext").put("userId",user))
   db.append(user,second);db.append(user,first);db.append(user,first)
   check(db.pending(user)==2){"Duplicate location IDs must not grow the queue"}
   check(db.batch(user).first().getString("id")==first.getString("id")){"Queue must upload original capture order"}
   check(db.pending("ANOTHER_USER")==0){"Queue must isolate users"}
   db.readableDatabase.rawQuery("SELECT payload FROM samples",null).use{cursor->while(cursor.moveToNext())check(!cursor.getString(0).contains("latitude")){"GPS payload must be encrypted"}}
   check(!targetContext.getSharedPreferences(name+".state",0).getString("config","")!!.contains("qa-secret")){"Tracking authorization must be encrypted"}
   db.close();db=TrackingStore(targetContext,name,alias)
   check(db.pending(user)==2){"Network failure / process restart must retain unacknowledged fixes"}
   check(db.config().getString("trackingKey")=="qa-secret-not-plaintext"){"Keystore configuration must survive reopen"}
   db.acknowledge(user,first.getString("id"),false);db.acknowledge(user,first.getString("id"),false)
   check(db.pending(user)==1){"Acknowledgement must be idempotent"}
   check(db.route(user,now-120000,now).size==2){"Acknowledged trail must remain available for offline viewing"}
   db.acknowledge(user,second.getString("id"),true)
   check(db.pending(user)==0&&db.route(user,now-120000,now).size==2){"Rejected fixes must remain available in the phone route"}
   val old=point(-35*86400000L);db.append(user,old);db.prune(now)
   check(db.pending(user)==1&&db.route(user,now-36*86400000L,now).size==3){"Pending locations must never expire during sync"}
   db.acknowledge(user,old.getString("id"),false)
   val scope="https://qa.example/api|QA";val opId=UUID.randomUUID().toString();val key="day:2026-11-09"
   val secondKey="day:2026-11-10"
   db.localWrite(scope,key,JSONObject().put("report",JSONObject().put("date","2026-11-09")))
   db.localWrite(scope,secondKey,JSONObject().put("report",JSONObject().put("date","2026-11-10")))
   check(db.routeSummary(scope,key)!!.getJSONObject("report").getString("date")=="2026-11-09"){"First restored date must remain independently readable"}
   check(db.routeSummary(scope,secondKey)!!.getJSONObject("report").getString("date")=="2026-11-10"){"Second restored date must not replace the first"}
   val apiA="https://one.example/api|SHARED";val apiB="https://two.example/api|SHARED"
   db.append(apiA,point(-500));db.append(apiB,point(-400));db.append(apiA,point(0))
   check(db.route(apiA,now-1000,now).size==1){"API scope and exclusive day end must isolate samples"}
   check(db.route(apiB,now-1000,now).size==1){"Shared employee ID cannot combine two APIs"}
   val op=JSONObject().put("id",opId).put("route","FieldAttendance/punch-in").put("body",JSONObject()).put("recordKey",key).put("localId",123)
   val day=JSONObject().put("attendance",JSONObject().put("id",123).put("localId",123).put("punchOutUtc",JSONObject.NULL))
   db.localCommit(scope,key,day,op)
   check(db.localRead(scope,key)!=null&&db.localNext(scope)?.getString("id")==opId){"Activity and outbox must commit together"}
   check(db.localNext("different-account")==null){"Outbox must isolate workspaces and employees"}
   val changed=JSONObject().put("attendance",JSONObject().put("id",999))
   try{db.localCommit(scope,key,changed,op);error("Expected duplicate commit to fail")}catch(_:android.database.sqlite.SQLiteConstraintException){}
   check(db.localRead(scope,key)!!.getJSONObject("attendance").getLong("id")==123L){"Failed outbox insert must roll back visible record"}
   db.localError(scope,opId,"Needs review",true)
   check(db.localNext(scope)==null&&db.localSyncState(scope).getInt("blocked")==1&&db.localRead(scope,key)!=null){"Rejected operations must be retained and visible"}
   db.localError(scope,opId,"Retry",false)
   db.localAck(scope,op,JSONObject().put("id",456))
   check(db.localResult(scope,opId)!!.getLong("id")==456L&&db.localRead(scope,key)!!.getJSONObject("attendance").getLong("id")==456L){"Receipt must update the local projection atomically"}
   val temporary=point(-1000).put("attendanceId",123);db.remapAttendance(scope,"Field",123,456);db.append(scope,temporary)
   check(db.batch(scope).single().getLong("attendanceId")==456L){"Late GPS callbacks must resolve temporary attendance IDs"}
   db.acknowledge(scope,temporary.getString("id"),false)
   // Exercise the real native HTTP transport against a local disposable server.
   val outgoing=point(-1000)
   val unused=java.net.ServerSocket(0);val port=unused.localPort;unused.close()
   val uploadOwner="http://127.0.0.1:$port/api|"+user;db.append(uploadOwner,outgoing)
   db.saveConfig(JSONObject().put("baseUrl","http://127.0.0.1:$port/api").put("userId",user).put("trackingKey","qa-write-only-grant-12345678901234567890").put("deviceId","qa-isolated-test-phone").put("mode","Field").put("attendanceId",1).put("active",false))
   check(!TrackingRuntime.sync(targetContext,db)&&db.pending(uploadOwner)==1){"Failed HTTP upload must preserve queue"}
   val server=java.net.ServerSocket(port);server.soTimeout=10000
   val failure=java.util.concurrent.atomic.AtomicReference<Throwable?>(null)
   val receiver=Thread {
    try{server.accept().use {socket->
      socket.soTimeout=10000;val input=socket.getInputStream().bufferedReader();var length=0;var keySeen=false
      while(true){val line=input.readLine()?:break;if(line.isEmpty())break;if(line.startsWith("Content-Length:",true))length=line.substringAfter(":").trim().toInt();if(line.startsWith("X-Tracking-Key:",true))keySeen=line.contains("qa-write-only-grant-12345678901234567890")}
      val chars=CharArray(length);var read=0;while(read<length){val count=input.read(chars,read,length-read);check(count>0);read+=count}
      val body=JSONObject(String(chars));check(keySeen&&body.getJSONArray("samples").getJSONObject(0).getString("capturedAtUtc")==outgoing.getString("capturedAtUtc")){"Transport must keep original capture time and scoped authorization"}
      val response=JSONObject().put("success",true).put("data",JSONObject().put("serverTimeUtc",Instant.now().toString()).put("acknowledgements",org.json.JSONArray().put(JSONObject().put("id",outgoing.getString("id")).put("disposition","accepted"))))
      val bytes=response.toString().toByteArray();socket.getOutputStream().write(("HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: ${bytes.size}\r\nConnection: close\r\n\r\n").toByteArray()+bytes)
    }}catch(error:Throwable){failure.set(error)}finally{server.close()}
   };receiver.start();val uploaded=TrackingRuntime.sync(targetContext,db);receiver.join(12000);failure.get()?.let{throw it};check(uploaded){"Successful native upload must acknowledge the queue: "+db.state().optString("lastError")+"; pending="+db.pending(uploadOwner)};check(db.pending(uploadOwner)==0){"Only server-acknowledged points may leave the queue"}
   // Exercise the actual activity outbox, dependency substitution and a 503 retry.
   val actionServer=java.net.ServerSocket(0);actionServer.soTimeout=10000
   val base="http://127.0.0.1:${actionServer.localPort}/api";val actionScope=base+"|"+user
   db.localWrite("system","activeAuth",JSONObject().put("scope",actionScope).put("baseUrl",base).put("userId",user).put("deviceId","qa-device").put("token","qa-not-a-real-token"))
   val inId=UUID.randomUUID().toString();val outId=UUID.randomUUID().toString()
   val actionDay=JSONObject().put("attendance",JSONObject().put("id",77).put("localId",77).put("punchInUtc",Instant.now().minusSeconds(120).toString()).put("punchOutUtc",Instant.now().toString()))
   db.localCommit(actionScope,key,actionDay,JSONObject().put("id",inId).put("route","FieldAttendance/punch-in").put("body",JSONObject()).put("localId",77).put("recordKey",key))
   val dependency=JSONObject().put("attendanceId",JSONObject().put("operationId",inId).put("field","id"))
   db.localCommit(actionScope,key,actionDay,JSONObject().put("id",outId).put("route","FieldAttendance/punch-out").put("body",JSONObject().put("attendanceId",77)).put("refs",dependency).put("localId",77).put("recordKey",key))
   val actionFailure=java.util.concurrent.atomic.AtomicReference<Throwable?>(null)
   val actionReceiver=Thread {
    try {repeat(3){attempt->actionServer.accept().use {socket->
      socket.soTimeout=10000;val input=socket.getInputStream().bufferedReader();var length=0;var operation=""
      while(true){val line=input.readLine()?:break;if(line.isEmpty())break;if(line.startsWith("Content-Length:",true))length=line.substringAfter(":").trim().toInt();if(line.startsWith("X-Operation-ID:",true))operation=line.substringAfter(":").trim()}
      val chars=CharArray(length);var read=0;while(read<length){val count=input.read(chars,read,length-read);check(count>0);read+=count}
      val body=JSONObject(String(chars));check(operation==if(attempt==0)inId else outId){"Retry must preserve operation ID"}
      if(attempt>0)check(body.getLong("attendanceId")==901L){"Punch-out must resolve the server attendance ID"}
      val status=if(attempt==1)503 else 200
      val envelope=JSONObject().put("success",status==200).put("data",JSONObject().put("id",901))
      val bytes=envelope.toString().toByteArray();socket.getOutputStream().write(("HTTP/1.1 $status Test\r\nContent-Type: application/json\r\nContent-Length: ${bytes.size}\r\nConnection: close\r\n\r\n").toByteArray()+bytes)
    }}}catch(error:Throwable){actionFailure.set(error)}finally{actionServer.close()}
   };actionReceiver.start()
   check(!LocalWorkspaceSync.drain(targetContext,db)){"503 must leave the activity pending"}
   check(db.localResult(actionScope,inId)!=null&&db.localSyncState(actionScope).getInt("pending")==1){"Earlier receipt must survive a later upload failure"}
   check(db.localRead(actionScope,key)!!.getJSONObject("attendance").getLong("id")==901L){"Optimistic phone attendance must retain the server mapping"}
   check(LocalWorkspaceSync.drain(targetContext,db)){"Retry must complete the pending outbox"}
   actionReceiver.join(12000);actionFailure.get()?.let{throw it}
   result.putString("stream","PASS: encrypted durable queue, restart retention, capture ordering, duplicate-safe acknowledgements, user isolation, unbounded pending retention, atomic activity/outbox, rejected item retention, dependency ID remapping, failed HTTP retention, successful native HTTP acknowledgement, ordered activity outbox, server ID substitution and stable-ID retry after 503.")
  }catch(error:Throwable){resultCode=0;result.putString("stream","FAIL: "+error.javaClass.simpleName+": "+error.message)}
  finally{try{db?.close();targetContext.deleteDatabase(name);targetContext.getSharedPreferences(name+".state",0).edit().clear().commit();KeyStore.getInstance("AndroidKeyStore").apply{load(null);deleteEntry(alias)}}catch(_:Exception){resultCode=0;result.putString("stream","FAIL: isolated test cleanup failed")}}
  finish(resultCode,result)
 }
}
