package com.fieldforce.fieldforce_hrms

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.Network
import android.os.*
import android.provider.Settings
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability
import com.google.android.gms.location.*
import org.json.JSONObject
import java.time.Instant
import java.util.UUID
import java.util.concurrent.Executors
import kotlin.math.max

class DutyLocationService: Service(), LocationListener {
    private val handler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private val uploadQueued = java.util.concurrent.atomic.AtomicBoolean(false)
    private var fused: FusedLocationProviderClient? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var fallback = false
    private var lastElapsed = 0L
    private var lastCaptured = 0L
    private var lastCoarse = 0L
    private var running = false
    private var freshPending = false

    private val callback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            for (location in result.locations) accept(location, "fused")
        }
    }

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) { upload() }
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            try {
                if (TrackingRuntime.checkDutyCutoff(this@DutyLocationService)) return
                if (!TrackingRuntime.fine(this@DutyLocationService)) {
                    state("Location permission removed")
                    stopSelf()
                    return
                }
                if (SystemClock.elapsedRealtime() - lastElapsed > 45000) {
                    fallback()
                    freshFix()
                }
                upload()
                notification()
            } catch (_: Exception) {
                state("Waiting for accurate GPS")
            }
            handler.postDelayed(this, 30000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val hasFine = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
        val hasCoarse = checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
        if (hasFine || hasCoarse) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    startForeground(417, buildInitialNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
                } else {
                    startForeground(417, buildInitialNotification())
                }
            } catch (_: Exception) {}
        }
        try {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "trackyu:location_service")
            wakeLock?.setReferenceCounted(false)
            wakeLock?.acquire(24 * 60 * 60 * 1000L)
        } catch (_: Exception) {}
    }

    private fun buildInitialNotification(): Notification {
        val intent = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, "trackyu_duty")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("Trackyu location tracking")
            .setContentText("Location service active")
            .setContentIntent(intent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            val hasFine = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
            val hasCoarse = checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
            if (!hasFine && !hasCoarse) {
                state("Open the app and allow precise background location")
                stopSelf()
                return START_NOT_STICKY
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(417, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
            } else {
                startForeground(417, buildNotification())
            }
            if (!TrackingRuntime.store(this).config().optBoolean("active")) {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            if (!running) {
                running = true
                TrackingRuntime.store(this).updateState {
                    it.put("running", true)
                    it.put("status", "Waiting for accurate GPS")
                }
                startLocations()
                try {
                    (getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager).registerDefaultNetworkCallback(networkCallback)
                } catch (_: Exception) {}
                handler.post(tick)
            }
            if (intent?.getBooleanExtra("freshFix", false) == true) {
                fallback()
                freshFix()
            }
        } catch (_: Exception) {
            state("Open the app and allow precise background location")
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    private fun createChannel() {
        val channel = NotificationChannel("trackyu_duty", "Attendance location tracking", NotificationManager.IMPORTANCE_DEFAULT)
        channel.description = "Maintains continuous GPS and route recording while punched in"
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val intent = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val state = try { TrackingRuntime.status(this) } catch (_: Exception) { JSONObject() }
        val text = if (!TrackingRuntime.gps(this)) "GPS is off - turn it on to record your route" else "${state.optInt("pendingCount")} locations pending sync. Tracking while punched in."
        return Notification.Builder(this, "trackyu_duty")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("Trackyu location tracking")
            .setContentText(text)
            .setContentIntent(intent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun notification() {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(417, buildNotification())
    }

    private fun state(message: String) {
        try {
            TrackingRuntime.store(this).updateState {
                it.put("status", message.take(64))
                it.put("lastError", message)
            }
        } catch (_: Exception) {}
    }

    @Suppress("MissingPermission")
    private fun startLocations() {
        if (!TrackingRuntime.fine(this)) throw SecurityException()
        val cfg = TrackingRuntime.store(this).config()
        val intervalSec = cfg.optLong("intervalSeconds", 60L).coerceIn(10L, 600L)
        val distanceMeters = cfg.optDouble("distanceFilterMeters", 30.0).toFloat().coerceIn(3f, 500f)
        val intervalMillis = intervalSec * 1000L

        val manager = getSystemService(LOCATION_SERVICE) as LocationManager
        try {
            if (manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, intervalMillis, distanceMeters, this, Looper.getMainLooper())
            }
        } catch (_: Exception) {}
        try {
            if (manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                manager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, intervalMillis * 2, distanceMeters, this, Looper.getMainLooper())
            }
        } catch (_: Exception) {}
        if (GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(this) == ConnectionResult.SUCCESS) {
            try {
                fused = LocationServices.getFusedLocationProviderClient(this)
                val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, intervalMillis)
                    .setMinUpdateIntervalMillis((intervalMillis / 2).coerceAtLeast(3000L))
                    .setMaxUpdateDelayMillis(intervalMillis * 2)
                    .setMinUpdateDistanceMeters(distanceMeters)
                    .setWaitForAccurateLocation(false)
                    .build()
                fused!!.requestLocationUpdates(request, callback, Looper.getMainLooper()).addOnFailureListener { fallback() }
            } catch (_: Exception) {
                fallback()
            }
        } else {
            fallback()
        }
    }

    @Suppress("MissingPermission")
    private fun freshFix() {
        if (freshPending) return
        freshPending = true
        try {
            fused?.getCurrentLocation(
                CurrentLocationRequest.Builder()
                    .setPriority(Priority.PRIORITY_HIGH_ACCURACY)
                    .setMaxUpdateAgeMillis(5000)
                    .setDurationMillis(10000)
                    .build(),
                com.google.android.gms.tasks.CancellationTokenSource().token
            )?.addOnSuccessListener { location ->
                if (location != null) accept(location, "fused")
            }?.addOnCompleteListener { freshPending = false }

            val manager = getSystemService(LOCATION_SERVICE) as LocationManager
            for (provider in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
                try {
                    val last = manager.getLastKnownLocation(provider)
                    if (last != null && Math.abs(System.currentTimeMillis() - last.time) < 60000) {
                        accept(last, provider)
                    }
                } catch (_: Exception) {}
            }
        } catch (_: Exception) {
            freshPending = false
        }
    }

    @Suppress("MissingPermission")
    private fun fallback() {
        if (fallback) return
        fallback = true
        val manager = getSystemService(LOCATION_SERVICE) as LocationManager
        for (provider in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
            try {
                if (manager.isProviderEnabled(provider)) {
                    manager.requestLocationUpdates(provider, 10000L, 0f, this, Looper.getMainLooper())
                }
            } catch (_: Exception) {
                state("Enable precise location and GPS")
            }
        }
        if (!TrackingRuntime.gps(this)) {
            fallback = false
            state("GPS is off")
        }
    }

    override fun onLocationChanged(location: Location) { accept(location, location.provider ?: "gps") }
    override fun onProviderEnabled(provider: String) { fallback = false; fallback() }
    override fun onProviderDisabled(provider: String) { state("GPS provider unavailable") }
    @Deprecated("Android legacy callback") override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}

    private fun accept(location: Location, provider: String) {
        if (!running) return
        try {
            val db = TrackingRuntime.store(this)
            val cfg = db.config()
            if (!cfg.optBoolean("active")) return

            val mocked = if (Build.VERSION.SDK_INT >= 31) location.isMock else location.isFromMockProvider
            val maxAcc = cfg.optDouble("maxAccuracyMeters", 50.0).coerceIn(10.0, 500.0)
            if (mocked || !location.hasAccuracy() || !location.latitude.isFinite() || !location.longitude.isFinite() || location.accuracy < 0 || location.accuracy > maxAcc) {
                db.updateState {
                    it.put("rejectedCount", it.optInt("rejectedCount") + 1)
                    it.put("status", if (mocked) "Mock location rejected" else if (location.accuracy > maxAcc) "GPS accuracy ${location.accuracy.toInt()}m above limit" else "Waiting for a fresh GPS fix")
                }
                return
            }

            val elapsed = SystemClock.elapsedRealtime()
            val ageMs = if (location.elapsedRealtimeNanos > 0) {
                elapsed - location.elapsedRealtimeNanos / 1000000
            } else {
                Math.abs(System.currentTimeMillis() - location.time)
            }
            if (ageMs !in -5000..180000) return

            val captured = if (location.time > 0 && Math.abs(System.currentTimeMillis() - location.time) < 86400000L) {
                location.time
            } else {
                System.currentTimeMillis()
            }

            if (captured <= lastCaptured && elapsed - lastElapsed < 2000) return

            val minDistance = cfg.optDouble("distanceFilterMeters", 30.0).toFloat().coerceIn(15f, 500f)
            val minIntervalMillis = cfg.optLong("intervalSeconds", 60L).coerceIn(10L, 600L) * 1000L
            val lastP = db.state().optJSONObject("lastPoint")
            if (lastP != null) {
                val lastLat = lastP.optDouble("latitude")
                val lastLng = lastP.optDouble("longitude")
                if (lastLat.isFinite() && lastLng.isFinite()) {
                    val moved = distance(lastLat, lastLng, location.latitude, location.longitude)
                    val timeDiff = captured - lastCaptured
                    // Stationary filter: ignore indoor GPS drift (below 25m or accuracy bubble)
                    // unless 10 minutes have elapsed (periodic heartbeat to keep session alive)
                    val deadband = Math.max(minDistance.toDouble(), (location.accuracy * 0.8).coerceIn(15.0, 45.0))
                    if (moved < deadband && timeDiff < 600000L) {
                        db.updateState { s ->
                            s.put("lastFixAtUtc", Instant.ofEpochMilli(captured).toString())
                            s.put("status", "Stationary • On duty")
                            s.put("running", true)
                        }
                        return
                    }
                }
            }

            val battery = (getSystemService(BATTERY_SERVICE) as BatteryManager).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            val attId = cfg.optLong("attendanceId").takeIf { it > 0 } ?: 0L
            val mode = cfg.optString("mode").takeIf { it.isNotBlank() } ?: "Field"

            val point = JSONObject()
                .put("id", UUID.randomUUID().toString())
                .put("mode", mode)
                .put("attendanceId", attId)
                .put("capturedAtUtc", Instant.ofEpochMilli(captured).toString())
                .put("latitude", location.latitude)
                .put("longitude", location.longitude)
                .put("accuracyMeters", location.accuracy.toDouble())
                .put("isMocked", false)
                .put("provider", provider.take(24))
                .put("batteryPercent", if (battery in 0..100) battery else JSONObject.NULL)

            if (location.hasSpeed()) point.put("speedMps", location.speed.toDouble())
            if (location.hasBearing()) point.put("bearing", location.bearing.toDouble())

            val owner = TrackingRuntime.owner(cfg)
            db.append(owner, point)
            lastCaptured = captured
            lastElapsed = elapsed
            if (location.accuracy > 50) lastCoarse = elapsed

            db.updateState { s ->
                s.put("lastPoint", point)
                s.put("lastFixAtUtc", point.getString("capturedAtUtc"))
                s.put("status", if (location.accuracy <= 50) "Recording your route" else "GPS accuracy: ${location.accuracy.toInt()}m")
                s.put("running", true)
                if (location.accuracy <= 50) {
                    val anchor = s.optJSONObject("stationary")
                    if (anchor == null || captured - anchor.optLong("last") > 180000 || distance(anchor.optDouble("lat"), anchor.optDouble("lng"), location.latitude, location.longitude) > 50) {
                        s.put("stationary", JSONObject().put("lat", location.latitude).put("lng", location.longitude).put("start", captured).put("last", captured))
                        s.remove("stopCandidate")
                    } else {
                        anchor.put("last", captured)
                        if (captured - anchor.getLong("start") >= 600000) {
                            s.put("stopCandidate", JSONObject().put("latitude", anchor.getDouble("lat")).put("longitude", anchor.getDouble("lng")).put("startUtc", Instant.ofEpochMilli(anchor.getLong("start")).toString()).put("minutes", (captured - anchor.getLong("start")) / 60000))
                        }
                    }
                }
            }
            upload()
            notification()
        } catch (e: Exception) {
            MobileDiagnostics.record(this, "channel", e.javaClass.name, MobileDiagnostics.frames(e), "DutyLocationService.accept")
            state("Location update failed: ${e.message?.take(32)}")
        }
    }

    private fun distance(a: Double, b: Double, c: Double, d: Double): Float {
        val result = FloatArray(1)
        Location.distanceBetween(a, b, c, d, result)
        return result[0]
    }

    private fun upload() {
        if (!executor.isShutdown && uploadQueued.compareAndSet(false, true)) {
            try {
                executor.execute {
                    try {
                        TrackingRuntime.sync(this)
                    } finally {
                        uploadQueued.set(false)
                    }
                }
            } catch (_: java.util.concurrent.RejectedExecutionException) {
                uploadQueued.set(false)
            }
        }
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        try {
            fused?.removeLocationUpdates(callback)
            (getSystemService(LOCATION_SERVICE) as LocationManager).removeUpdates(this)
            (getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager).unregisterNetworkCallback(networkCallback)
        } catch (_: Exception) {}
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Exception) {}
        executor.shutdown()
        try {
            TrackingRuntime.store(this).updateState { it.put("running", false) }
            TrackingRuntime.schedule(this)
        } catch (_: Exception) {}
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }
}

class TrackingBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        try {
            val cfg = TrackingRuntime.store(context).config()
            if (cfg.optString("userId").isNotBlank()) {
                TrackingRuntime.schedule(context)
                if (cfg.optBoolean("active") && TrackingRuntime.background(context) && TrackingRuntime.fine(context)) {
                    TrackingRuntime.start(context)
                }
            }
        } catch (_: Exception) {}
    }
}
