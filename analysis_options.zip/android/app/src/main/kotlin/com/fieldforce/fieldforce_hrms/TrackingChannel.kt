package com.fieldforce.fieldforce_hrms
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.BinaryMessenger
import org.json.JSONObject
import java.util.concurrent.Executors
class TrackingChannel(private val activity: Activity,messenger: BinaryMessenger){
 private fun safeSuccess(result:MethodChannel.Result,value:Any?) {
    try{result.success(value)}catch(error:Exception){
      MobileDiagnostics.record(activity,"channel",error.javaClass.name,MobileDiagnostics.frames(error),"channel.encode")
      try{result.error("CHANNEL_ENCODING_FAILED","Unable to read phone data. Records are retained.",null)}catch(_:Exception){}
    }
 }
 private val executor=Executors.newSingleThreadExecutor()
 private val networkExecutor=Executors.newSingleThreadExecutor()
 init {MethodChannel(messenger,"trackyu/duty_tracking").setMethodCallHandler {call,result->try{when(call.method){
  "diagnostic"->{val args=JSONObject(call.arguments as Map<*,*>);executor.execute{MobileDiagnostics.record(activity,"flutter",args.optString("errorType"),args.optString("stack"),args.optString("context"));try{TrackingRuntime.schedule(activity)}catch(_:Exception){}};safeSuccess(result,null)}
  "localAuth","localRead","localReadSummary","localWrite","localCommit","localSyncState","localPause","configureOffline"->{
    val args=JSONObject(call.arguments as Map<*,*>)
    executor.execute {try {
      val db=TrackingRuntime.store(activity);var response:Any?=null
      when(call.method) {
        "localAuth"->{require(TrackingRuntime.validUrl(args.getString("baseUrl")));require(args.getString("scope")==args.getString("baseUrl")+"|"+args.getString("userId"));db.localWrite("system","activeAuth",args);try{db.writableDatabase.execSQL("UPDATE local_outbox SET error=NULL, state='pending' WHERE scope=? AND (error LIKE '%Sign in%' OR state='blocked')", arrayOf(args.getString("scope")))}catch(_:Exception){};MobileDiagnostics.bind(activity,args.getString("scope"));TrackingRuntime.schedule(activity)}
        "localPause"->{val auth=LocalWorkspaceSync.auth(db);if(auth?.optString("scope")==args.optString("scope"))db.localWrite("system","activeAuth",JSONObject().put("scope",args.getString("scope")).put("paused",true))}
        "localReadSummary"->{response=db.routeSummary(args.getString("scope"),args.getString("key"))?.let{TrackingRuntime.jsonMap(it)}}
        "localRead"->{response=db.localRead(args.getString("scope"),args.getString("key"))?.let{TrackingRuntime.jsonMap(it)}}
        "localWrite"->{db.localWrite(args.getString("scope"),args.getString("key"),args.getJSONObject("value"))}
        "localCommit"->{val op=args.getJSONObject("operation");require(op.getString("route") in LocalWorkspaceSync.allowed);db.localCommit(args.getString("scope"),args.getString("key"),args.getJSONObject("value"),op)}
        "localSyncState"->{response=TrackingRuntime.jsonMap(db.localSyncState(args.getString("scope")))}
        "configureOffline"->{
          val auth=LocalWorkspaceSync.auth(db)?:throw IllegalStateException("Sign in first")
          require(auth.optString("userId")==args.getString("userId"));require(auth.optString("baseUrl")==args.getString("baseUrl"))
          val existing=db.config();val receipt=db.localResult(auth.getString("scope"),args.getString("requestId"))
          if(receipt!=null)args.put("attendanceId",receipt.getLong("id"))
          if(existing.optString("requestId")==args.optString("requestId")){for(k in listOf("trackingKey","expiresAtUtc","serverId"))if(existing.has(k))args.put(k,existing.get(k))}
          args.put("trackingKey",if(existing.optString("requestId")==args.optString("requestId"))existing.optString("trackingKey")else "")
          args.put("deviceId",auth.getString("deviceId"));args.put("offlineLocal",true)
          TrackingRuntime.configure(activity,args)
        }
      }
      activity.runOnUiThread{safeSuccess(result,response)}
    }catch(error:Exception){MobileDiagnostics.record(activity,"channel",error.javaClass.name,MobileDiagnostics.frames(error),"timeline.storage");activity.runOnUiThread{result.error("LOCAL_STORAGE_FAILED","Unable to save phone data: ${error.localizedMessage ?: error.javaClass.simpleName}",null)}}}
  }
  "configure"->{TrackingRuntime.configure(activity,JSONObject(call.arguments as Map<*,*>));safeSuccess(result,TrackingRuntime.jsonMap(TrackingRuntime.status(activity)))}
  "status"->{executor.execute{try{val status=TrackingRuntime.jsonMap(TrackingRuntime.status(activity));activity.runOnUiThread{safeSuccess(result,status)}}catch(error:Exception){MobileDiagnostics.record(activity,"channel",error.javaClass.name,MobileDiagnostics.frames(error),"timeline.status");activity.runOnUiThread{result.error("TRACKING_UNAVAILABLE","Unable to read tracking status",null)}}}}
  "resume"->{TrackingRuntime.start(activity);safeSuccess(result,null)}
  "refreshFix"->{
    val args=JSONObject(call.arguments as Map<*,*>);val cfg=TrackingRuntime.store(activity).config()
    require(cfg.optString("userId")==args.getString("userId")&&cfg.optString("baseUrl")==args.getString("baseUrl")&&cfg.optBoolean("active"))
    TrackingRuntime.start(activity,true);safeSuccess(result,null)
  }
  "stop"->{TrackingRuntime.stop(activity);safeSuccess(result,null)}
  "sync"->{
    TrackingRuntime.schedule(activity)
    networkExecutor.execute {
      val db = TrackingRuntime.store(activity)
      val auth = LocalWorkspaceSync.auth(db)
      if (auth != null) db.unblockOutbox(auth.getString("scope"))
      TrackingRuntime.sync(activity, force = true)
    }
    safeSuccess(result,null)
  }
  "batterySettings"->{
    try {
      val pm = activity.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
      if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M && !pm.isIgnoringBatteryOptimizations(activity.packageName)) {
        val reqIntent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
          data = Uri.parse("package:${activity.packageName}")
        }
        activity.startActivity(reqIntent)
      } else {
        activity.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
      }
    } catch (_: Exception) {
      try {
        val appIntent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
          data = Uri.parse("package:${activity.packageName}")
        }
        activity.startActivity(appIntent)
      } catch (_: Exception) {
        activity.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
      }
    }
    safeSuccess(result,null)
  }
  "route"->{
    val args = call.arguments as? Map<*, *> ?: emptyMap<String, Any>()
    val from = (args["from"] as? Number)?.toLong() ?: 0L
    val to = (args["to"] as? Number)?.toLong() ?: Long.MAX_VALUE
    executor.execute {try {
    val store = TrackingRuntime.store(activity)
    val requestedUser=args["userId"] as? String
    val requestedBase=args["baseUrl"] as? String
    val cfg=if(requestedUser.isNullOrBlank()||requestedBase.isNullOrBlank())store.config()else JSONObject()
    val userId=requestedUser?.takeIf{it.isNotBlank()}?:cfg.optString("userId")
    val baseUrl=requestedBase?.takeIf{it.isNotBlank()}?:cfg.optString("baseUrl")
    val points=if(userId.isNotBlank())store.route(baseUrl+"|"+userId,from,to,if(args["timeline"]==true)0 else RouteProjection.MAX_POINTS,((args["offset"] as? Number)?.toInt()?:0),if(args["timeline"]==true)((args["pageSize"] as? Number)?.toInt()?:250).coerceIn(1,2000) else 0)else emptyList();activity.runOnUiThread{safeSuccess(result,points.map{TrackingRuntime.jsonMap(it)})}}catch(error:Exception){MobileDiagnostics.record(activity,"channel",error.javaClass.name,MobileDiagnostics.frames(error),"timeline.storage");activity.runOnUiThread{result.error("LOCAL_STORAGE_FAILED","Unable to read saved locations",null)}}}
  }
  else->result.notImplemented()
 }}catch(_:Exception){result.error("TRACKING_UNAVAILABLE","Unable to access location tracking. Check location permission and phone storage.",null)}}}
}
