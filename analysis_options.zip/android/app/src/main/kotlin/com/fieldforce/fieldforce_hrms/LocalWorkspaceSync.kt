package com.fieldforce.fieldforce_hrms

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant

/** Ordered durable outbox. A 4xx blocks the item; it never discards phone data. */
object LocalWorkspaceSync {
    val allowed=setOf("FieldAttendance/punch-in","FieldAttendance/punch-out","OfficeAttendance/punch-in","OfficeAttendance/punch-out","MobileVisits/start","MobileVisits/finish","OfficeLeave/apply","OfficeActivities/save","OfficeReminders/save","OfficePreIntimation/submit")
    fun auth(db:TrackingStore):JSONObject?=db.localRead("system","activeAuth")
    fun request(auth:JSONObject,route:String,body:JSONObject,operationId:String?=null):JSONObject {
        require(TrackingRuntime.validUrl(auth.getString("baseUrl")))
        val c=URL(auth.getString("baseUrl")+"/"+route).openConnection() as HttpURLConnection
        try {
            c.requestMethod="POST";c.connectTimeout=8000;c.readTimeout=12000;c.doOutput=true
            c.setRequestProperty("Authorization","Bearer "+auth.getString("token"));c.setRequestProperty("X-Device-ID",auth.getString("deviceId"));c.setRequestProperty("Content-Type","application/json")
            if(operationId!=null)c.setRequestProperty("X-Operation-ID",operationId)
            c.outputStream.use{it.write(body.toString().toByteArray(Charsets.UTF_8))}
            val status=c.responseCode
            val text=(if(status in 200..299)c.inputStream else c.errorStream)?.bufferedReader()?.use{it.readText()}?:""
            val response=try{JSONObject(text)}catch(_:Exception){JSONObject()}
            if(status !in 200..299||!response.optBoolean("success"))throw SyncError(status,response.optString("message","Sync unavailable"))
            return response
        } finally {c.disconnect()}
    }
    class SyncError(val status:Int,message:String):Exception(message)

    fun renewLease(context:Context,db:TrackingStore) {
        val cfg=db.config()
        if(!cfg.optBoolean("offlineLocal"))return
        val auth=auth(db)?:return
        if(auth.optBoolean("paused")||auth.optString("userId")!=cfg.optString("userId")||auth.optString("baseUrl")!=cfg.optString("baseUrl"))return
        val receipt=db.localResult(auth.getString("scope"),cfg.optString("requestId"))
        val attendanceId=receipt?.optLong("id")?:cfg.optLong("attendanceId")
        if(receipt==null&&cfg.optLong("serverId")==0L)return
        val expires=try{Instant.parse(cfg.optString("expiresAtUtc"))}catch(_:Exception){Instant.EPOCH}
        if(cfg.optString("trackingKey").length>=32&&expires.isAfter(Instant.now().plusSeconds(86400)))return
        val lease=request(auth,"DutyTracking/lease",JSONObject().put("mode",cfg.getString("mode")).put("attendanceId",attendanceId)).getJSONObject("data")
        val latest=db.config()
        if(latest.optString("requestId")!=cfg.optString("requestId"))return
        latest.put("attendanceId",attendanceId);latest.put("trackingKey",lease.getString("trackingKey"));latest.put("expiresAtUtc",lease.getString("expiresAtUtc"));latest.put("serverTimeUtc",lease.getString("serverTimeUtc"));latest.put("dutyCutoffUtc",lease.getString("dutyCutoffUtc"))
        TrackingRuntime.configure(context,latest)
    }
    fun drain(context:Context,db:TrackingStore):Boolean {
        val auth=auth(db)?:return true
        if(auth.optBoolean("paused"))return true
        val scope=auth.getString("scope")
        repeat(30) {
            if(auth(db)?.optString("scope")!=scope||auth(db)?.optBoolean("paused")==true)return false
            val operation=db.localNext(scope)?:return db.localSyncState(scope).optInt("blocked")==0
            val id=operation.getString("id");val route=operation.getString("route")
            if(route !in allowed){db.localError(scope,id,"Unsupported operation; retained for review",true);return false}
            try {
                val body=JSONObject(operation.getJSONObject("body").toString())
                val refs=operation.optJSONObject("refs")
                if(refs!=null)for(field in refs.keys()) {
                    val ref=refs.getJSONObject(field);val receipt=db.localResult(scope,ref.getString("operationId"))?:return false
                    val value=receipt.opt(ref.getString("field"))
                    if(value==null||value==JSONObject.NULL)throw IllegalStateException("Dependency receipt is incomplete")
                    body.put(field,value)
                }
                val response=request(auth,route,body,id)
                val value=response.opt("data")
                val saved=if(value is JSONObject)value else JSONObject().put("value",value)
                if(route.endsWith("Attendance/punch-in")) {
                    val mode=if(route.startsWith("Field"))"Field"else"Office"
                    db.remapAttendance(scope,mode,operation.getLong("localId"),saved.getLong("id"))

                }
                db.localAck(scope,operation,saved)
            } catch(e:SyncError) {
                // Auth and transient failures wait for reauthentication/connectivity.
                db.localError(scope,id,if(e.status==401)"Sign in to resume sync"else e.message?:"Sync failed",e.status in 400..499&&e.status !in listOf(401,408,429))
                return false
            } catch(_:Exception) {db.localError(scope,id,"Connection unavailable. Saved on this phone.",false);return false}
        }
        return false
    }
}
