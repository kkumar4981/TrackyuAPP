import 'dart:async';
import 'package:flutter/material.dart';
import 'trackyu/app.dart';
import 'trackyu/error_logger.dart';

void main() {
  runZonedGuarded(
    () {
      WidgetsFlutterBinding.ensureInitialized();
      ErrorLogger.installHandlers();
      // Render immediately. Diagnostics must never hold the Android launch screen.
      runApp(const TrackyuApp());
      unawaited(ErrorLogger.initialize());
    },
    (error, stack) {
      unawaited(ErrorLogger.record(error, stack, context: 'rootZone'));
    },
  );
}
