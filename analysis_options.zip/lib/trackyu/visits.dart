import 'visit_media.dart';
import 'package:geocoding/geocoding.dart';
import 'address_cache.dart';
import 'duty_tracking.dart';
import 'dart:convert';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import 'api.dart';
import 'controller.dart';
import 'selfie.dart';
import 'selfie_view.dart';
import 'workspace.dart'
    show dateOnly, jsonRows, WorkspacePage, WorkFeature;

String cleanAddress(String? raw) {
  if (raw == null) return '';
  var trimmed = raw.replaceAll(RegExp(r'\s+'), ' ').trim();
  trimmed = trimmed.replaceAll(RegExp(r'\b[A-Z0-9]{4,8}\+[A-Z0-9]{2,},?\s*', caseSensitive: false), '').trim();
  if (trimmed.isEmpty || trimmed == '-') return '';

  final parts = trimmed.split(RegExp(r'[,;\n]'));
  final seen = <String>{};
  final cleaned = <String>[];

  for (final part in parts) {
    final segment = part.trim();
    if (segment.isEmpty) continue;
    final lower = segment.toLowerCase();
    if (seen.contains(lower)) continue;
    if (lower.contains('unnamed road')) continue;

    bool isDuplicate = false;
    for (int i = 0; i < cleaned.length; i++) {
      final prevLower = cleaned[i].toLowerCase();
      if (prevLower == lower) {
        isDuplicate = true;
        break;
      }
      if (prevLower.contains(lower) && lower.length >= 4) {
        isDuplicate = true;
        break;
      }
      if (lower.contains(prevLower) && prevLower.length >= 4) {
        cleaned[i] = segment;
        seen.remove(prevLower);
        seen.add(lower);
        isDuplicate = true;
        break;
      }
    }

    if (!isDuplicate) {
      seen.add(lower);
      cleaned.add(segment);
    }
  }
  return cleaned.join(', ');
}

String formatPlacemarkAddress(Placemark p) {
  final candidates = [
    p.name,
    p.street,
    p.subLocality,
    p.locality,
    p.subAdministrativeArea,
    p.administrativeArea,
    p.postalCode,
    p.country,
  ];
  return cleanAddress(candidates.whereType<String>().join(', '));
}

String formatVisitTime(dynamic inUtc, dynamic outUtc) {
  if (inUtc == null) return 'Time not recorded';
  final start = DateTime.tryParse('$inUtc')?.toLocal();
  if (start == null) return '$inUtc';

  final startStr = _format12Hour(start);
  if (outUtc == null) {
    return 'Started at $startStr • In progress';
  }

  final end = DateTime.tryParse('$outUtc')?.toLocal();
  if (end == null) return startStr;

  final endStr = _format12Hour(end);
  final durMin = end.difference(start).inMinutes;
  final durStr = durMin > 0 ? '$durMin min stay' : '< 1 min stay';

  final now = DateTime.now();
  final isToday = start.year == now.year && start.month == now.month && start.day == now.day;
  final datePrefix = isToday ? '' : '${start.day}/${start.month} · ';

  return '$datePrefix$startStr – $endStr • $durStr';
}

String _format12Hour(DateTime dt) {
  final hour = dt.hour % 12 == 0 ? 12 : dt.hour % 12;
  final minute = dt.minute.toString().padLeft(2, '0');
  final ampm = dt.hour < 12 ? 'AM' : 'PM';
  return '$hour:$minute $ampm';
}

int visitIdOf(Json row) {
  final val = row['id'] ?? row['Id'] ?? row['localId'] ?? row['LocalId'];
  if (val is num) return val.toInt();
  if (val != null) return int.tryParse(val.toString()) ?? 0;
  return 0;
}

bool visitCheckoutReady(Json row, DateTime now) {
  final earliest = DateTime.tryParse('${row['earliestCheckoutUtc']}');
  return earliest == null || !now.toUtc().isBefore(earliest.toUtc());
}

class SalesmanVisitShortcut extends StatefulWidget {
  final TrackyuController controller;
  final bool enabled;
  const SalesmanVisitShortcut({
    super.key,
    required this.controller,
    this.enabled = true,
  });

  @override
  State<SalesmanVisitShortcut> createState() => _SalesmanVisitShortcutState();
}

class _SalesmanVisitShortcutState extends State<SalesmanVisitShortcut> {
  Timer? _ticker;
  Json? _active;

  @override
  void initState() {
    super.initState();
    widget.controller.addListener(_onControllerChanged);
    _checkActiveVisit();
  }

  @override
  void dispose() {
    _ticker?.cancel();
    widget.controller.removeListener(_onControllerChanged);
    super.dispose();
  }

  void _onControllerChanged() {
    if (!mounted) return;
    _checkActiveVisit();
  }

  Future<void> _checkActiveVisit() async {
    if (!widget.controller.onDuty) {
      if (mounted && _active != null) {
        setState(() => _active = null);
        _ensureTicker();
      }
      return;
    }
    Json? found = widget.controller.activeVisit;
    final todayStr = widget.controller.localDay;
    if (found != null) {
      final vDate = found['workDate']?.toString();
      if (vDate != null && vDate.isNotEmpty && vDate != todayStr) {
        found = null;
      }
    }
    if (found == null) {
      if (widget.controller.local != null) {
        final day = await widget.controller.localDayData();
        final visits = jsonRows(day['visits'] ?? []);
        found = visits
            .where((r) =>
                r['checkOutUtc'] == null &&
                (r['workDate'] == null ||
                    r['workDate'] == '' ||
                    r['workDate'] == todayStr))
            .firstOrNull;
      }
      if (found == null) {
        final cached = await widget.controller.scopedVisitCache();
        found = cached
            .where((r) =>
                r['checkOutUtc'] == null &&
                (r['workDate'] == null ||
                    r['workDate'] == '' ||
                    r['workDate'] == todayStr))
            .firstOrNull;
      }
    }
    if (!mounted) return;
    if (found != _active) {
      setState(() {
        _active = found;
      });
      _ensureTicker();
    }
  }

  void _ensureTicker() {
    if (_active != null) {
      _ticker ??= Timer.periodic(const Duration(seconds: 1), (_) {
        if (mounted && _active != null) {
          setState(() {});
        }
      });
    } else {
      _ticker?.cancel();
      _ticker = null;
    }
  }

  Future<void> _punchOutVisit(BuildContext context, Json visit) async {
    final data = VisitsData(widget.controller);
    await data.load();
    if (!context.mounted) return;
    final saved = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) => VisitForm(data: data, visit: visit),
      ),
    );
    if (saved == true && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Visit punch-out confirmed.')),
      );
      widget.controller.activeVisit = null;
      setState(() {
        _active = null;
      });
      await widget.controller.refresh();
      _checkActiveVisit();
    }
  }

  void _openVisitsPage() {
    Navigator.push(
      context,
      MaterialPageRoute<void>(
        builder: (_) => VisitsPage(controller: widget.controller),
      ),
    ).then((_) {
      if (mounted) _checkActiveVisit();
    });
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.controller.onDuty) {
      return const SizedBox.shrink();
    }
    final isDark = widget.controller.isDarkMode;
    final active = widget.controller.activeVisit ?? _active;

    if (active != null) {
      final start = DateTime.tryParse('${active['checkInUtc']}');
      final checkInStr = start != null ? _format12Hour(start.toLocal()) : '--:--';
      final seconds = start != null
          ? DateTime.now().toUtc().difference(start.toUtc()).inSeconds.clamp(0, 864000)
          : 0;
      final elapsed =
          '${(seconds ~/ 3600).toString().padLeft(2, '0')}:${((seconds % 3600) ~/ 60).toString().padLeft(2, '0')}:${(seconds % 60).toString().padLeft(2, '0')}';
      final shopName = active['shopName']?.toString().trim().isNotEmpty == true
          ? active['shopName'].toString()
          : (active['clientName']?.toString().trim().isNotEmpty == true
              ? active['clientName'].toString()
              : 'Customer Visit');
      final place = cleanAddress(active['placeName']?.toString() ?? active['address']?.toString());
      final isRegular = active['kind'] == 'Regular';
      final canPunchOut = visitCheckoutReady(active, DateTime.now());

      return Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: LinearGradient(
            colors: isDark
                ? [const Color(0xff291a0a), const Color(0xff1c150c)]
                : [const Color(0xfffffbeb), const Color(0xfffef3c7)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          border: Border.all(
            color: isDark ? const Color(0xfff59e0b).withValues(alpha: 0.6) : const Color(0xfff59e0b),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: (isDark ? const Color(0xfff59e0b) : const Color(0xffd97706)).withValues(alpha: 0.14),
              blurRadius: 16,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(20),
            onTap: widget.enabled ? _openVisitsPage : null,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Top Badges Row
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: isDark ? const Color(0xff78350f) : const Color(0xffffedd5),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: isDark
                                ? const Color(0xfff59e0b).withValues(alpha: 0.5)
                                : const Color(0xfffdba74),
                          ),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              width: 7,
                              height: 7,
                              decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                                color: Color(0xffea580c),
                              ),
                            ),
                            const SizedBox(width: 5),
                            Text(
                              'VISIT IN PROGRESS',
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w800,
                                letterSpacing: 0.4,
                                color: isDark ? const Color(0xfffef08a) : const Color(0xffc2410c),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const Spacer(),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3.5),
                        decoration: BoxDecoration(
                          color: isDark ? const Color(0xff1e293b) : Colors.white.withValues(alpha: 0.8),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color: isDark ? const Color(0xff334155) : const Color(0xffe2e8f0),
                          ),
                        ),
                        child: Text(
                          isRegular ? 'Retailer' : 'Open visit',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                            color: isDark ? const Color(0xffcbd5e1) : const Color(0xff475569),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),

                  // Store Info Row
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          color: isDark ? const Color(0xff451a03) : const Color(0xffffedd5),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: isDark
                                ? const Color(0xffb45309).withValues(alpha: 0.4)
                                : const Color(0xfffed7aa),
                          ),
                        ),
                        child: const Icon(
                          Icons.storefront_rounded,
                          color: Color(0xffea580c),
                          size: 24,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              shopName,
                              style: TextStyle(
                                fontSize: 17,
                                fontWeight: FontWeight.w800,
                                letterSpacing: -0.3,
                                color: isDark ? Colors.white : const Color(0xff0f172a),
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            if (place.isNotEmpty) ...[
                              const SizedBox(height: 2),
                              Row(
                                children: [
                                  const Icon(
                                    Icons.place_rounded,
                                    size: 13,
                                    color: Color(0xffea580c),
                                  ),
                                  const SizedBox(width: 3),
                                  Expanded(
                                    child: Text(
                                      place,
                                      style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.w500,
                                        color: isDark ? const Color(0xff94a3b8) : const Color(0xff64748b),
                                      ),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),

                  // Timer & Check-in Details Bar
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                    decoration: BoxDecoration(
                      color: isDark ? const Color(0xff17120a) : Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: isDark
                            ? const Color(0xff78350f).withValues(alpha: 0.35)
                            : const Color(0xfffed7aa),
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Icon(
                              Icons.login_rounded,
                              size: 14,
                              color: isDark ? const Color(0xff94a3b8) : const Color(0xff64748b),
                            ),
                            const SizedBox(width: 5),
                            Text(
                              'In: $checkInStr',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                color: isDark ? const Color(0xffcbd5e1) : const Color(0xff475569),
                              ),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            const Icon(
                              Icons.timer_outlined,
                              size: 14,
                              color: Color(0xffea580c),
                            ),
                            const SizedBox(width: 5),
                            Text(
                              elapsed,
                              style: const TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w800,
                                fontFamily: 'monospace',
                                color: Color(0xffea580c),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),

                  // Action Buttons Row
                  Row(
                    children: [
                      Expanded(
                        child: FilledButton.icon(
                          style: FilledButton.styleFrom(
                            backgroundColor: const Color(0xffea580c),
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(vertical: 11),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            elevation: 0,
                          ),
                          onPressed: widget.enabled
                              ? (canPunchOut ? () => _punchOutVisit(context, active) : null)
                              : null,
                          icon: const Icon(Icons.check_circle_rounded, size: 17),
                          label: Text(
                            canPunchOut ? 'Punch Out Visit' : 'Min. 10m Required',
                            style: const TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Material(
                        color: isDark ? const Color(0xff332415) : const Color(0xffffedd5),
                        borderRadius: BorderRadius.circular(12),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(12),
                          onTap: widget.enabled ? _openVisitsPage : null,
                          child: Container(
                            padding: const EdgeInsets.all(11),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: isDark ? const Color(0xff78350f) : const Color(0xfffed7aa),
                              ),
                            ),
                            child: const Icon(
                              Icons.arrow_forward_rounded,
                              size: 18,
                              color: Color(0xffea580c),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    }

    // Default Salesman Visit shortcut when no visit is in progress
    return Material(
      color: isDark ? const Color(0xff1e1e1e) : const Color(0xfff0fdf4),
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: widget.enabled ? _openVisitsPage : null,
        child: Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: isDark ? const Color(0xff2d3135) : const Color(0xffbbf7d0),
            ),
          ),
          child: Row(
            children: [
              Icon(
                Icons.storefront_rounded,
                color: isDark
                    ? const Color(0xff4ade80)
                    : const Color(0xff16a34a),
                size: 28,
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Salesman visit',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        color: isDark ? Colors.white : const Color(0xff14532d),
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      'Open visit • Client check-in with selfie & GPS',
                      style: TextStyle(
                        fontSize: 12,
                        color: isDark
                            ? const Color(0xff94a3b8)
                            : const Color(0xff166534),
                      ),
                    ),
                  ],
                ),
              ),
              Icon(
                Icons.arrow_forward_rounded,
                color: isDark
                    ? const Color(0xff4ade80)
                    : const Color(0xff16a34a),
                size: 20,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class VisitsData extends ChangeNotifier {
  final TrackyuController session;
  final Future<String?> Function() capture;
  VisitsData(this.session, {Future<String?> Function()? capture})
    : capture = capture ?? capturePunchSelfie;
  List<Json> rows = [], retailers = [];
  bool loading = false, saving = false, disposed = false;
  String? error;
  String startKey = const Uuid().v4(), finishKey = const Uuid().v4();
  Json? get active {
    final todayStr = session.localDay;
    return rows
        .where((r) =>
            r['checkOutUtc'] == null &&
            (r['workDate'] == null ||
                r['workDate'] == '' ||
                r['workDate'] == todayStr))
        .firstOrNull;
  }
  Future<dynamic> request(String route, {Json? body}) async {
    try {
      return await session.api.request(route, body: body);
    } on ApiFailure catch (e) {
      if (e.status == 401) await session.signOut();
      rethrow;
    }
  }

  Future<void> loadCachedVisits() async {
    if (session.local != null) {
      final day = await session.localDayData();
      rows = jsonRows(day['visits'] ?? []);
      return;
    }
    try {
      final raw = await session.vault.readCachedVisits();
      if (raw != null && raw.isNotEmpty) {
        final decoded = jsonDecode(raw);
        if (decoded is Map &&
            decoded['scope'] == session.visitCacheScope &&
            decoded['rows'] is List) {
          rows = (decoded['rows'] as List)
              .whereType<Map>()
              .map((e) => Map<String, dynamic>.from(e))
              .toList();
        }
      }
    } catch (_) {}
  }

  Future<void> saveCachedVisits() async {
    try {
      await session.vault.writeCachedVisits(
        jsonEncode({'scope': session.visitCacheScope, 'rows': rows}),
      );
    } catch (_) {}
  }

  Future<void> _recordOfflineVisit({
    required bool finish,
    required Json fields,
    required Json point,
    required bool needsSelfie,
    required String? photo,
  }) async {
    final nowUtc =
        point['capturedAtUtc']?.toString() ??
        DateTime.now().toUtc().toIso8601String();
    final operationId = finish ? finishKey : startKey;

    if (finish) {
      final targetId = fields['id'];
      final idx = rows.indexWhere((r) {
        if (targetId != null &&
            (r['id']?.toString() == targetId.toString() ||
                r['localId']?.toString() == targetId.toString())) {
          return true;
        }
        return r['checkOutUtc'] == null;
      });

      if (idx >= 0) {
        final before = rows[idx];
        final localId = before['localId'] ?? before['id'];
        final serverVisitId = before['serverId'] ?? (before['isOffline'] != true ? before['id'] : null);
        final reqBody = {
          if (serverVisitId != null) 'id': serverVisitId,
          ...fields,
          ...point,
          'requestId': finishKey,
          if (needsSelfie) 'departureSelfieBase64': photo,
        };
        rows[idx] = {
          ...rows[idx],
          'checkOutUtc': nowUtc,
          'outLatitude': point['latitude'],
          'outLongitude': point['longitude'],
          'remark': fields['remark'],
          'ownerName': fields['ownerName'],
          'mobile': fields['mobile'],
          'lead': fields['lead'],
          'orderRemark': fields['orderRemark'],
          'otherRemark': fields['otherRemark'],
          if (needsSelfie) 'departureSelfieBase64': photo,
          if (needsSelfie) 'hasDepartureSelfie': photo != null,
          'isOffline': true,
        };
        finishKey = const Uuid().v4();

        if (session.local != null) {
          final refs = <String, dynamic>{};
          if (before['serverId'] == null &&
              before['requestId'] != null &&
              before['isOffline'] == true) {
            refs['id'] = {'operationId': before['requestId'], 'field': 'id'};
            refs['version'] = {
              'operationId': before['requestId'],
              'field': 'version',
            };
            reqBody['version'] ??= 'pending';
          }
          final day = await session.localDayData();
          await session.commitLocal(
            {...day, 'visits': rows},
            {
              'id': operationId,
              'route': 'MobileVisits/finish',
              'body': reqBody,
              'localId': localId,
              'refs': refs,
            },
          );
        } else {
          await saveCachedVisits();
          await session.queuePendingVisit(finish: true, body: reqBody);
        }
      } else {
        throw const ApiFailure(
          'NO_ACTIVE_VISIT',
          'No active visit found to punch out.',
        );
      }
    } else {
      final localId = DateTime.now().microsecondsSinceEpoch;
      final reqBody = {
        ...fields,
        ...point,
        'requestId': startKey,
        'photoBase64': photo,
      };
      final localVisit = {
        'id': localId,
        'localId': localId,
        'requestId': startKey,
        'retailerId': fields['retailerId'],
        'shopName': fields['shopName'] ?? fields['clientName'] ?? 'Open Visit',
        'placeName': fields['placeName'] ?? '',
        'clientName': fields['clientName'] ?? fields['shopName'] ?? 'Client',
        'address': fields['address'] ?? point['address'] ?? 'Recorded via GPS',
        'checkInUtc': nowUtc,
        'earliestCheckoutUtc': DateTime.parse(nowUtc)
            .add(Duration(minutes: fields['kind'] == 'Regular' ? 10 : 0))
            .toIso8601String(),
        'inLatitude': point['latitude'],
        'inLongitude': point['longitude'],
        'kind': fields['kind'] ?? 'Open',
        'isOffline': true,
        'syncState': 'pending',
        'photoBase64': photo,
        'hasArrivalSelfie': photo != null,
        'workDate': session.localDay,
      };
      rows = [localVisit, ...rows];
      startKey = const Uuid().v4();

      if (session.local != null) {
        final day = await session.localDayData();
        await session.commitLocal(
          {...day, 'visits': rows},
          {
            'id': operationId,
            'route': 'MobileVisits/start',
            'body': reqBody,
            'localId': localId,
          },
        );
      } else {
        await saveCachedVisits();
        await session.queuePendingVisit(finish: false, body: reqBody);
      }
    }
    session.notice =
        'Visit recorded offline on phone. Will sync when server is reachable.';
  }

  Future<void> load() async {
    if (loading || disposed) return;
    loading = true;
    error = null;
    notifyListeners();
    try {
      if (!session.offline) {
        try {
          await session.refreshMenus();
        } catch (_) {}
      }
      if (session.offline || session.local != null) {
        await loadCachedVisits();
      } else {
        final result = jsonRows(
          await request('MobileVisits/mine?date=${dateOnly(DateTime.now())}'),
        );
        if (!disposed) {
          rows = result;
          await saveCachedVisits();
          if (rows.any((r) => r['requestId'] == startKey)) {
            startKey = const Uuid().v4();
          }
          if (rows.any((r) => r['closeRequestId'] == finishKey)) {
            finishKey = const Uuid().v4();
          }
        }
      }
    } catch (e) {
      if (!disposed) {
        await loadCachedVisits();
        session.setOffline(true);
        error = null;
      }
    } finally {
      session.activeVisit = active;
      loading = false;
      if (!disposed) notifyListeners();
    }
  }

  Future<List<Json>> search(String query) async {
    final cache = await session.local?.read('retailers');
    final saved = jsonRows(cache?['rows'] ?? []);
    if (session.offline && session.local != null) {
      final term = query.trim().toLowerCase();
      return saved
          .where(
            (r) => '${r['id']} ${r['name']} ${r['place']}'
                .toLowerCase()
                .contains(term),
          )
          .toList();
    }
    final result = jsonRows(
      await request(
        'MobileVisits/retailers?search=${Uri.encodeQueryComponent(query.trim())}',
      ),
    );
    if (session.local != null) {
      await session.local!.write('retailers', {
        'rows': [
          ...result,
          ...saved.where((r) => !result.any((n) => n['id'] == r['id'])),
        ],
      });
    }
    return result;
  }

  Future<void> discard(Json visit) async {
    final targetId = visit['id'] ?? visit['Id'] ?? visit['localId'];
    rows.removeWhere((r) =>
        (targetId != null &&
            (r['id']?.toString() == targetId.toString() ||
                r['localId']?.toString() == targetId.toString())) ||
        (r['requestId'] != null && r['requestId'] == visit['requestId']));
    if (session.activeVisit?['id']?.toString() == targetId?.toString() ||
        session.activeVisit?['localId']?.toString() == targetId?.toString()) {
      session.activeVisit = null;
    }
    if (session.local != null) {
      final day = await session.localDayData();
      await session.local!.write(session.dayKey, {...day, 'visits': rows});
    } else {
      await saveCachedVisits();
    }
    session.activeVisit = active;
    notifyListeners();
  }

  Future<bool> save({required bool finish, required Json fields}) async {
    if (saving || disposed) return false;
    saving = true;
    final beforeRows = rows.map((r) => Map<String, dynamic>.from(r)).toList();
    final beforeStartKey = startKey, beforeFinishKey = finishKey;
    notifyListeners();
    try {
      if (!session.offline) {
        try {
          await session.refreshMenus();
        } catch (_) {}
      }
      session.requireVisitDuty();
      if (!finish && !session.menuEnabled('visits')) {
        if (!session.offline) {
          try {
            await session.refreshMenus();
          } catch (_) {}
        }
        if (!session.menuEnabled('visits')) {
          throw const ApiFailure(
            'MENU_DISABLED',
            'Visits have been disabled by your administrator.',
          );
        }
      }
      final needsSelfie =
          !finish || fields['kind'] == 'Open' || active?['kind'] == 'Open';
      final photo = needsSelfie ? await capture() : null;
      if (needsSelfie && photo == null) return false;
      session.requireVisitDuty();
      final point = await session.locate();
      final reqBody = {
        ...fields,
        ...point,
        'requestId': finish ? finishKey : startKey,
        if (!finish) 'photoBase64': photo,
        if (finish && needsSelfie) 'departureSelfieBase64': photo,
      };
      if (session.offline || session.local != null) {
        await _recordOfflineVisit(
          finish: finish,
          fields: fields,
          point: point,
          needsSelfie: needsSelfie,
          photo: photo,
        );
        return true;
      }
      await request(
        'MobileVisits/${finish ? 'finish' : 'start'}',
        body: reqBody,
      );
      if (finish) {
        finishKey = const Uuid().v4();
      } else {
        startKey = const Uuid().v4();
      }
      await load();
      return true;
    } catch (_) {
      if (session.local != null) {
        rows = beforeRows;
        startKey = beforeStartKey;
        finishKey = beforeFinishKey;
      }
      rethrow;
    } finally {
      saving = false;
      if (!disposed) notifyListeners();
    }
  }

  @override
  void dispose() {
    disposed = true;
    super.dispose();
  }
}

class VisitsPage extends StatefulWidget {
  final TrackyuController controller;
  const VisitsPage({super.key, required this.controller});
  @override
  State<VisitsPage> createState() => _VisitsPageState();
}

class _VisitsPageState extends State<VisitsPage> {
  late final VisitsData data;
  Timer? _ticker;
  @override
  void initState() {
    super.initState();
    data = VisitsData(widget.controller)..addListener(changed);
    data.load();
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted && data.active != null) {
        setState(() {});
      }
    });
  }

  void changed() {
    if (!mounted) return;
    if (!widget.controller.loggedIn) {
      Navigator.of(context).popUntil((r) => r.isFirst);
      return;
    }
    setState(() {});
  }

  @override
  void dispose() {
    _ticker?.cancel();
    data.removeListener(changed);
    data.dispose();
    super.dispose();
  }

  Future<void> edit(Json? visit) async {
    if (!widget.controller.offline) {
      try {
        await widget.controller.refresh();
      } catch (_) {
        // Continue gracefully in offline mode if server unreachable.
      }
    }
    if (!mounted) return;
    final canStart = widget.controller.canVisit || widget.controller.attendance != null || widget.controller.offline;
    if (!canStart) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Punch in to use visits.')));
      return;
    }
    final saved = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) => VisitForm(data: data, visit: visit),
      ),
    );
    if (saved == true && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            visit == null
                ? 'Visit punch-in confirmed.'
                : 'Visit punch-out confirmed.',
          ),
        ),
      );
    }
    await data.load();
  }

  Widget _buildSelfieButton({
    required String label,
    required IconData icon,
    required bool isDark,
    required Color accentColor,
    required Color bgColor,
    required Color borderColor,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(10),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7.5),
          decoration: BoxDecoration(
            color: bgColor,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: isDark ? accentColor.withValues(alpha: 0.3) : borderColor,
              width: 1.0,
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 14, color: accentColor),
              const SizedBox(width: 6),
              Text(
                label,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: accentColor,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('Visits'),
      actions: [
        IconButton(
          tooltip: 'Visit history',
          icon: const Icon(Icons.history_rounded),
          onPressed: () => Navigator.push(
            context,
            MaterialPageRoute<void>(
              builder: (_) => WorkspacePage(
                controller: widget.controller,
                feature: WorkFeature.visits,
              ),
            ),
          ),
        ),
        IconButton(
          tooltip: widget.controller.isDarkMode ? 'Light mode' : 'Dark mode',
          icon: Icon(
            widget.controller.isDarkMode
                ? Icons.light_mode_rounded
                : Icons.dark_mode_rounded,
          ),
          onPressed: () => widget.controller.toggleDarkMode(),
        ),
        IconButton(
          tooltip: 'Reload visits',
          onPressed: data.loading || data.saving ? null : data.load,
          icon: const Icon(Icons.refresh),
        ),
      ],
    ),
    floatingActionButton:
        data.active == null && !data.loading && data.rows.isEmpty
        ? FloatingActionButton.extended(
            onPressed: () => edit(null),
            icon: const Icon(Icons.add_location_alt_outlined),
            label: const Text('Visit punch in'),
          )
        : null,
    body: ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 100),
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Customer visits',
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                    letterSpacing: -0.4,
                    color: widget.controller.isDarkMode ? Colors.white : const Color(0xff0f172a),
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  '${data.rows.length} ${data.rows.length == 1 ? 'visit' : 'visits'} recorded today',
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                    color: widget.controller.isDarkMode ? const Color(0xff94a3b8) : const Color(0xff64748b),
                  ),
                ),
              ],
            ),
          ],
        ),

        if (data.active == null && !data.loading) ...[
          const SizedBox(height: 16),
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              gradient: const LinearGradient(
                colors: [Color(0xff16a34a), Color(0xff15803d)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xff16a34a).withValues(alpha: 0.28),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: () => edit(null),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 15),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.20),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(
                          Icons.add_business_rounded,
                          color: Colors.white,
                          size: 20,
                        ),
                      ),
                      const SizedBox(width: 14),
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Start Open Visit',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w700,
                                fontSize: 15.5,
                                letterSpacing: -0.2,
                              ),
                            ),
                            SizedBox(height: 2),
                            Text(
                              'Check in with client selfie & GPS location',
                              style: TextStyle(
                                color: Color(0xffdcfce7),
                                fontSize: 11.5,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const Icon(
                        Icons.arrow_forward_ios_rounded,
                        color: Colors.white,
                        size: 16,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 6),
        ],
        if (data.loading) const Padding(
          padding: EdgeInsets.symmetric(vertical: 8),
          child: LinearProgressIndicator(),
        ),
        if (data.error != null)
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Text(data.error!, style: const TextStyle(color: Colors.red)),
                TextButton(onPressed: data.load, child: const Text('Retry')),
              ],
            ),
          ),
        if (!data.loading && data.rows.isEmpty && data.error == null)
          Padding(
            padding: const EdgeInsets.all(32),
            child: Center(
              child: Column(
                children: [
                  Icon(
                    Icons.storefront_outlined,
                    size: 48,
                    color: widget.controller.isDarkMode ? const Color(0xff64748b) : const Color(0xff94a3b8),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    'No customer visits started today.',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      color: widget.controller.isDarkMode ? const Color(0xff94a3b8) : const Color(0xff64748b),
                    ),
                  ),
                ],
              ),
            ),
          ),
        const SizedBox(height: 12),
        for (final row in data.rows)
          Builder(
            builder: (context) {
              final isDark = widget.controller.isDarkMode;
              final isCompleted = row['checkOutUtc'] != null;
              final lat = ((row['inLatitude'] ?? row['latitude']) as num?)?.toDouble() ??
                  double.tryParse('');
              final lng = ((row['inLongitude'] ?? row['longitude']) as num?)?.toDouble() ??
                  double.tryParse('');
              final coordStr = (lat != null && lng != null)
                  ? '${lat.toStringAsFixed(4)}, ${lng.toStringAsFixed(4)}'
                  : '';
              final addressStr = cleanAddress('${row['address']}');

              return Container(
                margin: const EdgeInsets.only(bottom: 16),
                decoration: BoxDecoration(
                  color: isDark ? const Color(0xff1e2023) : Colors.white,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(
                    color: isDark
                        ? const Color(0xff2d3135)
                        : const Color(0xffe2e8f0),
                    width: 1.0,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: isDark ? 0.25 : 0.04),
                      blurRadius: 10,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Header Row: Icon + Shop Name + Status Badge
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            width: 44,
                            height: 44,
                            decoration: BoxDecoration(
                              color: isCompleted
                                  ? (isDark ? const Color(0xff064e3b) : const Color(0xffdcfce7))
                                  : (isDark ? const Color(0xff78350f) : const Color(0xfffef3c7)),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Icon(
                              Icons.storefront_rounded,
                              color: isCompleted
                                  ? const Color(0xff16a34a)
                                  : const Color(0xffd97706),
                              size: 24,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  row['shopName']?.toString() ?? 'Client visit',
                                  style: TextStyle(
                                    fontSize: 16.5,
                                    fontWeight: FontWeight.w700,
                                    letterSpacing: -0.3,
                                    color: isDark ? Colors.white : const Color(0xff0f172a),
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                const SizedBox(height: 3),
                                Row(
                                  children: [
                                    Container(
                                      width: 6,
                                      height: 6,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: isCompleted
                                            ? const Color(0xff16a34a)
                                            : const Color(0xffd97706),
                                      ),
                                    ),
                                    const SizedBox(width: 6),
                                    Text(
                                      row['kind'] == 'Regular' ? 'Retailer visit' : 'Open visit',
                                      style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.w500,
                                        color: isDark ? const Color(0xff94a3b8) : const Color(0xff64748b),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4.5),
                            decoration: BoxDecoration(
                              color: isCompleted
                                  ? (isDark ? const Color(0xff064e3b).withValues(alpha: 0.6) : const Color(0xffecfdf5))
                                  : (isDark ? const Color(0xff78350f).withValues(alpha: 0.6) : const Color(0xfffffbeb)),
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(
                                color: isCompleted
                                    ? const Color(0xff10b981).withValues(alpha: 0.3)
                                    : const Color(0xfff59e0b).withValues(alpha: 0.3),
                              ),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  isCompleted ? Icons.check_circle_rounded : Icons.pending_rounded,
                                  size: 12,
                                  color: isCompleted ? const Color(0xff059669) : const Color(0xffd97706),
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  isCompleted ? 'Completed' : 'In progress',
                                  style: TextStyle(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w700,
                                    color: isCompleted ? const Color(0xff059669) : const Color(0xffd97706),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),

                      // Time Strip: Clean human-readable
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 8),
                        decoration: BoxDecoration(
                          color: isDark ? const Color(0xff15181b) : const Color(0xfff1f5f9),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              Icons.schedule_rounded,
                              size: 14,
                              color: isDark ? const Color(0xff94a3b8) : const Color(0xff64748b),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                formatVisitTime(row['checkInUtc'], row['checkOutUtc']),
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                  color: isDark ? const Color(0xffcbd5e1) : const Color(0xff334155),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),

                      // Location & Coordinates
                      if (addressStr.isNotEmpty || coordStr.isNotEmpty) ...[
                        const SizedBox(height: 10),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Padding(
                              padding: EdgeInsets.only(top: 2),
                              child: Icon(
                                Icons.place_rounded,
                                size: 15,
                                color: Color(0xff0284c7),
                              ),
                            ),
                            const SizedBox(width: 7),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  if (addressStr.isNotEmpty)
                                    Text(
                                      addressStr,
                                      style: TextStyle(
                                        fontSize: 12.5,
                                        height: 1.35,
                                        color: isDark ? const Color(0xffe2e8f0) : const Color(0xff334155),
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  if (coordStr.isNotEmpty) ...[
                                    if (addressStr.isNotEmpty) const SizedBox(height: 2),
                                    Text(
                                      coordStr,
                                      style: const TextStyle(
                                        fontSize: 11,
                                        fontFamily: 'monospace',
                                        color: Color(0xff0284c7),
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ],
                                ],
                              ),
                            ),
                          ],
                        ),
                      ],

                      // Owner / Mobile
                      if (row['ownerName'] != null || row['mobile'] != null) ...[
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            Icon(
                              Icons.person_outline_rounded,
                              size: 15,
                              color: isDark ? const Color(0xff94a3b8) : const Color(0xff64748b),
                            ),
                            const SizedBox(width: 7),
                            Expanded(
                              child: Text(
                                [
                                  if (row['ownerName'] != null && '${row['ownerName']}'.trim().isNotEmpty)
                                    '${row['ownerName']}',
                                  if (row['mobile'] != null && '${row['mobile']}'.trim().isNotEmpty)
                                    '${row['mobile']}',
                                ].join(' • '),
                                style: TextStyle(
                                  fontSize: 12.5,
                                  fontWeight: FontWeight.w500,
                                  color: isDark ? const Color(0xffe2e8f0) : const Color(0xff475569),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],

                      // Remarks Note Box
                      if (row['remark'] != null && '${row['remark']}'.trim().isNotEmpty) ...[
                        const SizedBox(height: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                          decoration: BoxDecoration(
                            color: isDark ? const Color(0xff25282c) : const Color(0xfff8fafc),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(
                              color: isDark ? const Color(0xff33383f) : const Color(0xffe2e8f0),
                              width: 0.8,
                            ),
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Icon(
                                Icons.chat_bubble_outline_rounded,
                                size: 13,
                                color: isDark ? const Color(0xff94a3b8) : const Color(0xff64748b),
                              ),
                              const SizedBox(width: 6),
                              Expanded(
                                child: Text(
                                  'Note: ${row['remark']}',
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: isDark ? const Color(0xffcbd5e1) : const Color(0xff475569),
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],

                      // Ongoing Duration if active
                      if (!isCompleted) VisitDuration(row: row),

                      const SizedBox(height: 14),

                      // Action Buttons Row (Selfies & Punch Out)
                      Row(
                        children: [
                          _buildSelfieButton(
                            label: 'Arrival selfie',
                            icon: Icons.photo_camera_rounded,
                            isDark: isDark,
                            accentColor: const Color(0xff0284c7),
                            bgColor: isDark ? const Color(0xff0c2a42) : const Color(0xfff0f9ff),
                            borderColor: const Color(0xffbae6fd),
                            onTap: () => Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (_) => AttendanceSelfiePage.visit(
                                  controller: widget.controller,
                                  visitId: visitIdOf(row),
                                  visitRecord: row,
                                ),
                              ),
                            ),
                          ),
                          if (hasDeparturePhoto(row)) ...[
                            const SizedBox(width: 8),
                            _buildSelfieButton(
                              label: 'Departure selfie',
                              icon: Icons.photo_camera_rounded,
                              isDark: isDark,
                              accentColor: const Color(0xff7c3aed),
                              bgColor: isDark ? const Color(0xff2e1065) : const Color(0xfffaf5ff),
                              borderColor: const Color(0xffddd6fe),
                              onTap: () => Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (_) => AttendanceSelfiePage.visit(
                                    controller: widget.controller,
                                    visitId: visitIdOf(row),
                                    visitRecord: row,
                                    phase: 'out',
                                  ),
                                ),
                              ),
                            ),
                          ],
                          if (!isCompleted) ...[
                            const SizedBox(width: 8),
                            Expanded(
                              child: FilledButton.icon(
                                style: FilledButton.styleFrom(
                                  backgroundColor: const Color(0xff0284c7),
                                  foregroundColor: Colors.white,
                                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  elevation: 0,
                                ),
                                onPressed: (data.saving || !visitCheckoutReady(row, DateTime.now()))
                                    ? null
                                    : () => edit(row),
                                icon: const Icon(Icons.check_circle_outline_rounded, size: 16),
                                label: const Text(
                                  'Punch Out',
                                  style: TextStyle(
                                    fontSize: 12.5,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
      ],
    ),
  );
}

class VisitDuration extends StatelessWidget {
  final Json row;
  const VisitDuration({super.key, required this.row});
  @override
  Widget build(BuildContext context) {
    final start = DateTime.tryParse('${row['checkInUtc']}');
    if (start == null) {
      return const SizedBox();
    }
    final seconds = DateTime.now()
        .toUtc()
        .difference(start.toUtc())
        .inSeconds
        .clamp(0, 864000);
    final earliest = DateTime.tryParse('${row['earliestCheckoutUtc']}');
    final remaining =
        earliest?.toUtc().difference(DateTime.now().toUtc()).inSeconds ?? 0;
    final elapsed =
        '${(seconds ~/ 3600).toString().padLeft(2, '0')}:${((seconds % 3600) ~/ 60).toString().padLeft(2, '0')}:${(seconds % 60).toString().padLeft(2, '0')}';
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Visit duration  $elapsed',
            style: const TextStyle(
              fontWeight: FontWeight.w700,
              color: Color(0xff1c6799),
            ),
          ),
          if (remaining > 0)
            Text(
              'Punch-out available in ${(remaining / 60).ceil()} minute(s).',
              style: const TextStyle(fontSize: 12, color: Color(0xff64748b)),
            ),
        ],
      ),
    );
  }
}

class VisitForm extends StatefulWidget {
  final VisitsData data;
  final Json? visit;
  const VisitForm({super.key, required this.data, this.visit});
  @override
  State<VisitForm> createState() => _VisitFormState();
}

class _VisitFormState extends State<VisitForm> {
  final form = GlobalKey<FormState>();
  final shop = TextEditingController(),
      place = TextEditingController(),
      address = TextEditingController(),
      owner = TextEditingController(),
      mobile = TextEditingController(),
      remark = TextEditingController(),
      orderRemark = TextEditingController(),
      otherRemark = TextEditingController(),
      search = TextEditingController();
  String kind = 'Open', lead = 'Y';
  Json? retailer;
  List<Json> retailers = [];
  bool saving = false, searching = false, _fetchingLocation = false;
  String? error;
  bool get finish => widget.visit != null;
  bool get open => (finish ? widget.visit!['kind'] : kind) == 'Open';

  @override
  void initState() {
    super.initState();
    if (widget.data.session.lastLocation != null) {
      final addr = cleanAddress(widget.data.session.lastLocation!['address']?.toString());
      if (addr.isNotEmpty && addr != 'Recorded via GPS') {
        address.text = addr;
      }
    }
    // Auto-detect and populate Current Address & Place on screen open!
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        _refreshLocation();
        if (!widget.data.session.offline) {
          widget.data.session.refreshMenus().catchError((Object _) {});
        }
      }
    });
    if (!finish && kind == 'Regular') {
      findRetailers();
    }
  }

  Future<void> _resolveAddressFromCoords(double lat, double lng) async {
    try {
      final places = await Geocoding()
          .placemarkFromCoordinates(lat, lng)
          .timeout(const Duration(seconds: 4));
      if (places.isNotEmpty && mounted) {
        final p = places.first;
        final addr = formatPlacemarkAddress(p);
        TrackyuAddressCache.put(lat, lng, addr);
        if (addr.isNotEmpty && mounted) {
          if (address.text.isEmpty || address.text == 'Recorded via GPS') {
            setState(() {
              address.text = addr;
            });
          }
        }
        if (place.text.isEmpty && mounted) {
          final placeStr = [p.subLocality ?? p.name, p.locality]
              .whereType<String>()
              .map((s) => s.trim())
              .where((s) => s.isNotEmpty)
              .toSet()
              .join(', ');
          if (placeStr.isNotEmpty) {
            setState(() {
              place.text = placeStr;
            });
          }
        }
      }
    } catch (_) {}
  }

  @override
  void dispose() {
    for (final c in [
      shop,
      place,
      address,
      owner,
      mobile,
      remark,
      orderRemark,
      otherRemark,
      search,
    ]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _refreshLocation() async {
    if (_fetchingLocation || saving) return;
    setState(() => _fetchingLocation = true);
    try {
      // 1. Check instant fix from DutyTracker status or session
      try {
        final status = await DutyTracker.status();
        final fix = status['lastPoint'] is Map
            ? status['lastPoint'] as Map
            : widget.data.session.lastLocation;
        if (fix != null &&
            fix['latitude'] != null &&
            fix['longitude'] != null) {
          final lat = (fix['latitude'] as num?)?.toDouble() ?? double.tryParse('${fix['latitude']}');
          final lng = (fix['longitude'] as num?)?.toDouble() ?? double.tryParse('${fix['longitude']}');
          if (lat != null && lng != null) {
            await _resolveAddressFromCoords(lat, lng);
          }
        }
      } catch (_) {}

      // 2. Fetch fresh live fix from GPS + Cellular
      final loc = await widget.data.session.locate();
      final lat = (loc['latitude'] as num?)?.toDouble();
      final lng = (loc['longitude'] as num?)?.toDouble();
      if (lat != null && lng != null) {
        await _resolveAddressFromCoords(lat, lng);
      }
    } catch (_) {}
    if (mounted) setState(() => _fetchingLocation = false);
  }

  Future<void> findRetailers() async {
    if (searching || saving) return;
    setState(() {
      searching = true;
      error = null;
    });
    try {
      final rows = await widget.data.search(search.text);
      if (mounted) setState(() => retailers = rows);
    } catch (e) {
      if (mounted) {
        setState(
          () => error = e is ApiFailure
              ? e.toString()
              : 'Unable to load retailers. Retry.',
        );
      }
    } finally {
      if (mounted) setState(() => searching = false);
    }
  }

  Future<void> _discardVisit() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Discard In-Progress Visit?'),
        content: Text(
          'Are you sure you want to cancel and remove "${widget.visit!['shopName'] ?? 'this visit'}"?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Keep Visit'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: const Color(0xffef4444),
            ),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Discard'),
          ),
        ],
      ),
    );
    if (confirm != true || !mounted) return;
    setState(() => saving = true);
    try {
      await widget.data.discard(widget.visit!);
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) {
        setState(() => error = e.toString());
      }
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  Future<void> submit() async {
    if (saving || !form.currentState!.validate()) return;
    if (!finish && kind == 'Regular' && retailer == null) {
      setState(() => error = 'Search and choose your assigned retailer.');
      return;
    }
    setState(() {
      saving = true;
      error = null;
    });
    try {
      final saved = await widget.data.save(
        finish: finish,
        fields: finish
            ? {
                'id': widget.visit!['id'],
                'kind': widget.visit!['kind'],
                'version': widget.visit!['version'],
                'remark': remark.text.trim(),
                if (open) ...{
                  'ownerName': owner.text.trim(),
                  'mobile': mobile.text.trim(),
                  'lead': lead,
                },
                if (!open) ...{
                  'orderRemark': orderRemark.text.trim(),
                  'otherRemark': otherRemark.text.trim(),
                },
              }
            : {
                'kind': kind,
                'address': cleanAddress(address.text),
                if (kind == 'Regular') ...{
                  'retailerId': retailer!['id'],
                  'shopName': retailer!['name'],
                  'placeName': retailer!['place'],
                },
                if (open) ...{
                  'shopName': shop.text.trim(),
                  'placeName': place.text.trim(),
                },
              },
      );
      if (saved && mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) {
        setState(
          () => error = e is ApiFailure
              ? e.toString()
              : 'Unable to save. Reload visits to check whether this request reached your workspace.',
        );
      }
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  Widget field(
    TextEditingController c,
    String label,
    int max, {
    bool required = true,
    bool phone = false,
    int maxLines = 1,
    IconData? icon,
    Widget? suffix,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final inputBg = isDark ? const Color(0xff181a1f) : const Color(0xfff8fafc);
    final inputBorder = isDark ? const Color(0xff2d333b) : const Color(0xffcbd5e1);
    final inputFocusBorder = isDark ? const Color(0xff4ade80) : const Color(0xff16a34a);
    final inputTextColor = isDark ? const Color(0xfff1f5f9) : const Color(0xff0f172a);
    final labelColor = isDark ? const Color(0xff94a3b8) : const Color(0xff64748b);
    final iconColor = isDark ? const Color(0xff94a3b8) : const Color(0xff64748b);

    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: TextFormField(
        controller: c,
        enabled: !saving,
        maxLength: max,
        buildCounter:
            (_, {required currentLength, required isFocused, maxLength}) => null,
        maxLines: maxLines,
        keyboardType: phone
            ? TextInputType.phone
            : (maxLines > 1 ? TextInputType.multiline : TextInputType.text),
        style: TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.w500,
          color: inputTextColor,
        ),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: labelColor, fontSize: 14),
          floatingLabelStyle: TextStyle(
            color: inputFocusBorder,
            fontWeight: FontWeight.w600,
          ),
          prefixIcon: icon != null
              ? Icon(icon, size: 22, color: iconColor)
              : null,
          suffixIcon: suffix,
          filled: true,
          fillColor: inputBg,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 14,
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(color: inputBorder),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(color: inputBorder),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(color: inputFocusBorder, width: 1.8),
          ),
          errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xffef4444)),
          ),
        ),
        validator: (v) {
          final text = (v ?? '').trim();
          if (required && text.length < (phone ? 10 : 2)) {
            return phone ? 'Enter a ten-digit mobile number.' : 'Enter $label.';
          }
          if (phone && !RegExp(r'^\d{10}$').hasMatch(text)) {
            return 'Enter a ten-digit mobile number.';
          }
          return null;
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return PopScope(
      canPop: !saving,
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            finish
                ? 'Punch out - ${widget.visit!['shopName']}'
                : 'Visit punch in',
          ),
        ),
        body: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 620),
            child: Form(
              key: form,
              child: ListView(
                padding: const EdgeInsets.all(20),
                children: [
                  Container(
                    margin: const EdgeInsets.only(bottom: 20),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: isDark
                          ? (finish
                              ? const Color(0x220284c7)
                              : const Color(0x2216a34a))
                          : (finish
                              ? const Color(0xfff0f9ff)
                              : const Color(0xfff0fdf4)),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: isDark
                            ? (finish
                                ? const Color(0x4438bdf8)
                                : const Color(0x444ade80))
                            : (finish
                                ? const Color(0xffbae6fd)
                                : const Color(0xffbbf7d0)),
                      ),
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: finish
                                ? const Color(0xff0284c7)
                                : const Color(0xff16a34a),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Icon(
                            finish
                                ? Icons.business_center_rounded
                                : Icons.storefront_rounded,
                            color: Colors.white,
                            size: 24,
                          ),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                finish
                                    ? (widget.visit!['shopName']?.toString() ??
                                          'Visit Checkout')
                                    : 'Open visit',
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w700,
                                  color: isDark
                                      ? (finish
                                          ? const Color(0xff38bdf8)
                                          : const Color(0xff4ade80))
                                      : (finish
                                          ? const Color(0xff0369a1)
                                          : const Color(0xff14532d)),
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                finish
                                    ? 'Complete visit & check out'
                                    : 'Customer check-in with GPS',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: isDark
                                      ? const Color(0xff94a3b8)
                                      : (finish
                                          ? const Color(0xff0284c7)
                                          : const Color(0xff15803d)),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (!finish) ...[
                    if (!open) ...[
                      TextField(
                        controller: search,
                        enabled: !saving,
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w500,
                          color: isDark
                              ? const Color(0xfff1f5f9)
                              : const Color(0xff0f172a),
                        ),
                        decoration: InputDecoration(
                          labelText: 'Retailer name or code',
                          labelStyle: TextStyle(
                            color: isDark
                                ? const Color(0xff94a3b8)
                                : const Color(0xff64748b),
                          ),
                          filled: true,
                          fillColor: isDark
                              ? const Color(0xff181a1f)
                              : const Color(0xfff8fafc),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: BorderSide(
                              color: isDark
                                  ? const Color(0xff2d333b)
                                  : const Color(0xffcbd5e1),
                            ),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: BorderSide(
                              color: isDark
                                  ? const Color(0xff2d333b)
                                  : const Color(0xffcbd5e1),
                            ),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: BorderSide(
                              color: isDark
                                  ? const Color(0xff4ade80)
                                  : const Color(0xff16a34a),
                              width: 1.8,
                            ),
                          ),
                        ),
                      ),
                    const SizedBox(height: 8),
                    OutlinedButton.icon(
                      onPressed: searching || saving ? null : findRetailers,
                      icon: const Icon(Icons.search),
                      label: Text(
                        searching ? 'Searching…' : 'Find assigned retailers',
                      ),
                    ),
                    if (!searching && retailers.isEmpty && retailer == null)
                      const Padding(
                        padding: EdgeInsets.symmetric(vertical: 12),
                        child: Text(
                          'No customers found. Try another search or contact your administrator for assignments.',
                        ),
                      ),
                    if (retailer != null)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        child: Text(
                          'Selected: ${retailer!['name']}',
                          style: const TextStyle(fontWeight: FontWeight.w700),
                        ),
                      ),
                    for (final row in retailers)
                      ListTile(
                        title: Text(row['name']?.toString() ?? ''),
                        subtitle: Text(row['address']?.toString() ?? ''),
                        selected: retailer?['id'] == row['id'],
                        onTap: saving
                            ? null
                            : () => setState(() {
                                retailer = row;
                                address.text = row['address']?.toString() ?? '';
                                retailers = [];
                              }),
                      ),
                    const SizedBox(height: 14),
                  ],
                  if (open) ...[
                    field(
                      shop,
                      'Shop name',
                      100,
                      icon: Icons.storefront_outlined,
                    ),
                    field(
                      place,
                      'Place',
                      50,
                      icon: Icons.location_city_outlined,
                    ),
                  ],
                  field(
                    address,
                    open ? 'Shop address' : 'Shop / Client address',
                    500,
                    maxLines: 2,
                    icon: Icons.pin_drop_outlined,
                    suffix: IconButton(
                      tooltip: 'Refresh GPS address',
                      icon: _fetchingLocation
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Icon(
                              Icons.my_location_rounded,
                              size: 20,
                              color: Color(0xff16a34a),
                            ),
                      onPressed: _fetchingLocation ? null : _refreshLocation,
                    ),
                  ),
                ],
                if (finish) ...[
                  if (open) ...[
                    field(owner, 'Owner name', 50, icon: Icons.person_outline),
                    field(
                      mobile,
                      'Mobile',
                      10,
                      phone: true,
                      icon: Icons.phone_outlined,
                    ),
                    Padding(
                      padding: const EdgeInsets.only(bottom: 16),
                      child: DropdownButtonFormField<String>(
                        isExpanded: true,
                        initialValue: lead,
                        dropdownColor: isDark ? const Color(0xff1e2227) : Colors.white,
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w500,
                          color: isDark ? const Color(0xfff1f5f9) : const Color(0xff0f172a),
                        ),
                        decoration: InputDecoration(
                          labelText: 'Lead status',
                          labelStyle: TextStyle(
                            color: isDark ? const Color(0xff94a3b8) : const Color(0xff64748b),
                          ),
                          prefixIcon: Icon(
                            Icons.star_outline_rounded,
                            size: 22,
                            color: isDark ? const Color(0xff94a3b8) : const Color(0xff64748b),
                          ),
                          filled: true,
                          fillColor: isDark ? const Color(0xff181a1f) : const Color(0xfff8fafc),
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 14,
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: BorderSide(
                              color: isDark ? const Color(0xff2d333b) : const Color(0xffcbd5e1),
                            ),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: BorderSide(
                              color: isDark ? const Color(0xff2d333b) : const Color(0xffcbd5e1),
                            ),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: BorderSide(
                              color: isDark ? const Color(0xff4ade80) : const Color(0xff16a34a),
                              width: 1.8,
                            ),
                          ),
                        ),
                        items: const [
                          DropdownMenuItem(
                            value: 'Y',
                            child: Text('Interested'),
                          ),
                          DropdownMenuItem(
                            value: 'N',
                            child: Text('Not interested'),
                          ),
                          DropdownMenuItem(value: 'L', child: Text('Later')),
                        ],
                        onChanged: saving
                            ? null
                            : (v) => setState(() => lead = v!),
                      ),
                    ),
                  ],
                  field(
                    remark,
                    'Visit remark',
                    500,
                    maxLines: 2,
                    icon: Icons.notes_outlined,
                  ),
                  if (!open) ...[
                    field(
                      orderRemark,
                      'Order remark',
                      500,
                      required: false,
                      maxLines: 2,
                      icon: Icons.shopping_cart_outlined,
                    ),
                    field(
                      otherRemark,
                      'Other remark',
                      500,
                      required: false,
                      maxLines: 2,
                      icon: Icons.chat_bubble_outline,
                    ),
                  ],
                ],
                if (error != null)
                  Container(
                    margin: const EdgeInsets.only(bottom: 16),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: isDark ? const Color(0x22ef4444) : const Color(0xfffef2f2),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: isDark ? const Color(0x44ef4444) : const Color(0xfffecaca),
                      ),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Icon(
                          Icons.error_outline_rounded,
                          color: Color(0xffef4444),
                          size: 20,
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            error!,
                            style: TextStyle(
                              color: isDark ? const Color(0xfffca5a5) : const Color(0xffb91c1c),
                              fontSize: 13,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  height: 52,
                  child: ElevatedButton.icon(
                    onPressed: saving ? null : submit,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: finish
                          ? const Color(0xff0284c7)
                          : const Color(0xff16a34a),
                      foregroundColor: Colors.white,
                      elevation: 1,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                    icon: saving
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.white,
                            ),
                          )
                        : Icon(
                            finish
                                ? Icons.check_circle_outline
                                : Icons.camera_alt_outlined,
                            size: 22,
                          ),
                    label: Text(
                      saving
                          ? 'Please wait…'
                          : finish
                          ? (open ? 'Selfie & punch out' : 'Visit punch out')
                          : 'Photo & punch in',
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ),
                if (finish) ...[
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: OutlinedButton.icon(
                      style: OutlinedButton.styleFrom(
                        foregroundColor: const Color(0xffef4444),
                        side: const BorderSide(color: Color(0xffef4444)),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                      onPressed: saving ? null : _discardVisit,
                      icon: const Icon(Icons.delete_outline_rounded, size: 20),
                      label: const Text(
                        'Discard / Cancel in-progress visit',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ),
                ],
                const SizedBox(height: 12),
                Center(
                  child: TextButton.icon(
                    onPressed: saving
                        ? null
                        : () async {
                            setState(() {
                              saving = true;
                              error = null;
                            });
                            try {
                              await widget.data.session.refreshMenus();
                              await widget.data.load();
                              if (mounted && context.mounted) {
                                setState(() => error = null);
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text(
                                      'Visits and permissions updated.',
                                    ),
                                    duration: Duration(seconds: 2),
                                  ),
                                );
                              }
                            } catch (e) {
                              if (mounted) setState(() => error = e.toString());
                            } finally {
                              if (mounted) setState(() => saving = false);
                            }
                          },
                    icon: const Icon(Icons.refresh_rounded, size: 16),
                    label: const Text('Reload visits'),
                    style: TextButton.styleFrom(
                      foregroundColor: isDark
                          ? const Color(0xff94a3b8)
                          : const Color(0xff64748b),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    ),
  );
  }
}
