import 'visit_media.dart';
import 'local_workspace.dart';
import 'timeline_reconciliation.dart';
import 'address_cache.dart';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/rendering.dart' show ScrollCacheExtent;
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'api.dart';
import 'controller.dart';
import 'duty_tracking.dart';
import 'legacy_map.dart';
import 'route_presentation.dart';
import 'error_logger.dart';

class TrackingStatusCard extends StatefulWidget {
  final TrackyuController controller;
  const TrackingStatusCard({super.key, required this.controller});
  @override
  State<TrackingStatusCard> createState() => _TrackingStatusCardState();
}

class _TrackingStatusCardState extends State<TrackingStatusCard> {
  Timer? timer;
  Json state = {};
  @override
  void initState() {
    super.initState();
    TrackyuAddressCache.init();
    load();
    timer = Timer.periodic(const Duration(seconds: 5), (_) => load());
  }

  Future<void> load() async {
    try {
      final next = await DutyTracker.status();
      final own =
          next['userId'] == widget.controller.employeeId &&
          next['baseUrl'] == widget.controller.api.baseUrl;
      final target = own
          ? next
          : {
              'status': 'Tracking starts at your punch-in',
              'pendingCount': 0,
            };
      if (mounted && (state['status'] != target['status'] || state['pendingCount'] != target['pendingCount'])) {
        setState(() => state = target);
      }
    } catch (_) {
      if (mounted) {
        setState(
          () =>
              state = {'status': 'Open app settings to check tracking access'},
        );
      }
    }
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!DutyTracker.supported) return const SizedBox.shrink();
    final isDark = widget.controller.isDarkMode;
    final hasLocationPermission =
        state['precisePermission'] == true &&
        state['backgroundPermission'] == true;

    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Material(
          color: isDark ? const Color(0xff1e1e1e) : Colors.white,
          borderRadius: BorderRadius.circular(20),
          child: InkWell(
            borderRadius: BorderRadius.circular(20),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute<void>(
                builder: (_) => DutyRoutePage(controller: widget.controller),
              ),
            ),
            child: Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: isDark
                      ? const Color(0xff2d3135)
                      : const Color(0xffe2e8f0),
                ),
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: isDark
                          ? const Color(0xff0f172a)
                          : const Color(0xffe0f2fe),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(
                      Icons.route_rounded,
                      color: isDark
                          ? const Color(0xff38bdf8)
                          : const Color(0xff0284c7),
                      size: 24,
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'My route & timeline',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                            color: isDark
                                ? Colors.white
                                : const Color(0xff0f172a),
                          ),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          widget.controller.onDuty
                              ? 'Recording your route'
                              : (state['status'] as String? ??
                                    'Tracking starts at your punch-in'),
                          style: TextStyle(
                            fontSize: 12,
                            color: isDark
                                ? const Color(0xff94a3b8)
                                : const Color(0xff64748b),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Icon(
                    Icons.arrow_forward_ios_rounded,
                    size: 16,
                    color: isDark
                        ? const Color(0xff64748b)
                        : const Color(0xff94a3b8),
                  ),
                ],
              ),
            ),
          ),
        ),
        if (state['batteryUnrestricted'] == false) ...[
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: isDark ? const Color(0xff451a03) : const Color(0xfffffbeb),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: isDark ? const Color(0xffb45309) : const Color(0xfffde68a),
              ),
            ),
            child: Row(
              children: [
                Icon(
                  Icons.battery_alert_rounded,
                  color: isDark ? const Color(0xfffbbf24) : const Color(0xffd97706),
                  size: 22,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Battery is Restricted by Phone OS',
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          color: isDark ? const Color(0xfffef3c7) : const Color(0xff92400e),
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        'Set battery to "Unrestricted" so Android never stops your GPS in background.',
                        style: TextStyle(
                          fontSize: 11,
                          color: isDark ? const Color(0xfffde68a) : const Color(0xffb45309),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                FilledButton.tonal(
                  onPressed: DutyTracker.batterySettings,
                  style: FilledButton.styleFrom(
                    visualDensity: VisualDensity.compact,
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  ),
                  child: const Text('Allow'),
                ),
              ],
            ),
          ),
        ],
        if (hasLocationPermission) ...[
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
            decoration: BoxDecoration(
              color: isDark ? const Color(0xff052e16) : const Color(0xfff0fdf4),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: isDark
                    ? const Color(0xff166534)
                    : const Color(0xffbbf7d0),
              ),
            ),
            child: Row(
              children: [
                const Text('😊', style: TextStyle(fontSize: 16)),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Location permission active',
                    style: TextStyle(
                      color: isDark
                          ? const Color(0xff4ade80)
                          : const Color(0xff166534),
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                Icon(
                  Icons.check_circle,
                  size: 16,
                  color: isDark
                      ? const Color(0xff4ade80)
                      : const Color(0xff16a34a),
                ),
              ],
            ),
          ),
        ],
      ],
    );
  }
}

class DutyRoutePage extends StatefulWidget {
  final TrackyuController controller;
  const DutyRoutePage({super.key, required this.controller});
  @override
  State<DutyRoutePage> createState() => _DutyRoutePageState();
}

class _DutyRoutePageState extends State<DutyRoutePage> {
  DateTime date = DateTime.parse(businessDay(DateTime.now()));
  int _activeLoadSeq = 0;
  DateTime? _loadedDate;
  bool loading = true,
      _readingRoute = false,
      _followPosition = true,
      _requestingFix = false,
      _trackingActive = false;
  int _selectedTab = 0;
  String? error;
  String? _nativeDay;
  List<Json> _nativePoints = [];
  String? selectedNodeId;
  Json data = {};
  Json? _position;
  List<List<Json>> segments = [];
  final mapController = MapController();
  final Map<String, String> _addressCache = {};
  bool _fullscreenMap = false;
  Timer? timer;
  late String _owner;
  bool get _sameSession =>
      _owner ==
      '${widget.controller.api.baseUrl}|${widget.controller.employeeId}';
  bool get _today => LocalWorkspace.day(date) == widget.controller.localDay;
  bool get _darkMode => widget.controller.isDarkMode;
  bool get _current =>
      _today &&
      widget.controller.onDuty &&
      isCurrentFix(_position, DateTime.now(), tracking: _trackingActive);
  String get _positionLabel =>
      _current ? 'You are here' : 'Last known location';
  @override
  void initState() {
    super.initState();
    TrackyuAddressCache.init();
    _owner = '${widget.controller.api.baseUrl}|${widget.controller.employeeId}';
    widget.controller.addListener(_sessionChanged);
    load();
    timer = Timer.periodic(const Duration(seconds: 15), (_) {
      if (_today) load(silent: true);
    });
  }

  void _sessionChanged() {
    if (!mounted) return;
    if (!_sameSession) {
      segments = [];
      data = {};
      _position = null;
    }
    setState(() {});
  }

  @override
  void dispose() {
    timer?.cancel();
    widget.controller.removeListener(_sessionChanged);
    mapController.dispose();
    super.dispose();
  }

  Future<void> _resolveMissingAddresses([List<Json>? currentStops]) async {
    final selected = date;
    if (!mounted || !_sameSession || widget.controller.offline) return;

    // 1. Prioritize Halts/Stops first
    final rawStops = currentStops ?? ((data['route'] as Map?)?['stops'] as List? ?? []);
    for (final s in rawStops) {
      if (!mounted || date != selected || !_sameSession || widget.controller.offline) return;
      final pt = safeLatLng(s['latitude'], s['longitude']);
      if (pt == null) continue;
      if (TrackyuAddressCache.get(pt.latitude, pt.longitude) != null) continue;
      try {
        final addr = await TrackyuAddressCache.reverseGeocode(pt.latitude, pt.longitude);
        if (addr != null && mounted && date == selected) {
          setState(() {});
        }
      } catch (_) {}
    }

    // 2. Recent position
    if (_position != null) {
      final pt = routeCoordinate(_position);
      if (pt != null && TrackyuAddressCache.get(pt.latitude, pt.longitude) == null) {
        try {
          final addr = await TrackyuAddressCache.reverseGeocode(pt.latitude, pt.longitude);
          if (addr != null && mounted && date == selected) {
            setState(() {});
          }
        } catch (_) {}
      }
    }

    // 3. Movement segment start/ends
    for (final seg in segments) {
      if (!mounted || date != selected || !_sameSession || widget.controller.offline) return;
      if (seg.isEmpty) continue;
      final pt = routeCoordinate(seg.first);
      if (pt != null && TrackyuAddressCache.get(pt.latitude, pt.longitude) == null) {
        try {
          final addr = await TrackyuAddressCache.reverseGeocode(pt.latitude, pt.longitude);
          if (addr != null && mounted && date == selected) {
            setState(() {});
          }
        } catch (_) {}
      }
    }
  }
      Future<void> load({bool silent = false}) async {
    if (!mounted || !_sameSession || _readingRoute) return;
    final currentSeq = ++_activeLoadSeq;
    _readingRoute = true;
    final selected = date;
    if (!silent && segments.isEmpty) {
      setState(() => loading = true);
    }
    try {
      final day =
          '${selected.year}-${selected.month.toString().padLeft(2, '0')}-${selected.day.toString().padLeft(2, '0')}';
      String? warning;

      // Phase 1: Instant cache-first render from local storage (0ms UI lag)
      try {
        final cachedRecord = await widget.controller.localDayData(day);
        final cachedVisits = await widget.controller.scopedVisitCache();
        final cachedNative = await DutyTracker.status();
        if (mounted && _sameSession && date == selected && currentSeq == _activeLoadSeq) {
          if (cachedRecord.isNotEmpty || cachedVisits.isNotEmpty || (_nativeDay == day && _nativePoints.isNotEmpty)) {
            _applyRoute(selected, day, cachedNative, cachedRecord, _nativeDay == day ? _nativePoints : [], cachedVisits);
            loading = false;
            setState(() {});
          }
        }
      } catch (_) {}

      // Phase 2: Decoupled independent background fetches with deduplication & stale-response guard
      Map<String, dynamic> record = {};
      Map<String, dynamic> native = {};
      dynamic visitCache = <Json>[];

      try {
        native = await DutyTracker.status().timeout(const Duration(seconds: 4));
      } catch (_) {}

      try {
        visitCache = await widget.controller.scopedVisitCache().timeout(const Duration(seconds: 4));
      } catch (_) {}

      try {
        record = await widget.controller.routeDayData(day).timeout(const Duration(seconds: 10));
      } catch (exception, stack) {
        warning = 'Some phone history is still unavailable. Showing saved details; tap refresh to retry.';
        unawaited(ErrorLogger.record(exception, stack, context: 'DutyRoutePage.summary', notifyUser: false));
      }

      if (!mounted || !_sameSession || date != selected || currentSeq != _activeLoadSeq) return;

      void publish(List<Json> local) {
        if (!mounted || !_sameSession || date != selected || currentSeq != _activeLoadSeq) return;
        _applyRoute(selected, day, native.isNotEmpty ? native : data, record.isNotEmpty ? record : data, local, visitCache);
        error = warning ?? error;
        setState(() => loading = false);
      }

      publish(_nativeDay == day ? _nativePoints : []);

      // Phase 3: Paginated GPS route samples with lifecycle cancellation
      try {
        final local = await DutyTracker.route(
          widget.controller.employeeId,
          selected,
          baseUrl: widget.controller.api.baseUrl,
          fullResolution: true,
          pageSize: 1000,
          onPage: (points) {
            if (!mounted || !_sameSession || date != selected || currentSeq != _activeLoadSeq) return;
            final prior = _nativeDay == day ? _nativePoints : <Json>[];
            _nativeDay = day;
            _nativePoints = mergePoints(
              [...prior, ...points],
              day,
              widget.controller.employeeId,
              widget.controller.api.baseUrl,
            );
            publish(_nativePoints);
          },
          isCancelled: () => !mounted || !_sameSession || date != selected || currentSeq != _activeLoadSeq,
        );

        if (mounted && _sameSession && date == selected && currentSeq == _activeLoadSeq) {
          _nativeDay = day;
          _nativePoints = local;
          publish(local);
        }
      } catch (exception, stack) {
        unawaited(ErrorLogger.record(exception, stack, context: 'DutyRoutePage.gps', notifyUser: false));
      }

      if (mounted && _sameSession && date == selected && currentSeq == _activeLoadSeq && warning != null) {
        setState(() => error = warning);
      }
    } catch (exception, stack) {
      if (mounted && _sameSession && date == selected && currentSeq == _activeLoadSeq) {
        error = 'Unable to read phone data. Retry after checking storage.';
        ErrorLogger.record(exception, stack, context: 'DutyRoutePage.load');
      }
    } finally {
      _readingRoute = false;
      if (mounted && currentSeq == _activeLoadSeq) {
        setState(() => loading = false);
        if (date != selected) unawaited(load());
      }
    }
  }

  void _applyRoute(
    DateTime selected,
    String day,
    Json native,
    Json record,
    List<Json> local,
    dynamic visitCache,
  ) {
    final report = record['report'] is Map
        ? Map<String, dynamic>.from(record['report'])
        : <String, dynamic>{};
    final owner = widget.controller.employeeId,
        baseUrl = widget.controller.api.baseUrl;
    if (!rowBelongs(report, owner, baseUrl)) {
      throw const FormatException('Cached report owner mismatch');
    }
    // No network dependency: server history arrives only through explicit restore and durable sync.
    // Full, media-free projection + raw paged native samples feed calculations, never the map preview.
    final savedPoints = rowsOf(report['recordedPoints']);
    final serverSegments =
        (report['route'] is Map && report['route']['segments'] is List)
        ? (report['route']['segments'] as List).whereType<List>().toList()
        : <List>[];
    final normalizedSegments = <Json>[];
    for (final segment in serverSegments) {
      final points = rowsOf(segment);
      for (var i = 0; i < points.length; i++) {
        normalizedSegments.add({...points[i], if (i == 0) 'breakBefore': true});
      }
    }
    final points = mergePoints(
      [
        ...savedPoints,
        ...normalizedSegments,
        ...local.map((p) => <String, dynamic>{...p, 'displaySampled': false}),
      ],
      day,
      owner,
      baseUrl,
    );
    segments = recordedSegments(points);
    final visits = reconcileVisits(
      [
        ...rowsOf(visitCache),
        ...rowsOf(report['visits']),
        ...rowsOf(record['visits']),
      ],
      widget.controller.pendingVisits,
      day,
      owner,
      baseUrl,
    );
    final attendances = <Json>[...rowsOf(report['attendance'])];
    if (record['attendance'] is Map) {
      attendances.add(Map<String, dynamic>.from(record['attendance']));
    }
    if (day == widget.controller.localDay &&
        widget.controller.attendance != null) {
      attendances.add(widget.controller.attendance!);
    }
    final events = dayEvents([
      ...rowsOf(report['events']),
      ...attendanceEvents(attendances, day),
    ], day);
    data = {
      ...report,
      'events': events,
      'visits': visits,
      'route': {
        'segments': segments,
        'stops': (report['route'] is Map)
            ? report['route']['stops'] ?? <Json>[]
            : <Json>[],
        'distanceMeters': recordedDistance(segments),
        'gaps': recordingGaps(segments),
      },
    };
    final own =
        native['userId'] == widget.controller.employeeId &&
        native['baseUrl'] == widget.controller.api.baseUrl;
    _trackingActive =
        own &&
        native['active'] == true &&
        native['gpsEnabled'] == true &&
        native['precisePermission'] == true;
    _position = null;
    final candidates = <Json>[...points];
    if (_today && own && native['lastPoint'] is Map) {
      candidates.add(Map<String, dynamic>.from(native['lastPoint']));
    }
    if (_today && widget.controller.lastLocation != null) {
      candidates.add(widget.controller.lastLocation!);
    }
    candidates.removeWhere(
      (p) =>
          routeCoordinate(p) == null ||
          instant(p['capturedAtUtc']) == null ||
          businessDay(instant(p['capturedAtUtc'])!) != day,
    );
    candidates.sort(
      (a, b) =>
          (DateTime.tryParse('${a['capturedAtUtc']}') ??
                  DateTime.fromMillisecondsSinceEpoch(0))
              .compareTo(
                DateTime.tryParse('${b['capturedAtUtc']}') ??
                    DateTime.fromMillisecondsSinceEpoch(0),
              ),
    );
    if (candidates.isNotEmpty) {
      _position = candidates.lastOrNull;
    }
    // Seed persistent address cache
    if (_position != null) {
      final coord = routeCoordinate(_position);
      final addr = _position?['address']?.toString() ??
          _position?['telemetry']?['address']?.toString();
      if (coord != null && addr != null && addr.isNotEmpty) {
        TrackyuAddressCache.put(coord.latitude, coord.longitude, addr);
      }
    }
    for (final v in visits) {
      final pt = safeLatLng(
        v['inLatitude'] ?? v['latitude'] ?? v['xretailer'] ?? v['in_latitude'],
        v['inLongitude'] ?? v['longitude'] ?? v['yretailer'] ?? v['in_longitude'],
      );
      final addr = v['address']?.toString() ?? v['clientAddress']?.toString() ?? v['in_address']?.toString() ?? v['retailerAddress']?.toString();
      if (pt != null && addr != null && addr.isNotEmpty) {
        TrackyuAddressCache.put(pt.latitude, pt.longitude, addr, placeName: v['clientName']?.toString() ?? v['retailerName']?.toString());
      }
    }
    for (final a in attendances) {
      final inPt = safeLatLng(a['punchInLat'], a['punchInLng']);
      final inAddr = a['punchInAddress']?.toString();
      if (inPt != null && inAddr != null && inAddr.isNotEmpty) {
        TrackyuAddressCache.put(inPt.latitude, inPt.longitude, inAddr);
      }
      final outPt = safeLatLng(a['punchOutLat'], a['punchOutLng']);
      final outAddr = a['punchOutAddress']?.toString();
      if (outPt != null && outAddr != null && outAddr.isNotEmpty) {
        TrackyuAddressCache.put(outPt.latitude, outPt.longitude, outAddr);
      }
    }
    final changedDay = _loadedDate != selected;
    _loadedDate = selected;
    if (changedDay) _followPosition = _today;
    if (data['route'] is! Map) {
      data['route'] = {'segments': segments, 'stops': []};
    }
    for (final key in ['events', 'visits']) {
      if (data[key] is! List) data[key] = [];
    }
    if (changedDay || (_followPosition && _today && _position != null)) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted || date != selected || !_sameSession) return;
        final latest = routeCoordinate(_position);
        if (_today && _followPosition && latest != null) {
          _focusLocation(latest, follow: true);
        } else if (changedDay) {
          _fitBounds(
            segments
                .expand((s) => s)
                .map(routeCoordinate)
                .whereType<LatLng>()
                .toList(),
          );
        }
      });
    }
    error = record['metadataUnavailable'] == true
        ? 'Some saved timeline details could not be loaded safely. Original records are retained; retry explicit restore.'
        : null;
    if (_today && !widget.controller.offline) {
      unawaited(_resolveMissingAddresses());
    }
  }

  Future<void> _refreshPosition() async {
    _followPosition = true;
    final point = routeCoordinate(_position);
    if (point != null) _focusLocation(point, follow: true);
    if (!_sameSession ||
        !_today ||
        !widget.controller.onDuty ||
        _requestingFix) {
      return;
    }
    setState(() => _requestingFix = true);
    try {
      await DutyTracker.requestFreshFix(
        userId: widget.controller.employeeId,
        baseUrl: widget.controller.api.baseUrl,
      );
      await Future<void>.delayed(const Duration(seconds: 2));
      if (mounted) await load();
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'Unable to refresh GPS. Your saved route is available.',
            ),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _requestingFix = false);
    }
  }

  LatLng coord(Json p) =>
      safeLatLng(p['latitude'], p['longitude']) ?? const LatLng(0, 0);

  List<Json> _extractStops(List<Json> rawStops, List<Json> allPoints) {
    final stops = detectedStops(recordedSegments(allPoints));
    for (final stop in stops) {
      final at = instant(stop['startUtc'])!;
      final metadata = rawStops.where((s) {
        final start = instant(s['startUtc']), end = instant(s['endUtc']);
        final p = routeCoordinate(s), q = routeCoordinate(stop);
        return start != null &&
            end != null &&
            p != null &&
            q != null &&
            !at.isBefore(start) &&
            !at.isAfter(end) &&
            const Distance()(p, q) <= 50;
      }).firstOrNull;
      if (metadata != null) {
        for (final key in ['address', 'placeName', 'locationName']) {
          if (metadata[key] != null) stop[key] = metadata[key];
        }
      }
    }
    return stops;
  }

  List<_TimelineEntry> _buildTimeline({
    required List<Json> events,
    required List<Json> stops,
    required List<Json> visits,
    required List<Json> allPoints,
  }) {
    final list = <_TimelineEntry>[];
    const distCalc = Distance();

    // 1. Attendance Events
    for (final e in events) {
      final type = '${e['type']}';
      final at = DateTime.tryParse('${e['atUtc']}')?.add(businessOffset);
      if (at == null) continue;
      final pt = safeLatLng(e['latitude'], e['longitude']);

      if (type == 'PunchIn') {
        list.add(_TimelineEntry(
          id: '${e['id'] ?? 'in-$at'}',
          type: _TimelineType.punchIn,
          title: 'Punch-in',
          subtitle: 'Shift started',
          at: at,
          coord: pt,
          color: const Color(0xff10b981),
          icon: Icons.login_rounded,
          raw: e,
          address: e['address']?.toString() ?? '',
        ));
      } else if (type == 'PunchOut') {
        list.add(_TimelineEntry(
          id: '${e['id'] ?? 'out-$at'}',
          type: _TimelineType.punchOut,
          title: 'Punch-out',
          subtitle: 'Shift ended',
          at: at,
          coord: pt,
          color: const Color(0xffef4444),
          icon: Icons.logout_rounded,
          raw: e,
          address: e['address']?.toString() ?? '',
        ));
      } else if (type == 'Login') {
        list.add(_TimelineEntry(
          id: '${e['id'] ?? 'login-$at'}',
          type: _TimelineType.login,
          title: 'App Opened',
          subtitle: 'Device active',
          at: at,
          coord: pt,
          color: const Color(0xff3b82f6),
          icon: Icons.phonelink_ring_rounded,
          raw: e,
          address: e['address']?.toString() ?? '',
        ));
      }
    }

    // 2. Visits
    for (final v in visits) {
      final start = DateTime.tryParse(
        '${v['checkInUtc'] ?? v['in_time'] ?? v['atUtc']}',
      )?.add(businessOffset);
      final end =
          DateTime.tryParse(
            '${v['checkOutUtc'] ?? v['out_time']}',
          )?.add(businessOffset) ??
          start;
      if (start == null) continue;

      final pt = safeLatLng(
        v['inLatitude'] ??
            v['latitude'] ??
            v['xretailer'] ??
            v['in_latitude'],
        v['inLongitude'] ??
            v['longitude'] ??
            v['yretailer'] ??
            v['in_longitude'],
      );
      final cacheKey = pt != null
          ? '${pt.latitude.toStringAsFixed(4)},${pt.longitude.toStringAsFixed(4)}'
          : '';
      final cached = pt != null ? TrackyuAddressCache.get(pt.latitude, pt.longitude) : _addressCache[cacheKey];
      final addr =
          v['address']?.toString() ??
          v['placeName']?.toString() ??
          cached ??
          '';

      list.add(
        _TimelineEntry(
          id: 'visit-${v['id'] ?? start}',
          type: _TimelineType.visit,
          title: v['clientName']?.toString() ?? 'Client visit',
          subtitle: v['clientAddress']?.toString() ?? addr,
          badge: v['isOpenVisit'] == true ? 'OPEN VISIT' : 'Completed',
          at: start,
          end: end,
          coord: pt,
          color: const Color(0xffa855f7),
          icon: Icons.storefront_rounded,
          raw: v,
          address: addr,
          departureText: end != null ? 'Left at ${_formatTime(end)}' : null,
        ),
      );
    }

    // 3. Stops (Halts)
    for (int i = 0; i < stops.length; i++) {
      final s = stops[i];
      final start = DateTime.tryParse('${s['startUtc']}')?.add(businessOffset);
      final end = DateTime.tryParse('${s['endUtc']}')?.add(businessOffset);
      if (start == null) continue;
      final pt = safeLatLng(s['latitude'], s['longitude']);

      final duration = end != null ? end.difference(start) : Duration.zero;
      final durMin =
          (toNum(s['stoppedSeconds'])?.toInt() ?? duration.inSeconds) ~/ 60;

      // Check if this stop overlaps with an already-recorded visit
      bool hasVisitAtStop = false;
      for (final v in visits) {
        final vPt = safeLatLng(
          v['inLatitude'] ??
              v['latitude'] ??
              v['xretailer'] ??
              v['in_latitude'],
          v['inLongitude'] ??
              v['longitude'] ??
              v['yretailer'] ??
              v['in_longitude'],
        );
        final vStart = DateTime.tryParse(
          '${v['checkInUtc'] ?? v['in_time'] ?? v['atUtc']}',
        )?.add(businessOffset);
        final vEnd =
            DateTime.tryParse(
              '${v['checkOutUtc'] ?? v['out_time']}',
            )?.add(businessOffset) ??
            vStart;
        if (vStart == null) continue;

        final timeOverlaps =
            !vStart.isAfter(end ?? start) && !(vEnd ?? vStart).isBefore(start);
        final distMeters = (vPt != null && pt != null)
            ? distCalc(vPt, pt)
            : 999999.0;
        if (timeOverlaps && distMeters <= 50) {
          hasVisitAtStop = true;
          break;
        }
      }

      if (hasVisitAtStop) {
        continue; // Already shown as a visit
      }

      final cacheKey = pt != null
          ? '${pt.latitude.toStringAsFixed(4)},${pt.longitude.toStringAsFixed(4)}'
          : '';
      final cached = pt != null ? TrackyuAddressCache.get(pt.latitude, pt.longitude) : _addressCache[cacheKey];
      final serverAddr =
          s['address']?.toString() ??
          s['placeName']?.toString() ??
          s['locationName']?.toString();
      final resolvedAddr = (serverAddr != null && serverAddr.trim().isNotEmpty && serverAddr != 'Stop location')
          ? serverAddr.trim()
          : (cached != null && cached != 'Resolving address...'
                ? cached
                : null);
      final hasAddress = resolvedAddr != null && resolvedAddr.trim().isNotEmpty;
      final timeStr = end != null
          ? '${_formatTime(start)} – ${_formatTime(end)}'
          : _formatTime(start);
      final coordText = pt != null ? '(${pt.latitude.toStringAsFixed(4)}, ${pt.longitude.toStringAsFixed(4)})' : '';

      list.add(
        _TimelineEntry(
          id: 'stop-$i-${s['startUtc']}',
          type: _TimelineType.stop,
          title: resolvedAddr ?? 'Halt ${i + 1}',
          subtitle: hasAddress
              ? 'Halt ${i + 1} • $timeStr${durMin > 0 ? ' ($durMin min stay)' : ''}'
              : '$timeStr • Stay duration: ${durMin > 0 ? '$durMin min' : 'Stationary'}',
          badge: durMin > 0 ? '$durMin min stay' : 'Halt',
          at: start,
          end: end,
          coord: pt,
          color: const Color(
            0xff475569,
          ), // Slate gray for confirmed stationary stop
          icon: Icons.pause_circle_filled_rounded,
          stopNumber: i + 1,
          raw: s,
          isMissingVisit: false,
          address: resolvedAddr ?? coordText,
          departureText: end != null ? 'Left at ${_formatTime(end)}' : null,
        ),
      );
    }

    list.sort((a, b) => a.at.compareTo(b.at));

    // Every movement interval is backed by consecutive fixes in one recording segment.
    final evidence = recordedSegments(allPoints);
    for (final segment in evidence) {
      if (segment.length < 2) continue;
      final distance = recordedDistance([segment]);
      if (distance < 100) continue; // Real travel requires at least 100m of movement

      final startCoord = routeCoordinate(segment.first);
      final endCoord = routeCoordinate(segment.last);
      final netDisplacement = (startCoord != null && endCoord != null)
          ? distCalc(startCoord, endCoord)
          : 0.0;
      // If the net displacement between start and end of interval is under 50m,
      // the user stayed in the same physical area (home/office/shop)
      if (netDisplacement < 50) continue;

      final start = businessDisplay(instant(segment.first['capturedAtUtc'])!);
      final end = businessDisplay(instant(segment.last['capturedAtUtc'])!);
      final durationMinutes = end.difference(start).inMinutes.abs();
      // If duration is over 10 minutes and average speed < 1.5 km/h (0.42 m/s),
      // this is stationary dwell time (e.g. resting at home), not travel!
      if (durationMinutes >= 10 && (distance / (durationMinutes * 60)) < 0.42) {
        continue;
      }
      final meters = distance >= 1000
          ? '${(distance / 1000).toStringAsFixed(1)} km'
          : '${distance.round()} m';
      final pt = routeCoordinate(segment.first);
      final cacheKey = pt != null ? '${pt.latitude.toStringAsFixed(4)},${pt.longitude.toStringAsFixed(4)}' : '';
      final cached = _addressCache[cacheKey];
      final coordText = pt != null ? '(${pt.latitude.toStringAsFixed(4)}, ${pt.longitude.toStringAsFixed(4)})' : '';
      final addr = (cached != null && cached.trim().isNotEmpty && cached != '-') ? cached : (coordText.isNotEmpty ? coordText : 'GPS location');
      list.add(
        _TimelineEntry(
          id: 'movement:${segment.first['capturedAtUtc']}',
          type: _TimelineType.travel,
          title: 'Travel ($meters)',
          subtitle: '$meters between recorded fixes',
          badge: 'GPS',
          at: start,
          end: end,
          coord: pt,
          address: addr,
          color: const Color(0xff26c6da),
          icon: Icons.route_rounded,
          distanceMeters: distance,
        ),
      );
    }
    for (final gap in recordingGaps(evidence)) {
      final isStationary = gap['isStationary'] == true;
      final distM = toNum(gap['distanceMeters']);
      final startUtc = instant(gap['startUtc']);
      final endUtc = instant(gap['endUtc']);
      if (startUtc != null && endUtc != null) {
        final sec = endUtc.difference(startUtc).inSeconds;
        if (sec < 120 && (distM == null || distM < 25)) continue;
      }
      final lat = toNum(gap['latitude']);
      final lng = toNum(gap['longitude']);
      final endLat = toNum(gap['endLatitude']);
      final endLng = toNum(gap['endLongitude']);

      String coordText = '';
      if (lat != null && lng != null) {
        final latStr = lat.toStringAsFixed(4);
        final lngStr = lng.toStringAsFixed(4);
        if (isStationary || (endLat == null || endLng == null)) {
          coordText = '$latStr, $lngStr';
        } else {
          coordText = '$latStr, $lngStr → ${endLat.toStringAsFixed(4)}, ${endLng.toStringAsFixed(4)}';
        }
      }

      final cacheKey = (lat != null && lng != null)
          ? '${lat.toStringAsFixed(4)},${lng.toStringAsFixed(4)}'
          : '';
      final cachedAddress = _addressCache[cacheKey] ?? gap['address']?.toString();
      final hasAddr = cachedAddress != null && cachedAddress.trim().isNotEmpty && cachedAddress != '-';

      final title = isStationary
          ? (hasAddr ? cachedAddress : (coordText.isNotEmpty ? 'Stationary Halt ($coordText)' : 'Halt / Stay'))
          : (hasAddr ? cachedAddress : (coordText.isNotEmpty ? 'Travel ($coordText)' : 'GPS Movement'));

      final subtitle = coordText.isNotEmpty
          ? (hasAddr ? 'Coordinates: $coordText' : '($coordText)')
          : 'Movement during this interval is unknown';

      list.add(
        _TimelineEntry(
          id: 'gap:${gap['startUtc']}',
          type: isStationary ? _TimelineType.stop : _TimelineType.gap,
          title: title,
          subtitle: subtitle,
          badge: isStationary ? 'Halt' : 'Interval',
          at: businessDisplay(instant(gap['startUtc'])!),
          end: businessDisplay(instant(gap['endUtc'])!),
          coord: (lat != null && lng != null) ? LatLng(lat.toDouble(), lng.toDouble()) : null,
          color: isStationary ? const Color(0xff0288d1) : const Color(0xff64748b),
          icon: isStationary ? Icons.location_on_rounded : Icons.explore_rounded,
          address: hasAddr ? cachedAddress : (coordText.isNotEmpty ? '($coordText)' : 'GPS location'),
          distanceMeters: distM?.toDouble(),
          raw: gap,
        ),
      );
    }
    final capture = instant(_position?['capturedAtUtc']);
    if (_today && capture != null && routeCoordinate(_position) != null) {
      final key = coordinateKey(_position);
      final coord = routeCoordinate(_position)!;
      final cached = TrackyuAddressCache.get(coord.latitude, coord.longitude);
      final address =
          cached ??
          _position?['address']?.toString() ??
          _position?['telemetry']?['address']?.toString() ??
          _addressCache[key] ??
          '(${coord.latitude.toStringAsFixed(4)}, ${coord.longitude.toStringAsFixed(4)})';
      if (address.isNotEmpty && !address.startsWith('(')) {
        TrackyuAddressCache.put(coord.latitude, coord.longitude, address);
      }
      list.add(
        _TimelineEntry(
          id: 'last-fix:${capture.toIso8601String()}',
          type: _TimelineType.stop,
          title: _current ? 'You are here' : 'Last known location',
          subtitle: '$address · ${_formatTime(businessDisplay(capture))}',
          badge: _current ? 'Recent GPS' : 'Recorded',
          at: businessDisplay(capture),
          coord: routeCoordinate(_position),
          color: const Color(0xff0288d1),
          icon: Icons.my_location_rounded,
          raw: _position,
          address: address,
        ),
      );
    }
    list.sort((a, b) => a.at.compareTo(b.at));
    return list;
  }

  void _focusLocation(LatLng point, {bool follow = false}) {
    _followPosition = follow;
    try {
      mapController.move(point, 16);
    } catch (_) {}
  }

  void _fitBounds(List<LatLng> points) {
    if (points.isEmpty) return;
    try {
      if (points.length == 1 || points.every((p) => p == points.first)) {
        mapController.move(points.first, 15);
      } else {
        mapController.fitCamera(
          CameraFit.bounds(
            bounds: LatLngBounds.fromPoints(points),
            padding: const EdgeInsets.all(36),
            maxZoom: 16,
          ),
        );
      }
    } catch (_) {}
  }

  void _showVisitDetailsModal(BuildContext context, Json visit) {
    final start = DateTime.tryParse(
      '${visit['checkInUtc']}',
    )?.add(businessOffset);
    final end = DateTime.tryParse(
      '${visit['checkOutUtc']}',
    )?.add(businessOffset);
    final durMin = (start != null && end != null)
        ? end.difference(start).inMinutes
        : null;
    final shop = visit['shopName']?.toString().trim().isNotEmpty == true
        ? visit['shopName'].toString().trim()
        : (visit['clientName']?.toString().trim().isNotEmpty == true
              ? visit['clientName'].toString().trim()
              : 'Client visit');
    final addr = visit['address']?.toString().trim().isNotEmpty == true
        ? visit['address'].toString().trim()
        : (visit['placeName']?.toString().trim().isNotEmpty == true
              ? visit['placeName'].toString().trim()
              : 'Address not recorded');
    final remarks = visit['remarks']?.toString().trim().isNotEmpty == true
        ? visit['remarks'].toString().trim()
        : (visit['remark']?.toString().trim().isNotEmpty == true
              ? visit['remark'].toString().trim()
              : 'No remarks added');

    final inPt = safeLatLng(
      visit['inLatitude'] ?? visit['latitude'],
      visit['inLongitude'] ?? visit['longitude'],
    );
    final outPt = safeLatLng(visit['outLatitude'], visit['outLongitude']);
    final String? latLngText = inPt != null
        ? '${inPt.latitude.toStringAsFixed(6)}, ${inPt.longitude.toStringAsFixed(6)}'
        : null;
    final String? outLatLngText = outPt != null
        ? '${outPt.latitude.toStringAsFixed(6)}, ${outPt.longitude.toStringAsFixed(6)}'
        : null;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: _darkMode ? const Color(0xff1e1e1e) : Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        return ConstrainedBox(
          constraints: BoxConstraints(
            maxHeight: MediaQuery.of(ctx).size.height * 0.88,
          ),
          child: Padding(
            padding: EdgeInsets.fromLTRB(
              20,
              16,
              20,
              MediaQuery.of(ctx).viewInsets.bottom + 20,
            ),
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'OPEN VISIT DETAILS',
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 1.1,
                          color: Color(0xffab47bc),
                        ),
                      ),
                      IconButton(
                        icon: Icon(
                          Icons.close_rounded,
                          color: _darkMode ? Colors.white : Colors.black87,
                        ),
                        onPressed: () => Navigator.pop(ctx),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(
                    shop,
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w700,
                      color: _darkMode ? Colors.white : const Color(0xff102c4a),
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    visit['placeName']?.toString().trim().isNotEmpty == true
                        ? visit['placeName'].toString().trim()
                        : '${visit['kind'] ?? 'Open Visit'} • Check-in',
                    style: const TextStyle(
                      fontSize: 13,
                      color: Color(0xff94a3b8),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: _darkMode
                          ? const Color(0xff25282c)
                          : const Color(0xfff8fafd),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: _darkMode
                            ? const Color(0xff374151)
                            : const Color(0xffe2e8f0),
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Column(
                          children: [
                            const Text(
                              'CHECK IN',
                              style: TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.w600,
                                color: Color(0xff94a3b8),
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              start != null ? _formatTime(start) : '--',
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w700,
                                color: _darkMode
                                    ? Colors.white
                                    : Colors.black87,
                              ),
                            ),
                          ],
                        ),
                        Column(
                          children: [
                            const Text(
                              'CHECK OUT',
                              style: TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.w600,
                                color: Color(0xff94a3b8),
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              end != null ? _formatTime(end) : 'In progress',
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w700,
                                color: _darkMode
                                    ? Colors.white
                                    : Colors.black87,
                              ),
                            ),
                          ],
                        ),
                        Column(
                          children: [
                            const Text(
                              'DURATION',
                              style: TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.w600,
                                color: Color(0xff94a3b8),
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              durMin != null ? '$durMin min' : '--',
                              style: const TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w700,
                                color: Color(0xff26c6da),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  // Location, Current Address & Coordinates card
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: _darkMode
                          ? const Color(0xff25282c)
                          : const Color(0xfff8fafd),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: _darkMode
                            ? const Color(0xff374151)
                            : const Color(0xffe2e8f0),
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Icon(
                              Icons.location_on_rounded,
                              color: Color(0xff26c6da),
                              size: 18,
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text(
                                    'SHOP ADDRESS',
                                    style: TextStyle(
                                      fontSize: 10,
                                      fontWeight: FontWeight.w700,
                                      letterSpacing: 0.6,
                                      color: Color(0xff94a3b8),
                                    ),
                                  ),
                                  const SizedBox(height: 3),
                                  Text(
                                    addr,
                                    style: TextStyle(
                                      fontSize: 13,
                                      fontWeight: FontWeight.w600,
                                      color: _darkMode
                                          ? Colors.white
                                          : const Color(0xff1f2937),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        if (latLngText != null) ...[
                          const SizedBox(height: 10),
                          Divider(
                            height: 1,
                            color: _darkMode
                                ? const Color(0xff374151)
                                : const Color(0xffe2e8f0),
                          ),
                          const SizedBox(height: 10),
                          Row(
                            children: [
                              const Icon(
                                Icons.explore_outlined,
                                color: Color(0xffab47bc),
                                size: 18,
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const Text(
                                      'GPS COORDINATES (LAT, LONG)',
                                      style: TextStyle(
                                        fontSize: 10,
                                        fontWeight: FontWeight.w700,
                                        letterSpacing: 0.6,
                                        color: Color(0xff94a3b8),
                                      ),
                                    ),
                                    const SizedBox(height: 3),
                                    Text(
                                      latLngText,
                                      style: TextStyle(
                                        fontSize: 13,
                                        fontWeight: FontWeight.w600,
                                        fontFamily: 'monospace',
                                        color: _darkMode
                                            ? const Color(0xff80cbc4)
                                            : const Color(0xff00695c),
                                      ),
                                    ),
                                    if (outLatLngText != null) ...[
                                      const SizedBox(height: 2),
                                      Text(
                                        'Check-out GPS: $outLatLngText',
                                        style: TextStyle(
                                          fontSize: 11,
                                          fontFamily: 'monospace',
                                          color: _darkMode
                                              ? Colors.white54
                                              : Colors.black54,
                                        ),
                                      ),
                                    ],
                                  ],
                                ),
                              ),
                              IconButton(
                                icon: const Icon(Icons.copy_rounded, size: 16),
                                tooltip: 'Copy coordinates',
                                color: _darkMode
                                    ? Colors.white70
                                    : Colors.black54,
                                onPressed: () {
                                  Clipboard.setData(
                                    ClipboardData(text: latLngText),
                                  );
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: Text(
                                        'Coordinates copied to clipboard',
                                      ),
                                      duration: Duration(seconds: 1),
                                    ),
                                  );
                                },
                              ),
                            ],
                          ),
                        ],
                        if (inPt != null) ...[
                          const SizedBox(height: 12),
                          Container(
                            height: 160,
                            width: double.infinity,
                            clipBehavior: Clip.antiAlias,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                color: _darkMode
                                    ? const Color(0xff374151)
                                    : const Color(0xffe2e8f0),
                              ),
                            ),
                            child: Stack(
                              children: [
                                FlutterMap(
                                  key: ValueKey(
                                    'visit-modal-map-${inPt.latitude}-${inPt.longitude}',
                                  ),
                                  options: MapOptions(
                                    initialCenter: inPt,
                                    initialZoom: 15.5,
                                    interactionOptions:
                                        const InteractionOptions(
                                          flags:
                                              InteractiveFlag.all &
                                              ~InteractiveFlag.rotate,
                                        ),
                                  ),
                                  children: [
                                    legacyMapTiles(
                                      offline: () => widget.controller.offline,
                                      darkMode: _darkMode,
                                    ),
                                    legacyMapAttribution,
                                    MarkerLayer(
                                      markers: [
                                        Marker(
                                          point: inPt,
                                          width: 38,
                                          height: 38,
                                          child: Container(
                                            decoration: const BoxDecoration(
                                              color: Color(0xffab47bc),
                                              shape: BoxShape.circle,
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Colors.black26,
                                                  blurRadius: 4,
                                                  offset: Offset(0, 2),
                                                ),
                                              ],
                                            ),
                                            child: const Icon(
                                              Icons.storefront_rounded,
                                              color: Colors.white,
                                              size: 19,
                                            ),
                                          ),
                                        ),
                                        if (outPt != null)
                                          Marker(
                                            point: outPt,
                                            width: 34,
                                            height: 34,
                                            child: Container(
                                              decoration: const BoxDecoration(
                                                color: Color(0xff26c6da),
                                                shape: BoxShape.circle,
                                                boxShadow: [
                                                  BoxShadow(
                                                    color: Colors.black26,
                                                    blurRadius: 4,
                                                    offset: Offset(0, 2),
                                                  ),
                                                ],
                                              ),
                                              child: const Icon(
                                                Icons.flag_rounded,
                                                color: Colors.white,
                                                size: 17,
                                              ),
                                            ),
                                          ),
                                      ],
                                    ),
                                  ],
                                ),
                                Positioned(
                                  top: 8,
                                  right: 8,
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 8,
                                      vertical: 3,
                                    ),
                                    decoration: BoxDecoration(
                                      color: Colors.black.withValues(
                                        alpha: 0.65,
                                      ),
                                      borderRadius: BorderRadius.circular(6),
                                    ),
                                    child: const Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Icon(
                                          Icons.location_on_rounded,
                                          size: 11,
                                          color: Color(0xff26c6da),
                                        ),
                                        SizedBox(width: 3),
                                        Text(
                                          'Visit Map',
                                          style: TextStyle(
                                            fontSize: 10,
                                            fontWeight: FontWeight.w600,
                                            color: Colors.white,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  // Selfie / Photo section
                  Row(
                    children: [
                      const Icon(
                        Icons.photo_camera_rounded,
                        size: 16,
                        color: Color(0xffab47bc),
                      ),
                      const SizedBox(width: 6),
                      Text(
                        'VISIT SELFIE / PHOTO',
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 0.8,
                          color: _darkMode
                              ? Colors.white70
                              : const Color(0xff1f2937),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  _VisitSelfiePreview(
                    controller: widget.controller,
                    visit: visit,
                    darkMode: _darkMode,
                  ),
                  const SizedBox(height: 14),
                  Text(
                    'Remarks / Notes',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: _darkMode ? Colors.white : const Color(0xff1f2937),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: _darkMode
                          ? const Color(0xff25282c)
                          : const Color(0xfff8fafd),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      remarks,
                      style: TextStyle(
                        fontSize: 13,
                        color: _darkMode
                            ? const Color(0xffcbd5e1)
                            : const Color(0xff334155),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      style: FilledButton.styleFrom(
                        backgroundColor: const Color(0xff26c6da),
                        foregroundColor: const Color(0xff00363a),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      onPressed: () {
                        Navigator.pop(ctx);
                        final pt = safeLatLng(
                          visit['inLatitude'] ?? visit['latitude'],
                          visit['inLongitude'] ?? visit['longitude'],
                        );
                        if (pt != null) {
                          _focusLocation(pt);
                        }
                      },
                      icon: const Icon(Icons.map_rounded),
                      label: const Text(
                        'Show this visit on map',
                        style: TextStyle(fontWeight: FontWeight.w700),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    if (!_sameSession) {
      return Scaffold(
        appBar: AppBar(title: const Text('Timeline')),
        body: const Center(
          child: Padding(
            padding: EdgeInsets.all(24),
            child: Text('Session changed.', textAlign: TextAlign.center),
          ),
        ),
      );
    }
    final events = uniqueRouteEvents(
      (data['events'] as List? ?? [])
          .whereType<Map>()
          .map((e) => Map<String, dynamic>.from(e))
          .toList(),
      'id',
      'atUtc',
    );
    final rawStops = (data['route'] as Map?)?['stops'] as List? ?? [];
    final visits = uniqueRouteEvents(
      (data['visits'] as List? ?? [])
          .whereType<Map>()
          .map((v) => Map<String, dynamic>.from(v))
          .toList(),
      'id',
      'checkInUtc',
    );

    final allRawPoints = segments.expand((s) => s).toList();
    final stops = _extractStops(
      rawStops
          .whereType<Map>()
          .map((s) => Map<String, dynamic>.from(s))
          .toList(),
      allRawPoints,
    );

    final preview = routePreview(segments);
    final cleanPolylines = preview
        .map((s) => s.map(routeCoordinate).whereType<LatLng>().toList())
        .toList();
    final allCleanPoints = <LatLng>[
      ...cleanPolylines.expand((p) => p),
      for (final v in visits)
        if (routeCoordinate(v) != null) routeCoordinate(v)!,
      if (_today && routeCoordinate(_position) != null)
        routeCoordinate(_position)!,
    ];
    final mapPolylines = <Polyline>[
      for (final segment in cleanPolylines)
        if (segment.length > 1)
          Polyline(
            points: segment,
            strokeWidth: 4.8,
            color: const Color(0xff00e5ff),
            strokeCap: StrokeCap.round,
            strokeJoin: StrokeJoin.round,
          ),
    ];
    final timelineItems = _buildTimeline(
      events: events,
      stops: stops,
      visits: visits,
      allPoints: allRawPoints,
    );

    final double totalDistanceMeters = recordedDistance(segments);
    final String distanceDisplay = totalDistanceMeters >= 1000
        ? '${(totalDistanceMeters / 1000).toStringAsFixed(1)} km'
        : '${totalDistanceMeters.round()} meters';

    int totalStopMinutes = 0;
    for (final s in stops) {
      final st = DateTime.tryParse('${s['startUtc']}');
      final en = DateTime.tryParse('${s['endUtc']}');
      if (st != null && en != null) {
        totalStopMinutes +=
            (toNum(s['stoppedSeconds'])?.toInt() ??
                en.difference(st).inSeconds) ~/
            60;
      }
    }

    int transitMinutes = 0;
    for (final t in timelineItems.where(
      (i) => i.type == _TimelineType.travel,
    )) {
      if (t.end != null) {
        transitMinutes += t.end!.difference(t.at).inMinutes;
      }
    }

    final LatLng? initialCenter = allCleanPoints.isNotEmpty
        ? allCleanPoints.first
        : (allRawPoints.isNotEmpty
              ? routeCoordinate(allRawPoints.first)
              : null);

    final bgColor = _darkMode
        ? const Color(0xff121212)
        : const Color(0xfff8fafd);
    final cardColor = _darkMode ? const Color(0xff1e1e1e) : Colors.white;
    final textPrimary = _darkMode ? Colors.white : const Color(0xff102c4a);
    final textSecondary = _darkMode
        ? const Color(0xff94a3b8)
        : const Color(0xff64748b);
    final borderColor = _darkMode
        ? const Color(0xff2d3135)
        : const Color(0xffe2e8f0);

    if (error != null && data.isEmpty) {
      return Scaffold(
        backgroundColor: bgColor,
        appBar: AppBar(
          backgroundColor: bgColor,
          elevation: 0,
          title: Text(
            'Timeline',
            style: TextStyle(
              fontWeight: FontWeight.w700,
              fontSize: 20,
              color: textPrimary,
            ),
          ),
        ),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.lock_person_rounded, size: 48, color: textSecondary),
                const SizedBox(height: 16),
                Text(
                  error!,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: textPrimary,
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 16),
                FilledButton.tonal(onPressed: load, child: const Text('Retry')),
              ],
            ),
          ),
        ),
      );
    }

    Widget buildMapStack({required bool isFullscreen}) {
      return Stack(
        children: [
          FlutterMap(
            mapController: mapController,
            key: ValueKey('route-map-$_fullscreenMap'),
            options: MapOptions(
              onPositionChanged: (_, gesture) {
                if (gesture) _followPosition = false;
              },
              initialCenter:
                  (_today ? routeCoordinate(_position) : null) ??
                  initialCenter ??
                  const LatLng(23.18, 77.42),
              initialZoom: 14.5,

              initialCameraFit: () {
                if (_today || allCleanPoints.length <= 1) {
                  return null;
                }
                try {
                  final b = LatLngBounds.fromPoints(allCleanPoints);
                  if (b.southWest.latitude == b.northEast.latitude &&
                      b.southWest.longitude == b.northEast.longitude) {
                    return null;
                  }
                  return CameraFit.bounds(
                    bounds: b,
                    padding: const EdgeInsets.all(40),
                    maxZoom: 16,
                  );
                } catch (_) {
                  return null;
                }
              }(),
            ),
            children: [
              legacyMapTiles(
                offline: () => widget.controller.offline,
                darkMode: _darkMode,
              ),
              legacyMapAttribution,
              PolylineLayer(polylines: mapPolylines),
              if (routeCoordinate(_position) != null &&
                  toNum(_position!['accuracyMeters'])?.isFinite == true)
                CircleLayer(
                  circles: [
                    CircleMarker(
                      point: routeCoordinate(_position)!,
                      radius: (toNum(
                        _position!['accuracyMeters'],
                      )!.toDouble()).clamp(0, 10000),
                      useRadiusInMeter: true,
                      color: const Color(0x2026c6da),
                      borderColor: const Color(0x8026c6da),
                      borderStrokeWidth: 1.5,
                    ),
                  ],
                ),
              MarkerLayer(
                markers: _buildMapMarkers(
                  cleanPoints: allCleanPoints,
                  stops: stops,
                  visits: visits,
                  events: events,
                ),
              ),
            ],
          ),
          if (isFullscreen)
            Positioned(
              top: 12,
              left: 12,
              right: 12,
              child: Material(
                color: _darkMode
                    ? const Color(0xdd1e1e1e)
                    : Colors.white.withValues(alpha: 0.94),
                borderRadius: BorderRadius.circular(20),
                elevation: 4,
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 8,
                  ),
                  child: Row(
                    children: [
                      const Icon(
                        Icons.map_rounded,
                        size: 16,
                        color: Color(0xff26c6da),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'Full Map View • ${_today ? 'Today' : '${date.day}/${date.month}/${date.year}'}',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                            color: textPrimary,
                          ),
                        ),
                      ),
                      InkWell(
                        onTap: () => setState(() => _fullscreenMap = false),
                        borderRadius: BorderRadius.circular(12),
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            color: const Color(
                              0xff26c6da,
                            ).withValues(alpha: 0.15),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: const Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.close_fullscreen_rounded,
                                size: 13,
                                color: Color(0xff26c6da),
                              ),
                              SizedBox(width: 4),
                              Text(
                                'Collapse',
                                style: TextStyle(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w700,
                                  color: Color(0xff26c6da),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          // Map Floating Controls
          Positioned(
            left: 12,
            bottom: 12,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Material(
                  color: _darkMode ? const Color(0xcc1e1e1e) : Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  elevation: 3,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(20),
                    onTap: () {
                      _followPosition = false;
                      _fitBounds(allCleanPoints);
                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 6,
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.fit_screen_rounded,
                            size: 15,
                            color: textPrimary,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            'Fit route',
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                              color: textPrimary,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Material(
                  color: _darkMode ? const Color(0xcc1e1e1e) : Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  elevation: 3,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(20),
                    onTap: () {
                      setState(() {
                        _fullscreenMap = !_fullscreenMap;
                      });
                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 6,
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            isFullscreen
                                ? Icons.close_fullscreen_rounded
                                : Icons.open_in_full_rounded,
                            size: 15,
                            color: textPrimary,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            isFullscreen ? 'Show timeline' : 'Extend map',
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                              color: textPrimary,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Positioned(
            right: 12,
            bottom: 12,
            child: Material(
              color: _darkMode ? const Color(0xcc1e1e1e) : Colors.white,
              shape: const CircleBorder(),
              elevation: 3,
              child: IconButton(
                icon: const Icon(
                  Icons.my_location_rounded,
                  color: Color(0xff26c6da),
                  size: 20,
                ),
                tooltip: 'Show my location',
                onPressed: _requestingFix ? null : _refreshPosition,
              ),
            ),
          ),
        ],
      );
    }

    return PopScope(
      canPop: !_fullscreenMap,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop && _fullscreenMap) {
          setState(() => _fullscreenMap = false);
        }
      },
      child: Scaffold(
        backgroundColor: bgColor,
        appBar: AppBar(
          backgroundColor: bgColor,
          elevation: 0,
          scrolledUnderElevation: 0,
          title: Text(
            _fullscreenMap ? 'Map View' : 'Timeline',
            style: TextStyle(
              fontWeight: FontWeight.w700,
              fontSize: 20,
              color: textPrimary,
            ),
          ),
          actions: [
            IconButton(
              tooltip: _fullscreenMap ? 'Show timeline' : 'Extend map',
              icon: Icon(
                _fullscreenMap
                    ? Icons.view_timeline_rounded
                    : Icons.open_in_full_rounded,
                color: textSecondary,
              ),
              onPressed: () => setState(() => _fullscreenMap = !_fullscreenMap),
            ),
            IconButton(
              tooltip: _darkMode ? 'Light mode' : 'Dark mode',
              icon: Icon(
                _darkMode ? Icons.light_mode_rounded : Icons.dark_mode_rounded,
                color: textSecondary,
              ),
              onPressed: () async {
                await widget.controller.toggleDarkMode();
                if (mounted) setState(() {});
              },
            ),
            IconButton(
              tooltip: 'Refresh route',
              onPressed: loading ? null : load,
              icon: Icon(Icons.refresh_rounded, color: textSecondary),
            ),
          ],
          bottom: _fullscreenMap
              ? null
              : PreferredSize(
                  preferredSize: const Size.fromHeight(48),
                  child: Container(
                    decoration: BoxDecoration(
                      border: Border(
                        bottom: BorderSide(color: borderColor, width: 1),
                      ),
                    ),
                    child: Row(
                      children: [
                        _buildTopTabItem(
                          0,
                          'Day',
                          Icons.calendar_today_rounded,
                          textPrimary,
                          textSecondary,
                        ),
                        _buildTopTabItem(
                          1,
                          'Places',
                          Icons.place_rounded,
                          textPrimary,
                          textSecondary,
                        ),
                        _buildTopTabItem(
                          2,
                          'Insights',
                          Icons.insights_rounded,
                          textPrimary,
                          textSecondary,
                        ),
                      ],
                    ),
                  ),
                ),
        ),
        body: _fullscreenMap
            ? buildMapStack(isFullscreen: true)
            : (_selectedTab == 0
                  ? ListView(
                      scrollCacheExtent: const ScrollCacheExtent.pixels(300),
                      padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
                      children: [
                        // Google Maps Timeline Interactive Map Box
                        Container(
                          clipBehavior: Clip.antiAlias,
                          decoration: BoxDecoration(
                            color: cardColor,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: borderColor),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withValues(
                                  alpha: _darkMode ? 0.3 : 0.05,
                                ),
                                blurRadius: 14,
                                offset: const Offset(0, 4),
                              ),
                            ],
                          ),
                          child: Column(
                            children: [
                              if (allCleanPoints.isNotEmpty ||
                                  allRawPoints.isNotEmpty ||
                                  _position != null)
                                SizedBox(
                                  height: 260,
                                  child: buildMapStack(isFullscreen: false),
                                )
                              else if (!loading)
                                Padding(
                                  padding: const EdgeInsets.all(28),
                                  child: Center(
                                    child: Text(
                                      'No location points recorded for this date.',
                                      style: TextStyle(color: textSecondary),
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 12),

                        // Date Navigator Bar (< Today ▾ >)
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            color: cardColor,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(color: borderColor),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              IconButton(
                                icon: Icon(
                                  Icons.chevron_left_rounded,
                                  color: textPrimary,
                                ),
                                tooltip: 'Previous day',
                                onPressed: loading
                                    ? null
                                    : () {
                                        setState(
                                          () => date = date.subtract(
                                            const Duration(days: 1),
                                          ),
                                        );
                                        load();
                                      },
                              ),
                              InkWell(
                                onTap: loading
                                    ? null
                                    : () async {
                                        final picked = await showDatePicker(
                                          context: context,
                                          initialDate: date,
                                          firstDate: DateTime(2024),
                                          lastDate: DateTime.parse(
                                            widget.controller.localDay,
                                          ),
                                        );
                                        if (picked != null && mounted) {
                                          setState(() => date = picked);
                                          await load();
                                        }
                                      },
                                borderRadius: BorderRadius.circular(10),
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 12,
                                    vertical: 8,
                                  ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Text(
                                        _today
                                            ? 'Today'
                                            : MaterialLocalizations.of(
                                                context,
                                              ).formatMediumDate(date),
                                        style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w700,
                                          color: textPrimary,
                                        ),
                                      ),
                                      const SizedBox(width: 4),
                                      Icon(
                                        Icons.arrow_drop_down_rounded,
                                        color: const Color(0xff26c6da),
                                        size: 22,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              IconButton(
                                icon: Icon(
                                  Icons.chevron_right_rounded,
                                  color: _today
                                      ? textSecondary.withValues(alpha: 0.3)
                                      : textPrimary,
                                ),
                                tooltip: 'Next day',
                                onPressed: (loading || _today)
                                    ? null
                                    : () {
                                        setState(
                                          () => date = date.add(
                                            const Duration(days: 1),
                                          ),
                                        );
                                        load();
                                      },
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 12),

                        // Quick Google Timeline Summary Strip (🛵 13 km · 50 min  |  📍 5 visits)
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 10,
                          ),
                          decoration: BoxDecoration(
                            color: cardColor,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(color: borderColor),
                          ),
                          child: Row(
                            children: [
                              Expanded(
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    const Icon(
                                      Icons.two_wheeler_rounded,
                                      color: Color(0xff26c6da),
                                      size: 20,
                                    ),
                                    const SizedBox(width: 6),
                                    Flexible(
                                      child: Text(
                                        '$distanceDisplay • $transitMinutes min',
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                          fontSize: 13,
                                          fontWeight: FontWeight.w700,
                                          color: textPrimary,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                width: 1,
                                height: 18,
                                margin: const EdgeInsets.symmetric(
                                  horizontal: 6,
                                ),
                                color: borderColor,
                              ),
                              Expanded(
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    const Icon(
                                      Icons.place_rounded,
                                      color: Color(0xffab47bc),
                                      size: 18,
                                    ),
                                    const SizedBox(width: 6),
                                    Flexible(
                                      child: Text(
                                        '${visits.length} visits • ${stops.length} halts',
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                          fontSize: 13,
                                          fontWeight: FontWeight.w700,
                                          color: textPrimary,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 12),

                        // Status Bar (You are here / Last known location)
                        Container(
                          key: const ValueKey('location-status'),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 14,
                            vertical: 10,
                          ),
                          decoration: BoxDecoration(
                            color: _current
                                ? (_darkMode
                                      ? const Color(0xff122b3a)
                                      : const Color(0xffe8f0fe))
                                : (_darkMode
                                      ? const Color(0xff2a2517)
                                      : const Color(0xfffff8e1)),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: _current
                                  ? const Color(
                                      0xff26c6da,
                                    ).withValues(alpha: 0.4)
                                  : const Color(
                                      0xfff59e0b,
                                    ).withValues(alpha: 0.4),
                            ),
                          ),
                          child: Row(
                            children: [
                              Icon(
                                Icons.person_pin_circle_rounded,
                                color: _current
                                    ? const Color(0xff26c6da)
                                    : const Color(0xfff59e0b),
                                size: 22,
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      _position == null
                                          ? (_today ? 'Acquiring GPS location...' : 'Summary for this date')
                                          : _positionLabel,
                                      style: TextStyle(
                                        fontWeight: FontWeight.w700,
                                        fontSize: 14,
                                        color: textPrimary,
                                      ),
                                    ),
                                    if (_position != null)
                                      Text(
                                        '${DateTime.tryParse("${_position!['capturedAtUtc']}")?.add(businessOffset).toString().split('.').first ?? "Unknown time"} | +/-${toNum(_position!['accuracyMeters'])?.round() ?? "?"} m',
                                        style: TextStyle(
                                          fontSize: 11,
                                          color: textSecondary,
                                        ),
                                      ),
                                  ],
                                ),
                              ),
                              if (_today && widget.controller.onDuty)
                                IconButton(
                                  tooltip: 'Refresh GPS',
                                  onPressed: _requestingFix
                                      ? null
                                      : _refreshPosition,
                                  icon: Icon(
                                    Icons.refresh,
                                    color: textSecondary,
                                    size: 20,
                                  ),
                                ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 20),

                        // Connected Timeline Stream Header
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                'Timeline',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w700,
                                  color: textPrimary,
                                ),
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 3,
                              ),
                              decoration: BoxDecoration(
                                color: const Color(
                                  0xff26c6da,
                                ).withValues(alpha: 0.15),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Text(
                                '${timelineItems.where((t) => t.type != _TimelineType.travel && t.type != _TimelineType.gap).length} steps',
                                style: const TextStyle(
                                  color: Color(0xff26c6da),
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 14),

                        if (error != null)
                          Padding(
                            padding: const EdgeInsets.only(bottom: 12),
                            child: Text(
                              error!,
                              style: const TextStyle(color: Color(0xff9a6700)),
                            ),
                          ),
                        if (timelineItems.isEmpty && loading)
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 18,
                            ),
                            decoration: BoxDecoration(
                              color: cardColor,
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(color: borderColor),
                            ),
                            child: Center(
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const SizedBox(
                                    width: 14,
                                    height: 14,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                      color: Color(0xff26c6da),
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  Flexible(
                                    child: Text(
                                      'Loading timeline...',
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                        color: textSecondary,
                                        fontSize: 13,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),

                        if (timelineItems.isEmpty && !loading)
                          Container(
                            padding: const EdgeInsets.all(24),
                            decoration: BoxDecoration(
                              color: cardColor,
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(color: borderColor),
                            ),
                            child: Center(
                              child: Text(
                                'No activity recorded for this date.',
                                style: TextStyle(color: textSecondary),
                              ),
                            ),
                          ),

                        // Connected Timeline Items
                        for (int i = 0; i < timelineItems.length; i++)
                          _buildConnectedTimelineItem(
                            item: timelineItems[i],
                            isFirst: i == 0,
                            isLast: i == timelineItems.length - 1,
                          ),
                      ],
                    )
                  : _selectedTab == 1
                  ? _buildPlacesTab(
                      visits,
                      stops,
                      textPrimary,
                      textSecondary,
                      cardColor,
                      borderColor,
                    )
                  : _buildInsightsTab(
                      totalDistanceMeters,
                      transitMinutes,
                      totalStopMinutes,
                      visits,
                      textPrimary,
                      textSecondary,
                      cardColor,
                      borderColor,
                    )),
      ),
    );
  }

  Widget _buildTopTabItem(
    int index,
    String title,
    IconData icon,
    Color textPrimary,
    Color textSecondary,
  ) {
    final isSelected = _selectedTab == index;
    return Expanded(
      child: InkWell(
        onTap: () => setState(() => _selectedTab = index),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            border: Border(
              bottom: BorderSide(
                color: isSelected
                    ? const Color(0xff26c6da)
                    : Colors.transparent,
                width: 3,
              ),
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                icon,
                size: 16,
                color: isSelected ? const Color(0xff26c6da) : textSecondary,
              ),
              const SizedBox(width: 6),
              Flexible(
                child: Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                    color: isSelected ? const Color(0xff26c6da) : textSecondary,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPlacesTab(
    List<Json> visits,
    List<Json> stops,
    Color textPrimary,
    Color textSecondary,
    Color cardColor,
    Color borderColor,
  ) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text(
          '${visits.length} places visited',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w700,
            color: textPrimary,
          ),
        ),
        const SizedBox(height: 14),
        if (visits.isEmpty && stops.isEmpty)
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: cardColor,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: borderColor),
            ),
            child: Center(
              child: Text(
                'No visits or halts recorded on this date.',
                style: TextStyle(color: textSecondary),
              ),
            ),
          ),
        for (final v in visits) ...[
          Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: cardColor,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: borderColor),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: const Color(0xffab47bc).withValues(alpha: 0.15),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(
                    Icons.storefront_rounded,
                    color: Color(0xffab47bc),
                    size: 22,
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${v['shopName'] ?? v['clientName'] ?? 'Customer visit'}',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          color: textPrimary,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '${v['address'] ?? v['placeName'] ?? 'Address recorded via GPS'}',
                        style: TextStyle(fontSize: 13, color: textSecondary),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Text(
                            '${routeEventTime(v['checkInUtc'] ?? v['in_time'])} – ${v['checkOutUtc'] != null ? routeEventTime(v['checkOutUtc']) : (v['out_time'] != null ? routeEventTime(v['out_time']) : 'In progress')}',
                            style: const TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: Color(0xff26c6da),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.chevron_right_rounded, color: textSecondary),
                  onPressed: () => _showVisitDetailsModal(context, v),
                ),
              ],
            ),
          ),
        ],
        if (stops.isNotEmpty) ...[
          const SizedBox(height: 12),
          Text(
            '${stops.length} stationary halts',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: textPrimary,
            ),
          ),
          const SizedBox(height: 10),
          for (int i = 0; i < stops.length; i++) ...[
            Builder(
              builder: (context) {
                final s = stops[i];
                final pt = safeLatLng(s['latitude'], s['longitude']);
                final cached = pt != null ? TrackyuAddressCache.get(pt.latitude, pt.longitude) : null;
                final serverAddr =
                    s['address']?.toString() ??
                    s['placeName']?.toString() ??
                    s['locationName']?.toString();
                final resolvedAddr =
                    (serverAddr != null && serverAddr.trim().isNotEmpty && serverAddr != 'Stop location')
                    ? serverAddr.trim()
                    : (cached != null && cached != 'Resolving address...'
                          ? cached
                          : null);
                final start = DateTime.tryParse(
                  '${s['startUtc']}',
                )?.add(businessOffset);
                final end = DateTime.tryParse(
                  '${s['endUtc']}',
                )?.add(businessOffset);
                final duration = (start != null && end != null)
                    ? end.difference(start)
                    : Duration.zero;
                final durMin =
                    (toNum(s['stoppedSeconds'])?.toInt() ??
                        duration.inSeconds) ~/
                    60;
                final timeStr = (start != null && end != null)
                    ? '${_formatTime(start)} – ${_formatTime(end)}'
                    : (start != null ? _formatTime(start) : '');
                return Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: cardColor,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: borderColor),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          color: const Color(
                            0xff475569,
                          ).withValues(alpha: 0.12),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.pause_circle_filled_rounded,
                          color: Color(0xff475569),
                          size: 22,
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              resolvedAddr ?? 'Halt ${i + 1}',
                              style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.w700,
                                color: textPrimary,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              (resolvedAddr != null && resolvedAddr.trim().isNotEmpty) ? 'Halt ${i + 1} • $timeStr | $durMin min stay' : '$timeStr • Stay duration: $durMin min',
                              style: TextStyle(
                                fontSize: 13,
                                color: textSecondary,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ],
        ],
      ],
    );
  }

  Widget _buildInsightsTab(
    double totalMeters,
    int transitMin,
    int stopMin,
    List<Json> visits,
    Color textPrimary,
    Color textSecondary,
    Color cardColor,
    Color borderColor,
  ) {
    final distStr = totalMeters >= 1000
        ? '${(totalMeters / 1000).toStringAsFixed(1)} km'
        : '${totalMeters.round()} m';
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text(
          'Day Insights',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w700,
            color: textPrimary,
          ),
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: _insightCard(
                title: 'Distance',
                value: distStr,
                icon: Icons.straighten_rounded,
                color: const Color(0xff26c6da),
                cardColor: cardColor,
                borderColor: borderColor,
                textPrimary: textPrimary,
                textSecondary: textSecondary,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _insightCard(
                title: 'In Transit',
                value: '$transitMin min',
                icon: Icons.two_wheeler_rounded,
                color: const Color(0xff42a5f5),
                cardColor: cardColor,
                borderColor: borderColor,
                textPrimary: textPrimary,
                textSecondary: textSecondary,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: _insightCard(
                title: 'Stay Duration',
                value: '$stopMin min',
                icon: Icons.pause_circle_outline_rounded,
                color: const Color(0xffff8a65),
                cardColor: cardColor,
                borderColor: borderColor,
                textPrimary: textPrimary,
                textSecondary: textSecondary,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _insightCard(
                title: 'Completed Visits',
                value: '${visits.length}',
                icon: Icons.check_circle_outline_rounded,
                color: const Color(0xffab47bc),
                cardColor: cardColor,
                borderColor: borderColor,
                textPrimary: textPrimary,
                textSecondary: textSecondary,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _insightCard({
    required String title,
    required String value,
    required IconData icon,
    required Color color,
    required Color cardColor,
    required Color borderColor,
    required Color textPrimary,
    required Color textSecondary,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: color, size: 24),
          const SizedBox(height: 10),
          Text(
            value,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: textPrimary,
            ),
          ),
          const SizedBox(height: 4),
          Text(title, style: TextStyle(fontSize: 12, color: textSecondary)),
        ],
      ),
    );
  }

  List<Marker> _buildMapMarkers({
    required List<LatLng> cleanPoints,
    required List<Json> stops,
    required List<Json> visits,
    required List<Json> events,
  }) {
    final markers = <Marker>[];

    if (cleanPoints.isNotEmpty) {
      markers.add(
        Marker(
          point: cleanPoints.first,
          width: 50,
          height: 50,
          child: GestureDetector(
            onTap: () {
              setState(() => selectedNodeId = 'start');
              _focusLocation(cleanPoints.first);
            },
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: const BoxDecoration(
                color: Color(0xff607d8b),
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black45,
                    blurRadius: 4,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: const Icon(
                Icons.radio_button_checked_rounded,
                color: Colors.white,
                size: 20,
              ),
            ),
          ),
        ),
      );
    }

    final groupedStops = groupMapLocations([
      for (var i = 0; i < stops.length; i++) {...stops[i], 'mapNumber': i + 1},
    ]);
    for (final group in groupedStops) {
      final s = group.first;
      final i = (toNum(s['mapNumber'])?.toInt() ?? 1) - 1;
      final pt = safeLatLng(s['latitude'], s['longitude']);
      if (pt == null) continue;

      markers.add(
        Marker(
          point: pt,
          width: 50,
          height: 50,
          child: GestureDetector(
            onTap: () {
              setState(() => selectedNodeId = 'stop-$i-${s['startUtc']}');
              _followPosition = false;
              _focusLocation(pt);
            },
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: const BoxDecoration(
                color: Color(0xff475569), // Slate gray for stationary stop
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black45,
                    blurRadius: 4,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: const Icon(
                Icons.pause_circle_filled_rounded,
                color: Colors.white,
                size: 20,
              ),
            ),
          ),
        ),
      );
    }

    final groupedVisits = groupMapLocations(visits);
    for (final group in groupedVisits) {
      final v = group.first;
      final pt = safeLatLng(
        v['inLatitude'] ?? v['latitude'],
        v['inLongitude'] ?? v['longitude'],
      );
      if (pt == null) continue;
      final shop = v['shopName']?.toString().trim() ?? 'Visit';

      markers.add(
        Marker(
          point: pt,
          width: 76,
          height: 60,
          child: GestureDetector(
            onTap: () {
              setState(() => selectedNodeId = 'visit-${v['id']}');
              _followPosition = false;
              _focusLocation(pt);
              if (group.length == 1) {
                _showVisitDetailsModal(context, v);
              }
            },
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: const BoxDecoration(
                    color: Color(0xffab47bc),
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black45,
                        blurRadius: 4,
                        offset: Offset(0, 2),
                      ),
                    ],
                  ),
                  child: const Icon(
                    Icons.storefront_rounded,
                    color: Colors.white,
                    size: 16,
                  ),
                ),
                Container(
                  margin: const EdgeInsets.only(top: 2),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 4,
                    vertical: 1,
                  ),
                  decoration: BoxDecoration(
                    color: _darkMode ? const Color(0xff1e1e1e) : Colors.white,
                    borderRadius: BorderRadius.circular(4),
                    border: Border.all(
                      color: const Color(0xffab47bc),
                      width: 1,
                    ),
                  ),
                  child: Text(
                    shop,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 8.5,
                      fontWeight: FontWeight.w700,
                      color: Color(0xffab47bc),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    final lastPt = routeCoordinate(_position);
    if (lastPt != null) {
      final hasPunchOut = events.any((e) => e['type'] == 'PunchOut');
      markers.add(
        Marker(
          key: const ValueKey('user-location-marker'),
          alignment: const Alignment(0, 13 / 24),
          point: lastPt,
          rotate: true,
          width: 180,
          height: 96,
          child: GestureDetector(
            onTap: () {
              setState(() => selectedNodeId = 'end');
              _focusLocation(lastPt);
            },
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(7),
                  decoration: BoxDecoration(
                    color: hasPunchOut
                        ? const Color(0xffef5350)
                        : (_current
                              ? const Color(0xff0284c7)
                              : const Color(0xfff59e0b)),
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white, width: 2.5),
                    boxShadow: const [
                      BoxShadow(
                        color: Colors.black45,
                        blurRadius: 5,
                        offset: Offset(0, 2),
                      ),
                    ],
                  ),
                  child: const Icon(
                    Icons.person_rounded,
                    color: Colors.white,
                    size: 22,
                  ),
                ),
                Container(
                  margin: const EdgeInsets.only(top: 2),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 6,
                    vertical: 2,
                  ),
                  decoration: BoxDecoration(
                    color: _darkMode
                        ? const Color(0xdd1e1e1e)
                        : const Color(0xeeffffff),
                    borderRadius: BorderRadius.circular(8),
                    boxShadow: const [
                      BoxShadow(
                        color: Colors.black26,
                        blurRadius: 3,
                        offset: Offset(0, 1),
                      ),
                    ],
                  ),
                  child: Text(
                    _positionLabel,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: _darkMode
                          ? Colors.white70
                          : const Color(0xff334155),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return markers;
  }

  Widget _buildConnectedTimelineItem({
    required _TimelineEntry item,
    required bool isFirst,
    required bool isLast,
  }) {
    final textPrimary = _darkMode ? Colors.white : const Color(0xff102c4a);
    final textSecondary = _darkMode
        ? const Color(0xff94a3b8)
        : const Color(0xff64748b);
    final cardColor = _darkMode ? const Color(0xff1e1e1e) : Colors.white;
    final borderColor = _darkMode
        ? const Color(0xff2d3135)
        : const Color(0xffe2e8f0);

    // In-Transit / Travel Node
    if (item.type == _TimelineType.travel || item.type == _TimelineType.gap) {
      final distStr = item.distanceMeters != null
          ? (item.distanceMeters! >= 1000
                ? '${(item.distanceMeters! / 1000).toStringAsFixed(1)} km'
                : '${item.distanceMeters!.round()} meters')
          : (item.badge ?? '');
      final durMin = item.end != null
          ? item.end!.difference(item.at).inMinutes
          : 0;
      final timeStr = item.end != null
          ? '${_formatTime(item.at)} – ${_formatTime(item.end!)}'
          : _formatTime(item.at);

      return IntrinsicHeight(
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SizedBox(
              width: 48,
              child: Column(
                children: [
                  Expanded(
                    child: Container(
                      width: 2.5,
                      color: _darkMode
                          ? const Color(0xff3e4246)
                          : const Color(0xffcbd5e1),
                    ),
                  ),
                  Container(
                    width: 24,
                    height: 24,
                    decoration: BoxDecoration(
                      color: _darkMode ? const Color(0xff181a1b) : Colors.white,
                      shape: BoxShape.circle,
                      border: Border.all(color: item.color, width: 1.5),
                    ),
                    child: Icon(item.icon, size: 13, color: item.color),
                  ),
                  Expanded(
                    child: Container(
                      width: 2.5,
                      color: _darkMode
                          ? const Color(0xff3e4246)
                          : const Color(0xffcbd5e1),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: InkWell(
                  borderRadius: BorderRadius.circular(10),
                  onTap: item.coord != null
                      ? () {
                          setState(() => selectedNodeId = item.id);
                          _focusLocation(item.coord!);
                        }
                      : null,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      color: _darkMode
                          ? const Color(0xff1c1f22)
                          : const Color(0xfff1f5f9),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: _darkMode
                            ? const Color(0xff2d3135)
                            : const Color(0xffe2e8f0),
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Row(
                          children: [
                            Icon(item.icon, size: 14, color: item.color),
                            const SizedBox(width: 6),
                            Expanded(
                              child: Text(
                                item.type == _TimelineType.travel
                                    ? (distStr.isNotEmpty && durMin > 0
                                          ? 'Travel • $distStr ($durMin min)'
                                          : (distStr.isNotEmpty
                                                ? 'Travel • $distStr'
                                                : (durMin > 0 ? 'Travel • $durMin min' : 'Travel • In Transit')))
                                    : ((item.title.isNotEmpty && item.title != '-' && !item.title.startsWith('•'))
                                          ? item.title
                                          : (durMin > 0 ? 'Movement • $durMin min' : 'GPS Movement')),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontSize: 12.5,
                                  fontWeight: FontWeight.w700,
                                  color: item.color,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 3),
                        Text(
                          (timeStr.isNotEmpty && timeStr != ' – ' && timeStr != '-')
                              ? (item.subtitle.isNotEmpty && item.subtitle != '-' && !item.subtitle.contains('unknown')
                                  ? '$timeStr • ${item.subtitle}'
                                  : timeStr)
                              : (item.subtitle.isNotEmpty && item.subtitle != '-' ? item.subtitle : 'Recorded route interval'),
                          style: TextStyle(
                            fontSize: 11.5,
                            fontWeight: FontWeight.w600,
                            color: textSecondary,
                          ),
                        ),
                        if (item.coord != null) ...[
                          const SizedBox(height: 4),
                          Row(
                            children: [
                              const Icon(
                                Icons.explore_outlined,
                                size: 12,
                                color: Color(0xff0288d1),
                              ),
                              const SizedBox(width: 4),
                              Expanded(
                                child: Text(
                                  (item.address != null && item.address!.isNotEmpty && item.address != 'Stop location' && item.address != '-')
                                      ? '${item.address!} (${item.coord!.latitude.toStringAsFixed(4)}, ${item.coord!.longitude.toStringAsFixed(4)})'
                                      : '(${item.coord!.latitude.toStringAsFixed(4)}, ${item.coord!.longitude.toStringAsFixed(4)})',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    fontSize: 11,
                                    fontFamily: 'monospace',
                                    color: Color(0xff0288d1),
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      );
    }

    final isSelected = selectedNodeId == item.id;

    // Place / Stop / Event Nodes
    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Vertical connected line & circular icon badge
          SizedBox(
            width: 48,
            child: Column(
              children: [
                if (!isFirst)
                  Container(
                    width: 2.5,
                    height: 14,
                    color: _darkMode
                        ? const Color(0xff3e4246)
                        : const Color(0xffcbd5e1),
                  )
                else
                  const SizedBox(height: 14),
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: item.color,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: item.color.withValues(alpha: 0.35),
                        blurRadius: 6,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Icon(item.icon, color: Colors.white, size: 20),
                ),
                Expanded(
                  child: Container(
                    width: isLast ? 0 : 2.5,
                    color: _darkMode
                        ? const Color(0xff3e4246)
                        : const Color(0xffcbd5e1),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),

          // Content Card
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Material(
                color: isSelected
                    ? (_darkMode
                          ? const Color(0xff1a3344)
                          : const Color(0xffe8f0fe))
                    : cardColor,
                borderRadius: BorderRadius.circular(16),
                child: InkWell(
                  borderRadius: BorderRadius.circular(16),
                  onTap: () {
                    setState(() => selectedNodeId = item.id);
                    if (item.coord != null) {
                      _focusLocation(item.coord!);
                    }
                  },
                  child: Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: isSelected
                            ? const Color(0xff26c6da)
                            : borderColor,
                        width: isSelected ? 1.5 : 1,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(
                            alpha: _darkMode ? 0.2 : 0.03,
                          ),
                          blurRadius: 6,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                item.title,
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w700,
                                  color: textPrimary,
                                ),
                              ),
                            ),
                            if (item.badge != null)
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 8,
                                  vertical: 3,
                                ),
                                decoration: BoxDecoration(
                                  color: item.color.withValues(alpha: 0.15),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Text(
                                  item.badge!,
                                  style: TextStyle(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w700,
                                    color: item.color,
                                  ),
                                ),
                              ),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Text(
                          item.subtitle.isNotEmpty && item.subtitle != '-'
                              ? item.subtitle
                              : (item.address != null && item.address!.isNotEmpty && item.address != '-'
                                  ? item.address!
                                  : (item.coord != null
                                      ? '(${item.coord!.latitude.toStringAsFixed(4)}, ${item.coord!.longitude.toStringAsFixed(4)})'
                                      : 'Activity recorded')),
                          style: TextStyle(fontSize: 13, color: textSecondary),
                        ),
                        if (item.coord != null) ...[
                          const SizedBox(height: 4),
                          Row(
                            children: [
                              const Icon(
                                Icons.pin_drop_outlined,
                                size: 12,
                                color: Color(0xff0288d1),
                              ),
                              const SizedBox(width: 4),
                              Expanded(
                                child: Text(
                                  (item.address != null && item.address!.isNotEmpty && item.address != 'Stop location' && item.address != '-')
                                      ? '${item.address!} (${item.coord!.latitude.toStringAsFixed(4)}, ${item.coord!.longitude.toStringAsFixed(4)})'
                                      : '(${item.coord!.latitude.toStringAsFixed(4)}, ${item.coord!.longitude.toStringAsFixed(4)})',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    fontSize: 11,
                                    color: Color(0xff0288d1),
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                        if (item.departureText != null) ...[
                          const SizedBox(height: 4),
                          Text(
                            item.departureText!,
                            style: const TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: Color(0xff26c6da),
                            ),
                          ),
                        ],
                        if (isSelected && item.coord != null) ...[
                          const SizedBox(height: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 3,
                            ),
                            decoration: BoxDecoration(
                              color: const Color(
                                0xff26c6da,
                              ).withValues(alpha: 0.18),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: const Text(
                              'Focused on map',
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                                color: Color(0xff26c6da),
                              ),
                            ),
                          ),
                        ],
                        if (item.type == _TimelineType.visit &&
                            item.raw != null) ...[
                          if (item.raw!['remarks'] != null ||
                              item.raw!['remark'] != null) ...[
                            const SizedBox(height: 6),
                            Text(
                              '${item.raw!['remarks'] ?? item.raw!['remark']}',
                              style: TextStyle(
                                fontSize: 13,
                                color: textSecondary,
                              ),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                          const SizedBox(height: 8),
                          InkWell(
                            onTap: () =>
                                _showVisitDetailsModal(context, item.raw!),
                            child: const Text(
                              'Tap for full visit details',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                color: Color(0xffab47bc),
                                decoration: TextDecoration.underline,
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

String _formatTime(DateTime dt) {
  final hour = dt.hour % 12 == 0 ? 12 : dt.hour % 12;
  final minute = dt.minute.toString().padLeft(2, '0');
  final ampm = dt.hour < 12 ? 'AM' : 'PM';
  return '$hour:$minute $ampm';
}

String routeEventTitle(Json event) {
  switch (event['type']) {
    case 'PunchIn':
      return 'Punch-in';
    case 'PunchOut':
      return 'Punch-out';
    case 'Login':
      return 'Signed in';
    default:
      return '${event['title'] ?? 'Activity'}'.replaceAll(
        RegExp(r'\bduty\b', caseSensitive: false),
        'Attendance',
      );
  }
}

String routeEventTime(dynamic value) {
  final date = DateTime.tryParse('$value')?.add(businessOffset);
  if (date == null) return 'Time unavailable';
  return _formatTime(date);
}

enum _TimelineType { punchIn, punchOut, login, visit, stop, travel, gap }

class _TimelineEntry {
  final String id, title, subtitle;
  final _TimelineType type;
  final DateTime at;
  final DateTime? end;
  final LatLng? coord;
  final Color color;
  final IconData icon;
  final Json? raw;
  final String? badge, departureText, address;
  final double? distanceMeters;
  final int? stopNumber;
  final bool isMissingVisit;
  _TimelineEntry({
    required this.id,
    required this.type,
    required this.title,
    required this.subtitle,
    required this.at,
    this.end,
    this.coord,
    required this.color,
    required this.icon,
    this.raw,
    this.badge,
    this.departureText,
    this.address,
    this.distanceMeters,
    this.stopNumber,
    this.isMissingVisit = false,
  });
}

class _VisitSelfiePreview extends StatefulWidget {
  final TrackyuController controller;
  final Json visit;
  final bool darkMode;

  const _VisitSelfiePreview({
    required this.controller,
    required this.visit,
    required this.darkMode,
  });

  @override
  State<_VisitSelfiePreview> createState() => _VisitSelfiePreviewState();
}

class _VisitSelfiePreviewState extends State<_VisitSelfiePreview> {
  Uint8List? _inBytes;
  Uint8List? _outBytes;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    TrackyuAddressCache.init();
    _load();
  }

  Future<void> _load() async {
    Json v;
    try {
      v = await localVisitMedia(widget.controller, widget.visit);
    } catch (_) {
      if (mounted) setState(() => _loading = false);
      return;
    }
    try {
      _inBytes = await loadVisitPhoto(widget.controller, v, 'in');
    } catch (_) {
      // Arrival photo not cached or offline
    }
    if (hasDeparturePhoto(v)) {
      try {
        _outBytes = await loadVisitPhoto(widget.controller, v, 'out');
      } catch (_) {
        // Departure photo not cached or offline
      }
    }

    if (mounted) {
      setState(() {
        _loading = false;
      });
    }
  }

  void _showFullScreen(Uint8List bytes, String title) {
    showDialog(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.all(12),
        child: Stack(
          alignment: Alignment.topRight,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: Container(
                color: Colors.black,
                child: InteractiveViewer(
                  maxScale: 4.0,
                  child: Image.memory(bytes, fit: BoxFit.contain),
                ),
              ),
            ),
            Positioned(
              top: 10,
              right: 10,
              child: CircleAvatar(
                backgroundColor: Colors.black54,
                radius: 18,
                child: IconButton(
                  padding: EdgeInsets.zero,
                  icon: const Icon(Icons.close, color: Colors.white, size: 20),
                  onPressed: () => Navigator.pop(ctx),
                ),
              ),
            ),
            Positioned(
              bottom: 12,
              left: 12,
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 4,
                ),
                decoration: BoxDecoration(
                  color: Colors.black87,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  title,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPhotoCard(Uint8List bytes, String label) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              label,
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.5,
                color: widget.darkMode
                    ? Colors.white70
                    : const Color(0xff475569),
              ),
            ),
            const Text(
              'Tap to zoom',
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w600,
                color: Color(0xff26c6da),
              ),
            ),
          ],
        ),
        const SizedBox(height: 6),
        InkWell(
          onTap: () => _showFullScreen(bytes, label),
          borderRadius: BorderRadius.circular(12),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Container(
              height: 190,
              width: double.infinity,
              decoration: BoxDecoration(
                color: widget.darkMode
                    ? const Color(0xff25282c)
                    : const Color(0xfff1f5f9),
                border: Border.all(
                  color: widget.darkMode
                      ? const Color(0xff374151)
                      : const Color(0xffe2e8f0),
                ),
              ),
              child: Stack(
                fit: StackFit.expand,
                children: [
                  Image.memory(bytes, fit: BoxFit.cover),
                  Positioned(
                    bottom: 8,
                    right: 8,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.black.withValues(alpha: 0.65),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.zoom_in, color: Colors.white, size: 14),
                          SizedBox(width: 4),
                          Text(
                            'Full photo',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return Container(
        height: 120,
        width: double.infinity,
        decoration: BoxDecoration(
          color: widget.darkMode
              ? const Color(0xff25282c)
              : const Color(0xfff8fafd),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: widget.darkMode
                ? const Color(0xff374151)
                : const Color(0xffe2e8f0),
          ),
        ),
        child: const Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(
                width: 24,
                height: 24,
                child: CircularProgressIndicator(strokeWidth: 2.2),
              ),
              SizedBox(height: 10),
              Text(
                'Loading visit selfie...',
                style: TextStyle(fontSize: 12, color: Color(0xff94a3b8)),
              ),
            ],
          ),
        ),
      );
    }

    if (_inBytes == null && _outBytes == null) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: widget.darkMode
              ? const Color(0xff25282c)
              : const Color(0xfff8fafd),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: widget.darkMode
                ? const Color(0xff374151)
                : const Color(0xffe2e8f0),
          ),
        ),
        child: Row(
          children: [
            Icon(
              Icons.no_photography_outlined,
              size: 20,
              color: widget.darkMode ? Colors.white54 : Colors.black45,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                'No selfie recorded for this visit',
                style: TextStyle(
                  fontSize: 12,
                  color: widget.darkMode ? Colors.white60 : Colors.black54,
                ),
              ),
            ),
          ],
        ),
      );
    }

    return Column(
      children: [
        if (_inBytes != null) _buildPhotoCard(_inBytes!, 'Arrival Selfie'),
        if (_inBytes != null && _outBytes != null) const SizedBox(height: 12),
        if (_outBytes != null) _buildPhotoCard(_outBytes!, 'Departure Selfie'),
      ],
    );
  }
}
