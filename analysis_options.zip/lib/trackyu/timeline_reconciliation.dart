import 'api.dart';
import 'route_presentation.dart';
import 'package:latlong2/latlong.dart';

const businessOffset = Duration(minutes: 330);
String businessDay(DateTime utc) =>
    utc.toUtc().add(businessOffset).toIso8601String().substring(0, 10);
DateTime? instant(dynamic value) {
  if (value == null) return null;
  final text = value.toString();
  // Timestamp contracts are UTC/offset-bearing. Never interpret a naive time in the device zone.
  if (!RegExp(r'(Z|[+-]\d\d:\d\d)$', caseSensitive: false).hasMatch(text)) {
    return null;
  }
  return DateTime.tryParse(text)?.toUtc();
}

DateTime businessDisplay(DateTime utc) => utc.toUtc().add(businessOffset);
String coordinateKey(Json? row) {
  final p = routeCoordinate(row);
  return p == null
      ? ''
      : '${p.latitude.toStringAsFixed(4)},${p.longitude.toStringAsFixed(4)}';
}

List<Json> rowsOf(dynamic value) =>
    (value is List
            ? value
            : value is Map
            ? value['rows']
            : null)
        is List
    ? ((value is List ? value : value['rows']) as List)
          .whereType<Map>()
          .map((e) => Map<String, dynamic>.from(e))
          .toList()
    : [];
bool rowBelongs(Json row, String owner, String baseUrl) =>
    (row['userId'] == null ||
        '${row['userId']}'.toLowerCase() == owner.toLowerCase()) &&
    (row['baseUrl'] == null || row['baseUrl'] == baseUrl);

Set<String> _visitIds(Json row) => {
  if (row['requestId'] != null) 'request:${row['requestId']}',
  for (final key in ['id', 'localId', 'serverId'])
    if (row[key] != null) 'id:${row[key]}',
};
Json mergeRich(Json older, Json newer) {
  final merged = <String, dynamic>{...older};
  for (final entry in newer.entries) {
    if (entry.value != null && entry.value != '') {
      merged[entry.key] = entry.value;
    }
  }
  // Checkout is monotonic: an older open copy must never reopen a finished local record.
  for (final key in ['checkOutUtc', 'punchOutUtc']) {
    if (older[key] != null && newer[key] == null) merged[key] = older[key];
  }
  return merged;
}

Json? reconcileAttendance(Json? older, Json? newer) {
  if (older == null) return newer;
  if (newer == null) return older;
  final a = instant(older['punchInUtc']), b = instant(newer['punchInUtc']);
  final same = a != null && b != null
      ? a == b
      : [older['id'], older['localId'], older['serverId']]
            .where((v) => v != null)
            .any(
              (v) => [
                newer['id'],
                newer['localId'],
                newer['serverId'],
              ].contains(v),
            );
  if (!same) return a != null && (b == null || a.isAfter(b)) ? older : newer;
  return mergeRich(older, newer);
}

bool visitOnDay(Json row, String day) {
  final at = instant(row['checkInUtc']);
  if (at != null) return businessDay(at) == day;
  if (row['checkInUtc'] != null) return false;
  final declared = '${row['workDate'] ?? ''}';
  return RegExp(r'^\d{4}-\d{2}-\d{2}($|T)').hasMatch(declared) &&
      declared.substring(0, 10) == day;
}

List<Json> reconcileVisits(
  Iterable<Json> sources,
  Iterable<Json> pending,
  String day,
  String owner,
  String baseUrl,
) {
  final merged = <Json>[];
  void add(Json row) {
    if (!rowBelongs(row, owner, baseUrl)) return;
    final ids = _visitIds(row);
    final indices = <int>[];
    for (var i = 0; i < merged.length; i++) {
      if (ids.isNotEmpty && _visitIds(merged[i]).intersection(ids).isNotEmpty) {
        indices.add(i);
        ids.addAll(_visitIds(merged[i]));
      }
    }
    if (indices.isEmpty) {
      merged.add({...row});
      return;
    }
    var value = merged[indices.first];
    for (final i in indices.skip(1)) {
      value = mergeRich(value, merged[i]);
    }
    value = mergeRich(value, row);
    for (final i in indices.reversed) {
      merged.removeAt(i);
    }
    merged.add(value);
  }

  for (final row in sources) {
    add(row);
  }
  for (final op in pending) {
    // Legacy unowned queues must not be attributed to whichever account signs in next.
    if (op['scope'] != '$baseUrl|$owner') continue;
    final body = op['body'];
    if (body is! Map) continue;
    final b = Map<String, dynamic>.from(body);
    final at = instant(b['capturedAtUtc']);
    if (at == null) continue;
    final finish = op['finish'] == true || '${op['route']}'.endsWith('/finish');
    if (finish) {
      final target = merged
          .where((r) => _visitIds(r).contains('id:${b['id'] ?? op['localId']}'))
          .firstOrNull;
      if (target != null) {
        add({
          ...target,
          ...b,
          'requestId': target['requestId'],
          'checkInUtc': target['checkInUtc'],
          'checkOutUtc': at.toIso8601String(),
        });
      }
    } else {
      add({
        ...b,
        if (op['localId'] != null) 'localId': op['localId'],
        'checkInUtc': at.toIso8601String(),
      });
    }
  }
  return merged.where((r) => visitOnDay(r, day)).toList()
    ..sort((a, b) => '${a['checkInUtc']}'.compareTo('${b['checkInUtc']}'));
}

List<Json> mergePoints(
  Iterable<Json> points,
  String day,
  String owner,
  String baseUrl,
) {
  final byId = <String, Json>{};
  final byFix = <String, String>{};
  for (final original in points) {
    if (!rowBelongs(original, owner, baseUrl)) continue;
    final at = instant(original['capturedAtUtc']);
    if (at == null ||
        businessDay(at) != day ||
        routeCoordinate(original) == null) {
      continue;
    }
    final p = {
      ...original,
      'mode': original['mode'] ?? original['attendanceMode'],
      'capturedAtUtc': at.toIso8601String(),
    };
    final fix =
        '${p['mode']}:${p['attendanceId']}:${at.microsecondsSinceEpoch}:${p['latitude']}:${p['longitude']}';
    final id = '${p['sampleId'] ?? p['id'] ?? fix}';
    final key = byFix[fix] ?? id;
    byFix[fix] = key;
    byId[key] = byId[key] == null ? p : mergeRich(byId[key]!, p);
  }
  return byId.values.toList()..sort(
    (a, b) =>
        instant(a['capturedAtUtc'])!.compareTo(instant(b['capturedAtUtc'])!),
  );
}

bool connectedFixes(Json a, Json b) {
  final from = instant(a['capturedAtUtc']), to = instant(b['capturedAtUtc']);
  final p = routeCoordinate(a), q = routeCoordinate(b);
  if (from == null || to == null || p == null || q == null) return false;
  final seconds = to.difference(from).inMilliseconds / 1000;
  if (seconds <= 0 ||
      seconds > 180 ||
      a['attendanceId'] != b['attendanceId'] ||
      (a['mode'] ?? a['attendanceMode']) !=
          (b['mode'] ?? b['attendanceMode']) ||
      a['displaySampled'] == true ||
      b['displaySampled'] == true ||
      b['breakBefore'] == true) {
    return false;
  }
  final meters = const Distance()(p, q);
  return !(meters > 100 && meters / seconds > 60);
}

List<List<Json>> recordedSegments(List<Json> points) {
  final result = <List<Json>>[];
  Json? previous;
  for (final point in points) {
    final accuracy = toNum(point['accuracyMeters']);
    if (accuracy == null ||
        accuracy > 50 ||
        accuracy < 0 ||
        point['isAccurate'] == false) {
      previous = null;
      continue;
    }
    final boundary = previous == null || !connectedFixes(previous, point);
    if (boundary) result.add([]);
    result.last.add({...point, if (boundary) 'breakBefore': true});
    previous = point;
  }
  return result;
}

List<Json> recordingGaps(List<List<Json>> segments) {
  final gaps = <Json>[];
  for (var i = 1; i < segments.length; i++) {
    final a = segments[i - 1].last, b = segments[i].first;
    final start = instant(a['capturedAtUtc']),
        end = instant(b['capturedAtUtc']);
    if (start == null || end == null || !end.isAfter(start)) continue;

    final p = routeCoordinate(a), q = routeCoordinate(b);
    final meters = (p != null && q != null) ? const Distance()(p, q) : null;
    final diffSec = end.difference(start).inSeconds;

    if (diffSec <= 180 &&
        a['attendanceId'] == b['attendanceId'] &&
        (a['mode'] ?? a['attendanceMode']) ==
            (b['mode'] ?? b['attendanceMode'])) {
      continue;
    }

    final isStationary = meters != null && meters < 75;

    gaps.add({
      'startUtc': start.toIso8601String(),
      'endUtc': end.toIso8601String(),
      'reason': isStationary
          ? 'Halt / Stationary'
          : (diffSec > 1800 ? 'GPS interval (>30 min)' : 'Between GPS fixes'),
      'isStationary': isStationary,
      'latitude': a['latitude'] ?? b['latitude'],
      'longitude': a['longitude'] ?? b['longitude'],
      'endLatitude': b['latitude'],
      'endLongitude': b['longitude'],
      'distanceMeters': meters,
      'address': a['address'] ?? b['address'],
      'fromPoint': a,
      'toPoint': b,
    });
  }
  return gaps;
}
List<Json> detectedStops(List<List<Json>> segments) {
  final stops = <Json>[];
  for (final segment in segments) {
    Json? first, last;
    var count = 0;
    void finish() {
      if (first != null &&
          last != null &&
          count >= 3 &&
          instant(
                last!['capturedAtUtc'],
              )!.difference(instant(first!['capturedAtUtc'])!).inMinutes >=
              10) {
        stops.add({
          'startUtc': first!['capturedAtUtc'],
          'endUtc': last!['capturedAtUtc'],
          'latitude': first!['latitude'],
          'longitude': first!['longitude'],
          'attendanceId': first!['attendanceId'],
          'mode': first!['mode'],
          'sampleCount': count,
        });
      }
      first = null;
      last = null;
      count = 0;
    }

    for (final p in segment) {
      if (first != null &&
          const Distance()(routeCoordinate(first)!, routeCoordinate(p)!) > 50) {
        finish();
      }
      first ??= p;
      last = p;
      count++;
    }
    finish();
  }
  return groupLocationStops(stops, segments.expand((s) => s).toList());
}

double recordedDistance(List<List<Json>> segments) {
  const distCalc = Distance();
  var sum = 0.0;
  for (final segment in segments) {
    if (segment.length < 2) continue;

    LatLng? anchor = routeCoordinate(segment.first);
    DateTime? anchorTime = instant(segment.first['capturedAtUtc']);

    for (var i = 1; i < segment.length; i++) {
      final prev = segment[i - 1];
      final curr = segment[i];
      final currCoord = routeCoordinate(curr);
      final currTime = instant(curr['capturedAtUtc']);

      if (currCoord == null) continue;

      if (!connectedFixes(prev, curr)) {
        // Discontinuity/gap: restart anchor at currCoord without adding gap distance
        anchor = currCoord;
        anchorTime = currTime;
        continue;
      }

      anchor ??= routeCoordinate(prev);
      if (anchor == null) {
        anchor = currCoord;
        anchorTime = currTime;
        continue;
      }

      final moved = distCalc(anchor, currCoord);
      final acc = toNum(curr['accuracyMeters']) ?? 20.0;
      // Movement threshold: ignore GPS jitter within 25m or accuracy radius
      final threshold = (acc > 25.0 ? acc : 25.0).clamp(20.0, 45.0);

      if (moved >= threshold) {
        // Legitimate movement out of the stationary bubble
        if (anchorTime != null && currTime != null) {
          final dtSec = currTime.difference(anchorTime).inSeconds.abs();
          // Filter unrealistic teleportation jumps (> 150 km/h = 42 m/s)
          if (dtSec > 0 && (moved / dtSec) > 42.0) {
            anchor = currCoord;
            anchorTime = currTime;
            continue;
          }
        }
        sum += moved;
        anchor = currCoord;
        anchorTime = currTime;
      }
    }
  }
  return sum;
}

List<Json> attendanceEvents(Iterable<Json> attendances, String day) {
  final result = <String, Json>{};
  for (final a in attendances) {
    for (final out in [false, true]) {
      final at = instant(a[out ? 'punchOutUtc' : 'punchInUtc']);
      if (at == null || businessDay(at) != day) continue;
      final type = out ? 'PunchOut' : 'PunchIn';
      final key = '$type:${at.toIso8601String()}';
      result[key] = {
        'id': key,
        'type': type,
        'title': out ? 'Punch-out' : 'Punch-in',
        'atUtc': at.toIso8601String(),
        'latitude': a[out ? 'outLatitude' : 'inLatitude'],
        'longitude': a[out ? 'outLongitude' : 'inLongitude'],
      };
    }
  }
  return result.values.toList();
}

List<Json> dayEvents(Iterable<Json> events, String day) {
  final result = <String, Json>{};
  for (final row in events) {
    final at = instant(row['atUtc']);
    if (at == null || businessDay(at) != day) continue;
    final key = '${row['type']}:${at.toIso8601String()}';
    result[key] = result[key] == null ? {...row} : mergeRich(result[key]!, row);
  }
  return result.values.toList()
    ..sort((a, b) => '${a['atUtc']}'.compareTo('${b['atUtc']}'));
}
