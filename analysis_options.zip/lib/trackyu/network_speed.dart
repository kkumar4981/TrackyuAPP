import 'dart:async';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'api.dart';
import 'controller.dart';

enum NetworkQuality { offline, slow, good, fast }

class NetworkStatus {
  final bool isOnline;
  final String typeName; // 'WiFi', '4G/5G', 'Offline'
  final int? latencyMs;
  final NetworkQuality quality;
  final DateTime lastChecked;

  const NetworkStatus({
    required this.isOnline,
    required this.typeName,
    this.latencyMs,
    required this.quality,
    required this.lastChecked,
  });

  String get speedLabel {
    if (!isOnline) return 'No Internet';
    if (latencyMs == null) return '$typeName • Checking...';
    if (quality == NetworkQuality.fast) return '$typeName • Fast (${latencyMs}ms) ⚡';
    if (quality == NetworkQuality.good) return '$typeName • Good (${latencyMs}ms)';
    if (quality == NetworkQuality.slow) return '$typeName • Slow (${latencyMs}ms)';
    return '$typeName • Offline';
  }

  String get compactLabel {
    if (!isOnline) return 'Offline';
    if (latencyMs == null) return typeName;
    return '$typeName • ${latencyMs}ms';
  }

  Color get statusColor {
    if (!isOnline) return const Color(0xffef4444);
    if (quality == NetworkQuality.fast) return const Color(0xff10b981);
    if (quality == NetworkQuality.good) return const Color(0xff0284c7);
    if (quality == NetworkQuality.slow) return const Color(0xfff59e0b);
    return const Color(0xffef4444);
  }

  IconData get icon {
    if (!isOnline) return Icons.wifi_off_rounded;
    if (typeName == 'WiFi') return Icons.wifi_rounded;
    return Icons.signal_cellular_alt_rounded;
  }
}

class NetworkQualityMonitor extends ChangeNotifier {
  final TrackyuApi api;
  NetworkQualityMonitor(this.api);

  static NetworkQualityMonitor? _instance;
  static NetworkQualityMonitor instance(TrackyuApi api) =>
      _instance ??= NetworkQualityMonitor(api);

  NetworkStatus _status = NetworkStatus(
    isOnline: true,
    typeName: 'WiFi',
    latencyMs: null,
    quality: NetworkQuality.good,
    lastChecked: DateTime.now(),
  );

  NetworkStatus get status => _status;

  Timer? _timer;
  StreamSubscription? _sub;
  bool _disposed = false;
  bool _probing = false;

  void start() {
    _timer?.cancel();
    _sub?.cancel();

    // Listen to connectivity changes
    _sub = Connectivity().onConnectivityChanged.listen((results) {
      probeNow();
    });

    // Probe latency every 15 seconds
    _timer = Timer.periodic(const Duration(seconds: 15), (_) => probeNow());

    // Immediate initial probe
    probeNow();
  }

  Future<void> probeNow() async {
    if (_probing || _disposed) return;
    _probing = true;
    try {
      final connectivityList = await Connectivity().checkConnectivity();
      final hasConn = connectivityList.any((r) => r != ConnectivityResult.none);

      String type = 'Mobile data';
      if (connectivityList.contains(ConnectivityResult.wifi)) {
        type = 'WiFi';
      } else if (connectivityList.contains(ConnectivityResult.mobile)) {
        type = '4G/5G';
      } else if (connectivityList.contains(ConnectivityResult.ethernet)) {
        type = 'LAN';
      }

      if (!hasConn) {
        if (!_disposed) {
          _status = NetworkStatus(
            isOnline: false,
            typeName: 'Offline',
            quality: NetworkQuality.offline,
            lastChecked: DateTime.now(),
          );
          notifyListeners();
        }
        return;
      }

      final watch = Stopwatch()..start();
      int latency = 0;
      bool ok = false;
      try {
        final res = await api.dio.get(
          'Health',
          options: Options(
            receiveTimeout: const Duration(seconds: 4),
            sendTimeout: const Duration(seconds: 4),
          ),
        );
        watch.stop();
        latency = watch.elapsedMilliseconds;
        ok = res.data is Map && res.data['success'] == true;
      } catch (_) {
        ok = false;
      }

      if (_disposed) return;

      if (!ok) {
        _status = NetworkStatus(
          isOnline: false,
          typeName: type,
          quality: NetworkQuality.offline,
          lastChecked: DateTime.now(),
        );
      } else {
        NetworkQuality q;
        if (latency < 180) {
          q = NetworkQuality.fast;
        } else if (latency < 450) {
          q = NetworkQuality.good;
        } else {
          q = NetworkQuality.slow;
        }
        _status = NetworkStatus(
          isOnline: true,
          typeName: type,
          latencyMs: latency,
          quality: q,
          lastChecked: DateTime.now(),
        );
      }
      notifyListeners();
    } catch (_) {
    } finally {
      _probing = false;
    }
  }

  @override
  void dispose() {
    _disposed = true;
    _timer?.cancel();
    _sub?.cancel();
    super.dispose();
  }
}

class SyncNetworkAppBarPill extends StatelessWidget {
  final TrackyuController controller;
  final NetworkQualityMonitor network;
  final bool busy;
  final VoidCallback onSync;

  const SyncNetworkAppBarPill({
    super.key,
    required this.controller,
    required this.network,
    required this.busy,
    required this.onSync,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = controller.isDarkMode;
    final isSyncing = busy || controller.isSyncing;
    final pending = controller.pendingCount;
    final isOnline = network.status.isOnline;

    if (isSyncing) {
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
          color: isDark ? const Color(0xff0c2a42) : const Color(0xfff0f9ff),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: const Color(0xff38bdf8),
            width: 1.2,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(
              width: 12,
              height: 12,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                color: Color(0xff0284c7),
              ),
            ),
            const SizedBox(width: 6),
            Text(
              'Syncing...',
              style: TextStyle(
                color: isDark ? const Color(0xff38bdf8) : const Color(0xff0284c7),
                fontSize: 11.5,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      );
    }

    if (!isOnline) {
      return Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () {
            network.probeNow();
            onSync();
          },
          borderRadius: BorderRadius.circular(16),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
            decoration: BoxDecoration(
              color: isDark ? const Color(0xff3f1218) : const Color(0xfffff1f2),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: const Color(0xfff43f5e),
                width: 1.2,
              ),
            ),
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  Icons.wifi_off_rounded,
                  size: 14,
                  color: Color(0xffe11d48),
                ),
                SizedBox(width: 4),
                Text(
                  'No Internet',
                  style: TextStyle(
                    color: Color(0xffe11d48),
                    fontSize: 11.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    if (pending > 0) {
      return Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onSync,
          borderRadius: BorderRadius.circular(16),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
            decoration: BoxDecoration(
              color: isDark ? const Color(0xff2d1704) : const Color(0xfffff7ed),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: const Color(0xfff97316),
                width: 1.2,
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(
                  Icons.cloud_upload_rounded,
                  size: 14,
                  color: Color(0xffea580c),
                ),
                const SizedBox(width: 4),
                Text(
                  '$pending pending • Upload ⚡',
                  style: const TextStyle(
                    color: Color(0xffea580c),
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    // Connected & Synced
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () {
          network.probeNow();
          onSync();
        },
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
          decoration: BoxDecoration(
            color: isDark
                ? const Color(0xff064e3b).withValues(alpha: 0.4)
                : const Color(0xffecfdf5),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: isDark
                  ? const Color(0xff059669).withValues(alpha: 0.6)
                  : const Color(0xffa7f3d0),
              width: 1.0,
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                network.status.icon,
                size: 13,
                color: network.status.statusColor,
              ),
              const SizedBox(width: 4),
              Text(
                network.status.compactLabel,
                style: TextStyle(
                  color: network.status.statusColor,
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class NetworkSyncStatusCard extends StatelessWidget {
  final TrackyuController controller;
  final NetworkQualityMonitor network;
  final VoidCallback onSync;

  const NetworkSyncStatusCard({
    super.key,
    required this.controller,
    required this.network,
    required this.onSync,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = controller.isDarkMode;
    final status = network.status;
    final pending = controller.pendingCount;
    final isSyncing = controller.isSyncing;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xff181b20) : Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: isDark ? const Color(0xff2d3135) : const Color(0xffe2e8f0),
          width: 1.0,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: isDark ? 0.2 : 0.03),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header: Internet speed & connection status
          Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: status.statusColor.withValues(alpha: isDark ? 0.2 : 0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(
                  status.icon,
                  color: status.statusColor,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Wrap(
                      spacing: 6,
                      runSpacing: 4,
                      crossAxisAlignment: WrapCrossAlignment.center,
                      children: [
                        Text(
                          'Internet: ${status.typeName}',
                          style: TextStyle(
                            fontSize: 13.5,
                            fontWeight: FontWeight.w700,
                            color: isDark ? Colors.white : const Color(0xff0f172a),
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: status.statusColor.withValues(alpha: isDark ? 0.25 : 0.12),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(
                            status.isOnline
                                ? (status.latencyMs != null
                                    ? '${status.latencyMs}ms • ${status.quality == NetworkQuality.fast ? "Fast ⚡" : (status.quality == NetworkQuality.good ? "Good" : "Slow")}'
                                    : 'Connected')
                                : 'Offline',
                            style: TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.w700,
                              color: status.statusColor,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 2),
                    Text(
                      status.isOnline
                          ? 'Server connection active & responding.'
                          : 'No internet connection detected.',
                      style: TextStyle(
                        fontSize: 11,
                        color: isDark ? const Color(0xff94a3b8) : const Color(0xff64748b),
                      ),
                    ),
                  ],
                ),
              ),
              IconButton(
                tooltip: 'Test network speed & sync',
                icon: const Icon(Icons.refresh_rounded, size: 18),
                color: isDark ? const Color(0xff94a3b8) : const Color(0xff64748b),
                onPressed: () {
                  network.probeNow();
                  onSync();
                },
              ),
            ],
          ),

          // Divider
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 10),
            child: Divider(
              height: 1,
              color: isDark ? const Color(0xff2d3135) : const Color(0xfff1f5f9),
            ),
          ),

          // Sync status row
          if (isSyncing)
            Row(
              children: [
                const SizedBox(
                  width: 14,
                  height: 14,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: Color(0xff0284c7),
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  'Syncing in progress... Uploading data.',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: isDark ? const Color(0xff38bdf8) : const Color(0xff0284c7),
                  ),
                ),
              ],
            )
          else if (pending > 0)
            Row(
              children: [
                Expanded(
                  child: Row(
                    children: [
                      const Icon(
                        Icons.cloud_upload_outlined,
                        size: 16,
                        color: Color(0xffea580c),
                      ),
                      const SizedBox(width: 6),
                      Flexible(
                        child: Text(
                          '$pending pending sync',
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: Color(0xffea580c),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                FilledButton.icon(
                  style: FilledButton.styleFrom(
                    backgroundColor: const Color(0xffea580c),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    minimumSize: Size.zero,
                    tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    elevation: 0,
                  ),
                  onPressed: onSync,
                  icon: const Icon(Icons.bolt_rounded, size: 14),
                  label: const Text(
                    'Upload fast ⚡',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],
            )
          else
            Row(
              children: [
                const Icon(
                  Icons.check_circle_rounded,
                  size: 15,
                  color: Color(0xff10b981),
                ),
                const SizedBox(width: 6),
                Text(
                  'All phone records synced with server.',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                    color: isDark ? const Color(0xff94a3b8) : const Color(0xff64748b),
                  ),
                ),
              ],
            ),
        ],
      ),
    );
  }
}
