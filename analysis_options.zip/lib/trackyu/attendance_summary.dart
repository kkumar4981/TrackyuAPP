import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'controller.dart';
import 'working_hours.dart';
import 'selfie_view.dart';

class AttendanceSummary extends StatefulWidget {
  final TrackyuController controller;
  final String status;
  const AttendanceSummary({
    super.key,
    required this.controller,
    required this.status,
  });
  @override
  State<AttendanceSummary> createState() => _AttendanceSummaryState();
}

class _AttendanceSummaryState extends State<AttendanceSummary> {
  Future<Uint8List>? inPhoto;
  String? inPhotoKey;

  @override
  void initState() {
    super.initState();
    sync();
  }

  @override
  void didUpdateWidget(AttendanceSummary old) {
    super.didUpdateWidget(old);
    sync();
  }

  void sync() {
    final c = widget.controller;
    final id = c.attendance?['serverId'] ?? c.attendance?['id'];
    final key = c.attendance?['hasSelfie'] == true
        ? '::'
        : null;
    if (key == inPhotoKey) return;
    inPhotoKey = key;
    final localBytes = _getInSelfieBytes(c);
    if (localBytes != null) {
      inPhoto = Future.value(localBytes);
    } else {
      final numId = id is num ? id.toInt() : int.tryParse('') ?? 0;
      inPhoto = key == null || numId < 1 || numId > 1000000000
          ? null
          : c.api.attendanceSelfie(c.isField ? 'Field' : 'Office', numId);
    }
  }

  String _formatTime(dynamic utc) {
    if (utc == null) return '--:--';
    final time = DateTime.tryParse(utc.toString())?.toLocal();
    if (time == null) return '--:--';
    final hour = time.hour;
    final h = hour == 0 ? 12 : (hour > 12 ? hour - 12 : hour);
    final m = time.minute.toString().padLeft(2, '0');
    final ampm = hour >= 12 ? 'pm' : 'am';
    return '$h:$m $ampm';
  }

  Uint8List? _getInSelfieBytes(TrackyuController c) {
    final att = c.attendance;
    final b64 = att?['punchInPhotoBase64'] ?? att?['selfieBase64'] ?? att?['photoBase64'];
    if (b64 is! String || b64.trim().isEmpty) return null;
    try {
      final clean = b64.replaceFirst(RegExp(r'^data:image/[^;]+;base64,'), '').trim();
      final bytes = base64Decode(clean);
      return bytes.isEmpty ? null : bytes;
    } catch (_) {
      return null;
    }
  }

  Uint8List? _getOutSelfieBytes() {
    final b64 = widget.controller.outSelfieBase64;
    if (b64 == null || b64.isEmpty) return null;
    try {
      return base64Decode(b64);
    } catch (_) {
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.controller;
    final outBytes = _getOutOutSelfieBytesSafe();

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xff0d233a), Color(0xff164264)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(
          color: Colors.white.withValues(alpha: 0.10),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0xff0d233a).withValues(alpha: 0.35),
            blurRadius: 18,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header status pill
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: Colors.white.withValues(alpha: 0.15),
                width: 0.8,
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  Icons.fiber_manual_record_rounded,
                  size: 7,
                  color: c.onDuty
                      ? const Color(0xff34d399)
                      : const Color(0xff60a5fa),
                ),
                const SizedBox(width: 6),
                Flexible(
                  child: Text(
                    widget.status,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                      fontSize: 11.5,
                      letterSpacing: 0.2,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          // Total working hours in a single row
          WorkingHoursDisplay(controller: c, showSubtitle: false, inRow: true),
          const SizedBox(height: 14),
          // Dual Cards: Punch-In & Punch-Out side by side with both selfies
          Row(
            children: [
              // Punch-In Card with Check-In Selfie
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.07),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: Colors.white.withValues(alpha: 0.12),
                      width: 0.8,
                    ),
                  ),
                  child: Row(
                    children: [
                      // Check-in selfie thumbnail
                      _inPhotoThumbnail(c),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            FittedBox(
                              fit: BoxFit.scaleDown,
                              alignment: Alignment.centerLeft,
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: const [
                                  Icon(
                                    Icons.login_rounded,
                                    size: 11,
                                    color: Color(0xff34d399),
                                  ),
                                  SizedBox(width: 3),
                                  Text(
                                    'PUNCH IN',
                                    style: TextStyle(
                                      fontSize: 9,
                                      fontWeight: FontWeight.w700,
                                      color: Color(0xff94a3b8),
                                      letterSpacing: 0.3,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 1),
                            FittedBox(
                              fit: BoxFit.scaleDown,
                              alignment: Alignment.centerLeft,
                              child: Text(
                                _formatTime(c.attendance?['punchInUtc']),
                                style: const TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w800,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                            const FittedBox(
                              fit: BoxFit.scaleDown,
                              alignment: Alignment.centerLeft,
                              child: Text(
                                'Check-in selfie',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontSize: 8.5,
                                  color: Color(0xff34d399),
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 10),
              // Punch-Out Card with Check-Out Selfie
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.07),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: Colors.white.withValues(alpha: 0.12),
                      width: 0.8,
                    ),
                  ),
                  child: Row(
                    children: [
                      // Check-out selfie thumbnail
                      _outPhotoThumbnail(c, outBytes),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            FittedBox(
                              fit: BoxFit.scaleDown,
                              alignment: Alignment.centerLeft,
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: const [
                                  Icon(
                                    Icons.logout_rounded,
                                    size: 11,
                                    color: Color(0xff60a5fa),
                                  ),
                                  SizedBox(width: 3),
                                  Text(
                                    'PUNCH OUT',
                                    style: TextStyle(
                                      fontSize: 9,
                                      fontWeight: FontWeight.w700,
                                      color: Color(0xff94a3b8),
                                      letterSpacing: 0.3,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 1),
                            FittedBox(
                              fit: BoxFit.scaleDown,
                              alignment: Alignment.centerLeft,
                              child: Text(
                                _formatTime(c.attendance?['punchOutUtc']),
                                style: const TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w800,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                            FittedBox(
                              fit: BoxFit.scaleDown,
                              alignment: Alignment.centerLeft,
                              child: Text(
                                outBytes != null
                                    ? 'Check-out selfie'
                                    : (c.completed
                                          ? 'Tap to capture'
                                          : 'Pending'),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontSize: 8.5,
                                  color: outBytes != null
                                      ? const Color(0xff60a5fa)
                                      : const Color(0xff94a3b8),
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Uint8List? _getOutOutSelfieBytesSafe() {
    return _getOutSelfieBytes();
  }

  Widget _inPhotoThumbnail(TrackyuController c) {
    return InkWell(
      onTap: () {
        final raw = _getInSelfieBytes(c);
        final rawId = c.attendance?['serverId'] ?? c.attendance?['id'];
        final numId = rawId is num ? rawId.toInt() : int.tryParse('') ?? 0;
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => AttendanceSelfiePage(
              controller: c,
              mode: c.isField ? 'Field' : 'Office',
              attendanceId: numId,
              rawBytes: raw,
              title: 'Check-in selfie',
            ),
          ),
        );
      },
      borderRadius: BorderRadius.circular(10),
      child: Container(
        width: 44,
        height: 44,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: const Color(0xff10b981).withValues(alpha: 0.6),
            width: 1.2,
          ),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(8.8),
          child: inPhoto != null
              ? FutureBuilder<Uint8List>(
                  future: inPhoto,
                  builder: (context, snapshot) {
                    if (snapshot.hasData) {
                      return Image.memory(
                        snapshot.data!,
                        fit: BoxFit.cover,
                        errorBuilder: (_, _, _) => const Icon(
                          Icons.broken_image_outlined,
                          color: Colors.white70,
                          size: 18,
                        ),
                      );
                    }
                    return ColoredBox(
                      color: const Color(0xff10b981).withValues(alpha: 0.15),
                      child: const Icon(
                        Icons.photo_camera_rounded,
                        color: Color(0xff34d399),
                        size: 18,
                      ),
                    );
                  },
                )
              : ColoredBox(
                  color: const Color(0xff10b981).withValues(alpha: 0.15),
                  child: const Icon(
                    Icons.photo_camera_rounded,
                    color: Color(0xff34d399),
                    size: 18,
                  ),
                ),
        ),
      ),
    );
  }

  Widget _outPhotoThumbnail(TrackyuController c, Uint8List? outBytes) {
    return InkWell(
      onTap: () async {
        if (outBytes != null) {
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (_) => AttendanceSelfiePage(
                controller: c,
                mode: c.isField ? 'Field' : 'Office',
                attendanceId: c.attendance?['id'] as int? ?? 0,
                rawBytes: outBytes,
                title: 'Check-out selfie',
              ),
            ),
          );
        } else if (c.completed) {
          // Allow employee to take check-out selfie if not yet taken
          final photo = await c.takeSelfie();
          if (photo != null) {
            await c.saveOutSelfie(photo);
          }
        }
      },
      borderRadius: BorderRadius.circular(10),
      child: Container(
        width: 44,
        height: 44,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: const Color(0xff60a5fa).withValues(alpha: 0.6),
            width: 1.2,
          ),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(8.8),
          child: outBytes != null
              ? Image.memory(
                  outBytes,
                  fit: BoxFit.cover,
                  errorBuilder: (_, _, _) => const Icon(
                    Icons.broken_image_outlined,
                    color: Colors.white70,
                    size: 18,
                  ),
                )
              : ColoredBox(
                  color: const Color(0xff60a5fa).withValues(alpha: 0.15),
                  child: Icon(
                    c.completed
                        ? Icons.add_a_photo_rounded
                        : Icons.photo_camera_rounded,
                    color: const Color(0xff60a5fa),
                    size: 18,
                  ),
                ),
        ),
      ),
    );
  }
}
