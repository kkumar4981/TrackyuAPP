import 'package:flutter/material.dart';

String readableDate(DateTime value) =>
    '${value.day} ${const ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][value.month - 1]} ${value.year}';
bool arrivalAllowed(DateTime value, DateTime now) =>
    DateUtils.isSameDay(value, now) && value.isAfter(now);

class WorkflowPickerField extends StatelessWidget {
  final String label, value;
  final VoidCallback? onTap;
  final IconData icon;
  const WorkflowPickerField({
    super.key,
    required this.label,
    required this.value,
    required this.onTap,
    this.icon = Icons.calendar_month_outlined,
  });
  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final cardBg = isDark ? const Color(0xff1e1e1e) : Colors.white;
    final borderColor = isDark ? const Color(0xff2d3135) : const Color(0xffdce5ef);
    final textColor = isDark ? Colors.white : const Color(0xff102c4a);
    final labelColor = isDark ? const Color(0xff94a3b8) : const Color(0xff64748b);
    final iconColor = isDark ? const Color(0xff38bdf8) : const Color(0xff1c6799);

    return Semantics(
      button: true,
      label: '$label, $value',
      child: Material(
        color: cardBg,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: onTap,
          child: InputDecorator(
            decoration: InputDecoration(
              labelText: label,
              labelStyle: TextStyle(color: labelColor, fontSize: 13),
              floatingLabelBehavior: FloatingLabelBehavior.always,
              filled: true,
              fillColor: cardBg,
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 14,
                vertical: 14,
              ),
              suffixIcon: Icon(icon, color: iconColor, size: 21),
              enabled: onTap != null,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: BorderSide(color: borderColor),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: BorderSide(color: borderColor),
              ),
            ),
            child: Text(
              value,
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w600,
                color: textColor,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class WorkflowDateFields extends StatelessWidget {
  final DateTime from, to;
  final VoidCallback? onFrom, onTo;
  final bool single;
  const WorkflowDateFields({
    super.key,
    required this.from,
    required this.to,
    required this.onFrom,
    required this.onTo,
    this.single = false,
  });
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 16),
    child: LayoutBuilder(
      builder: (context, size) {
        final start = WorkflowPickerField(
          label: single ? 'Date' : 'From date',
          value: readableDate(single ? to : from),
          onTap: single ? onTo : onFrom,
        );
        if (single) return start;
        final end = WorkflowPickerField(
          label: 'To date',
          value: readableDate(to),
          onTap: onTo,
        );
        if (size.maxWidth < 300 ||
            MediaQuery.textScalerOf(context).scale(1) > 1.4) {
          return Column(children: [start, const SizedBox(height: 16), end]);
        }
        return Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(child: start),
            const SizedBox(width: 12),
            Expanded(child: end),
          ],
        );
      },
    ),
  );
}
