import 'package:flutter/material.dart';
import 'api.dart';
import 'controller.dart';
import 'workspace.dart' show jsonRows;

class OfficeLocationRequestPage extends StatefulWidget {
  final TrackyuController controller;
  const OfficeLocationRequestPage({super.key, required this.controller});
  @override
  State<OfficeLocationRequestPage> createState() =>
      _OfficeLocationRequestPageState();
}

class _OfficeLocationRequestPageState extends State<OfficeLocationRequestPage> {
  final form = GlobalKey<FormState>(),
      name = TextEditingController(),
      address = TextEditingController();
  Json? point;
  List<Json> requests = [];
  bool busy = false;
  String? error, success;
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<dynamic> request(String path, {Json? body}) async {
    try {
      return await widget.controller.api.request(path, body: body);
    } on ApiFailure catch (e) {
      if (e.status == 401) {
        await widget.controller.signOut();
        if (mounted) Navigator.popUntil(context, (r) => r.isFirst);
      }
      rethrow;
    }
  }

  Future<void> load() async {
    try {
      final rows = jsonRows(await request('OfficeLocationRequests/mine'));
      if (mounted) setState(() => requests = rows);
    } catch (e) {
      if (mounted) setState(() => error = e.toString());
    }
  }

  Future<void> capture() async {
    if (busy) return;
    setState(() {
      busy = true;
      error = null;
    });
    try {
      final value = await widget.controller.locate();
      if (mounted) setState(() => point = value);
    } catch (e) {
      if (mounted) setState(() => error = e.toString());
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> submit() async {
    if (busy || !form.currentState!.validate()) return;
    setState(() {
      busy = true;
      error = null;
      success = null;
    });
    try {
      // Refresh the GPS at submit rather than reusing an old preview reading.
      final location = await widget.controller.locate();
      await request(
        'OfficeLocationRequests/submit',
        body: {
          ...location,
          'name': name.text.trim(),
          'address': address.text.trim(),
        },
      );
      if (mounted) {
        setState(() {
          point = location;
          success =
              'Location sent. Your administrator will configure the office and approve your assignment.';
        });
      }
      await load();
    } catch (e) {
      if (mounted) setState(() => error = e.toString());
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  void dispose() {
    name.dispose();
    address.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Add office location')),
    body: Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 620),
        child: Form(
          key: form,
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: const Color(0xffe5f3f5),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(
                      Icons.add_location_alt_outlined,
                      size: 32,
                      color: Color(0xff1c6799),
                    ),
                    SizedBox(height: 12),
                    Text(
                      'Set up your workplace',
                      style: TextStyle(
                        fontSize: 23,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      'Stand at the office and send its location. Your administrator confirms the location, shift and attendance radius before assigning it to you.',
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: name,
                enabled: !busy,
                maxLength: 100,
                decoration: const InputDecoration(
                  labelText: 'Office name',
                  border: OutlineInputBorder(),
                ),
                validator: (v) => (v ?? '').trim().length < 2
                    ? 'Enter the office name.'
                    : null,
              ),
              const SizedBox(height: 14),
              TextFormField(
                controller: address,
                enabled: !busy,
                maxLength: 500,
                minLines: 2,
                maxLines: 4,
                decoration: const InputDecoration(
                  labelText: 'Office address / landmark',
                  border: OutlineInputBorder(),
                ),
                validator: (v) => (v ?? '').trim().length < 3
                    ? 'Enter the office address.'
                    : null,
              ),
              OutlinedButton.icon(
                onPressed: busy ? null : capture,
                icon: const Icon(Icons.my_location),
                label: const Text('Capture current office location'),
              ),
              if (point != null)
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Text(
                      'GPS captured · accuracy ${point!['accuracyMeters']} m\n${point!['latitude']}, ${point!['longitude']}',
                    ),
                  ),
                ),
              if (error != null)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  child: Text(
                    error!,
                    style: const TextStyle(color: Colors.red),
                  ),
                ),
              if (success != null)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  child: Text(
                    success!,
                    style: const TextStyle(color: Color(0xff24846e)),
                  ),
                ),
              FilledButton(
                onPressed: busy || requests.any((r) => r['status'] == 'Pending')
                    ? null
                    : submit,
                child: Text(
                  busy ? 'Please wait…' : 'Send location for approval',
                ),
              ),
              const SizedBox(height: 24),
              const Text(
                'Your location requests',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
              ),
              for (final row in requests)
                Card(
                  child: ListTile(
                    leading: const Icon(Icons.business_outlined),
                    title: Text('${row['name']}'),
                    subtitle: Text(
                      '${row['status']}${row['note'] == null ? '' : ' · ${row['note']}'}',
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    ),
  );
}
