import 'app.dart' show appVersion;
import 'tracking_status.dart';
import 'record_details.dart';
import 'workflow_dates.dart';
import 'package:flutter/material.dart';
import 'api.dart';
import 'controller.dart';
import 'exports.dart';
import 'locations.dart';
import 'selfie_view.dart';
import 'visits.dart';
import 'office_location_request.dart';
import 'error_logger.dart';
import 'local_db_inspector.dart';

enum WorkFeature {
  history('Attendance history', Icons.history),
  locations('My locations', Icons.map_outlined),
  leave('Leave', Icons.event_available_outlined),
  activity('Daily activity', Icons.edit_note),
  reminder('Reminders', Icons.alarm),
  intimation('Pre-intimation', Icons.message_outlined),
  inbox('Inbox', Icons.notifications_outlined),
  visits('Salesman visit', Icons.storefront_outlined),
  orders('Orders', Icons.shopping_bag_outlined),
  tasks('Assigned tasks', Icons.task_alt),
  offices('My offices', Icons.business_outlined);

  final String title;
  final IconData icon;
  const WorkFeature(this.title, this.icon);
  bool get writable => [leave, activity, reminder, intimation].contains(this);
  bool get officeScoped => [activity].contains(this);
  bool get teamSupported =>
      [history, leave, activity, intimation].contains(this);
}

String dateOnly(DateTime date) =>
    '${date.year.toString().padLeft(4, '0')}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';
String valueOf(Json row, String key, [String fallback = '—']) {
  final entry = row.entries
      .where(
        (e) =>
            e.key.toLowerCase().replaceAll('_', '') ==
            key.toLowerCase().replaceAll('_', ''),
      )
      .firstOrNull;
  return entry?.value?.toString().isNotEmpty == true
      ? entry!.value.toString()
      : fallback;
}

List<Json> jsonRows(dynamic data) {
  if (data is! List) return <Json>[];
  return data
      .whereType<Map>()
      .map((r) => Map<String, dynamic>.from(r))
      .toList();
}

String localStamp(dynamic raw) {
  if (raw == null) return '—';
  final date = DateTime.tryParse(raw.toString())?.toLocal();
  if (date == null) return raw.toString();
  return '${dateOnly(date)} ${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';
}

String localTimeOnly(dynamic raw) {
  if (raw == null) return '—';
  final str = raw.toString().trim();
  if (str.isEmpty || str == '—' || str == '-') return '—';
  final date = DateTime.tryParse(str)?.toLocal();
  if (date == null) return str;
  final hourNum = date.hour;
  final period = hourNum >= 12 ? 'PM' : 'AM';
  final hour = hourNum == 0 ? 12 : (hourNum > 12 ? hourNum - 12 : hourNum);
  final minute = date.minute.toString().padLeft(2, '0');
  return '$hour:$minute $period';
}

class WorkspaceDrawer extends StatelessWidget {
  final TrackyuController controller;
  final VoidCallback? openSetup;
  const WorkspaceDrawer({super.key, required this.controller, this.openSetup});
  @override
  Widget build(BuildContext context) => Drawer(
    child: SafeArea(
      child: ListView(
        children: [
          Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Your workspace',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 8),
                Text(
                  controller.name,
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 16,
                  ),
                ),
                if (controller.employeeId.isNotEmpty) ...[
                  const SizedBox(height: 4),
                  Text(
                    'User ID: ${controller.employeeId}',
                    style: const TextStyle(
                      color: Color(0xff74849b),
                      fontSize: 13,
                    ),
                  ),
                ],
              ],
            ),
          ),
          ListTile(
            leading: const Icon(Icons.fingerprint),
            title: const Text('Attendance'),
            selected: true,
            onTap: () => Navigator.pop(context),
          ),
          for (final feature in WorkFeature.values.where(
            (f) => controller.menuEnabled(f.name),
          ))
            ListTile(
              leading: Icon(feature.icon),
              title: Text(feature.title),
              onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute<void>(
                          builder: (_) => feature == WorkFeature.visits
                              ? VisitsPage(controller: controller)
                              : feature == WorkFeature.locations
                              ? DutyRoutePage(controller: controller)
                              : WorkspacePage(
                                  controller: controller,
                                  feature: feature,
                                ),
                        ),
                      );
                    },
            ),
          if (openSetup != null)
            ListTile(
              leading: const Icon(Icons.verified_user_outlined),
              title: const Text('Device setup checklist'),
              onTap: () {
                Navigator.pop(context);
                openSetup!();
              },
            ),
          SwitchListTile(
            secondary: Icon(
              controller.isDarkMode
                  ? Icons.nightlight_round
                  : Icons.wb_sunny_rounded,
            ),
            title: const Text('Dark theme'),
            value: controller.isDarkMode,
            onChanged: (_) => controller.toggleDarkMode(),
          ),
          ListTile(
            leading: const Icon(
              Icons.cloud_download_rounded,
              color: Color(0xff2563eb),
            ),
            title: const Text('Restore phone history'),
            onTap: () async {
              Navigator.pop(context);
              final ok = await controller.restoreDataFromServer();
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                      controller.notice.isNotEmpty
                          ? controller.notice
                          : ok
                          ? 'Phone history restored.'
                          : 'Restore did not complete.',
                    ),
                  ),
                );
              }
            },
          ),
          ListTile(
            leading: const Icon(
              Icons.storage_rounded,
              color: Color(0xff059669),
            ),
            title: const Text('Local DB & Sync Inspector'),
            subtitle: const Text(
              'View offline saved records, GPS points & sync outbox',
              style: TextStyle(fontSize: 11),
            ),
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) =>
                      LocalDatabaseInspectorPage(controller: controller),
                ),
              );
            },
          ),
          ListTile(
            leading: const Icon(
              Icons.bug_report_outlined,
              color: Color(0xffe11d48),
            ),
            title: const Text('App Error Logs'),
            subtitle: const Text(
              'View error details & SQLite crash logs',
              style: TextStyle(fontSize: 11),
            ),
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const ErrorLogsPage()),
              );
            },
          ),
          if ('${controller.syncStatus['error'] ?? ''}'.contains('Sign in'))
            ListTile(
              leading: const Icon(Icons.login),
              title: const Text('Sign in to resume sync'),
              onTap: () async {
                final password = TextEditingController();
                try {
                  final value = await showDialog<String>(
                    context: context,
                    builder: (ctx) => AlertDialog(
                      title: Text('Sign in as ${controller.employeeId}'),
                      content: TextField(
                        controller: password,
                        obscureText: true,
                        autofocus: true,
                        decoration: const InputDecoration(
                          labelText: 'Password',
                        ),
                      ),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(ctx),
                          child: const Text('Cancel'),
                        ),
                        FilledButton(
                          onPressed: () => Navigator.pop(ctx, password.text),
                          child: const Text('Sign in'),
                        ),
                      ],
                    ),
                  );
                  if (value != null && value.isNotEmpty) {
                    await controller.login(controller.employeeId, value);
                  }
                } catch (_) {
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text(
                          'Unable to sign in. Phone data is retained.',
                        ),
                      ),
                    );
                  }
                } finally {
                  password.dispose();
                }
              },
            ),
          const Divider(),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Text(
              'Trackyu $appVersion',
              style: const TextStyle(
                color: Color(0xff94a3b8),
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    ),
  );
}

class WorkspaceData extends ChangeNotifier {
  final TrackyuController session;
  final WorkFeature feature;
  WorkspaceData(this.session, this.feature);
  Json? profile;
  List<Json> rows = [];
  bool loading = false, saving = false, team = false, more = false;
  String? error;
  int? officeId;
  int page = 1, _revision = 0;
  bool _disposed = false;
  DateTime from = DateTime(DateTime.now().year, DateTime.now().month, 1);
  DateTime to = DateTime.now();
  List<Json> get offices =>
      profile == null ? [] : jsonRows(profile!['offices']);
  List<Json> get members => offices
      .where((o) => o['isMember'] == true && o['isEnabled'] == true)
      .toList();
  List<Json> get managers =>
      offices.where((o) => o['canManage'] == true).toList();
  List<Json> get choices => team ? managers : members;
  bool get needsOffice => team || feature.officeScoped;
  bool get canCreate =>
      !team &&
      feature.writable &&
      ([WorkFeature.intimation, WorkFeature.leave].contains(feature) ||
          members.isNotEmpty);

  Future<dynamic> request(String route, {Json? body}) async {
    if (!session.loggedIn) {
      throw const ApiFailure(
        'UNAUTHORIZED',
        'Please sign in again.',
        status: 401,
      );
    }
    try {
      return await session.workspaceRequest(route, body: body);
    } on ApiFailure catch (e) {
      if (e.status == 401) await session.signOut();
      rethrow;
    }
  }

  Future<void> load({bool append = false}) async {
    final revision = ++_revision;
    loading = true;
    error = null;
    if (!append) {
      rows = [];
      page = 1;
      more = false;
    }
    notifyListeners();
    try {
      if (profile == null) {
        final result = Map<String, dynamic>.from(
          await request('Portal/profile') as Map,
        );
        if (_disposed || revision != _revision) return;
        profile = result;
      }
      if (!choices.any((o) => o['id'] == officeId)) {
        officeId = choices.firstOrNull?['id'] as int?;
      }
      if (needsOffice && officeId == null) return;
      final query = <String, dynamic>{
        'fromDate': dateOnly(from),
        'toDate': dateOnly(to),
        'page': page,
        'pageSize': 50,
        if (officeId != null) 'officeId': officeId,
      };
      dynamic data;
      switch (feature) {
        case WorkFeature.history:
          data = await request(
            team ? 'Portal/team-attendance' : 'Portal/attendance',
            body: query,
          );
          data = (data as Map)['rows'];
        case WorkFeature.locations:
          data = await request(
            'Portal/locations',
            body: {'date': dateOnly(to)},
          );
        case WorkFeature.leave:
          data = await request(
            team ? 'OfficeLeave/team' : 'OfficeLeave/mine',
            body: team ? query : null,
          );
          if (!team) {
            final legacy = jsonRows(
              await request('Portal/legacy-leave', body: query),
            );
            data = [
              ...jsonRows(data).where(
                (r) =>
                    valueOf(
                          r,
                          'fromDate',
                        ).split('T').first.compareTo(dateOnly(to)) <=
                        0 &&
                    valueOf(
                          r,
                          'toDate',
                        ).split('T').first.compareTo(dateOnly(from)) >=
                        0,
              ),
              ...legacy.map((r) => {...r, 'legacy': true}),
            ];
          }
        case WorkFeature.activity:
          data = await request(
            'OfficeActivities/${team ? 'team' : 'mine'}',
            body: query,
          );
        case WorkFeature.intimation:
          data = await request(
            'OfficePreIntimation/${team ? 'team' : 'personal'}',
            body: query,
          );
        case WorkFeature.reminder:
          data = await request('OfficeReminders/mine');
        case WorkFeature.inbox:
          data = await request('WorkforceInbox/mine');
        case WorkFeature.visits:
          final selectedDateStr = dateOnly(to);
          List<Json> modernList = [];
          try {
            final modernRes =
                await request('MobileVisits/mine?date=$selectedDateStr');
            modernList = jsonRows(modernRes);
          } catch (_) {}

          List<Json> legacyList = [];
          try {
            final visits = await request(
              'Portal/visits',
              body: {'date': selectedDateStr},
            ) as Map;
            legacyList = [
              ...jsonRows(visits['modern'] ?? []),
              ...jsonRows(
                visits['regular'],
              ).map((r) => {...r, 'visitKind': 'Regular'}),
              ...jsonRows(
                visits['open'],
              ).map((r) => {...r, 'visitKind': 'Open'}),
            ];
          } catch (_) {}

          final Map<String, Json> byKey = {};
          for (final row in [...modernList, ...legacyList]) {
            final k = row['id']?.toString() ??
                row['requestId']?.toString() ??
                '${row['shopName']}_${row['checkInUtc']}';
            byKey.putIfAbsent(k, () => row);
          }
          data = byKey.values.toList();
        case WorkFeature.orders:
          data = await request('Portal/orders', body: {'date': dateOnly(to)});
        case WorkFeature.tasks:
          data = await request('Portal/tasks', body: query);
        case WorkFeature.offices:
          data = offices;
      }
      if (_disposed || revision != _revision) return;
      final received = jsonRows(data);
      rows = append ? [...rows, ...received] : received;
      if (!team && !append) {
        if (feature == WorkFeature.visits) {
          final selectedDateStr = dateOnly(to);
          final List<Json> localVisits = [];
          if (session.local != null) {
            try {
              final day = await session.localDayData(selectedDateStr);
              localVisits.addAll(jsonRows(day['visits'] ?? []));
            } catch (_) {}
          }
          try {
            final cached = await session.scopedVisitCache();
            localVisits.addAll(cached);
          } catch (_) {}

          final matchingLocal = localVisits.where((v) {
            final wDate = v['workDate']?.toString();
            final inUtc = v['checkInUtc']?.toString();
            if (wDate != null && wDate.isNotEmpty) {
              return wDate == selectedDateStr;
            }
            if (inUtc != null && inUtc.isNotEmpty) {
              try {
                return DateTime.parse(inUtc)
                    .toLocal()
                    .toString()
                    .startsWith(selectedDateStr);
              } catch (_) {}
            }
            return selectedDateStr == session.localDay;
          }).toList();

          final Set<String> seenIds = {};
          final List<Json> merged = [];
          for (final v in matchingLocal) {
            final idStr =
                (v['id'] ?? v['localId'] ?? v['requestId'] ?? '').toString();
            if (idStr.isNotEmpty && seenIds.add(idStr)) {
              merged.add(v);
            }
          }
          for (final r in rows) {
            final idStr =
                (r['id'] ?? r['localId'] ?? r['requestId'] ?? '').toString();
            if (idStr.isNotEmpty && seenIds.add(idStr)) {
              merged.add(r);
            }
          }
          rows = merged;
        } else if (session.local != null) {
          final local = await session.localDayData();
          final route = switch (feature) {
            WorkFeature.leave => 'OfficeLeave/apply',
            WorkFeature.activity => 'OfficeActivities/save',
            WorkFeature.reminder => 'OfficeReminders/save',
            WorkFeature.intimation => 'OfficePreIntimation/submit',
            _ => '',
          };
          final activities = jsonRows(local['activities'] ?? [])
              .where((a) => a['route'] == route)
              .map(
                (a) => <String, dynamic>{
                  ...Map<String, dynamic>.from(a['body'] as Map),
                  if (a['result'] is Map)
                    ...Map<String, dynamic>.from(a['result'] as Map),
                  'id': (a['result'] as Map?)?['id'] ?? a['operationId'],
                  'syncState': a['syncState'],
                  'userId': session.employeeId,
                },
              )
              .toList();
          rows = [
            ...activities.reversed,
            ...rows.where((r) => !activities.any((a) => a['id'] == r['id'])),
          ];
        }
      }
      more =
          received.length == 50 &&
          (feature == WorkFeature.history || feature.officeScoped || team);
    } catch (e) {
      if (!_disposed && revision == _revision) {
        error = e is ApiFailure
            ? e.toString()
            : 'Unable to load these records. Please retry.';
      }
    } finally {
      if (!_disposed && revision == _revision) {
        loading = false;
        notifyListeners();
      }
    }
  }

  Future<void> mutate(String route, Json body) async {
    if (saving) return;
    saving = true;
    notifyListeners();
    try {
      await request(route, body: body);
    } finally {
      if (!_disposed) {
        saving = false;
        notifyListeners();
      }
    }
    if (!_disposed) await load();
  }

  @override
  void dispose() {
    _disposed = true;
    _revision++;
    super.dispose();
  }
}

class WorkspacePage extends StatefulWidget {
  final TrackyuController controller;
  final WorkFeature feature;
  const WorkspacePage({
    super.key,
    required this.controller,
    required this.feature,
  });
  @override
  State<WorkspacePage> createState() => _WorkspacePageState();
}

class _WorkspacePageState extends State<WorkspacePage> {
  late final WorkspaceData data;
  bool exporting = false;
  Future<void> export() async {
    if (exporting) return;
    setState(() => exporting = true);
    try {
      final path = await saveAttendanceExport(List<Json>.from(data.rows));
      if (path != null && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Loaded records exported.')),
        );
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'Unable to save the file. Choose a writable folder and try again.',
            ),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => exporting = false);
    }
  }

  @override
  void initState() {
    super.initState();
    data = WorkspaceData(widget.controller, widget.feature);
    if (widget.feature.officeScoped || widget.feature == WorkFeature.leave) {
      data.to = DateTime.now().add(const Duration(days: 30));
    }
    data.addListener(changed);
    data.load();
  }

  void changed() {
    if (!mounted) return;
    if (!widget.controller.loggedIn) {
      Navigator.of(context).popUntil((r) => r.isFirst);
      return;
    }
    setState(() {});
  }

  @override
  void dispose() {
    data.removeListener(changed);
    data.dispose();
    super.dispose();
  }

  Future<void> edit([Json? row]) async {
    await Navigator.push<void>(
      context,
      MaterialPageRoute(
        builder: (_) => WorkspaceForm(data: data, row: row),
      ),
    );
    if (mounted && widget.controller.loggedIn) await data.load();
  }

  Future<void> action(String route, Json body) async {
    try {
      await data.mutate(route, body);
    } catch (e) {
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Unable to update'),
          content: Text(e is ApiFailure ? e.toString() : 'Please retry.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('OK'),
            ),
          ],
        ),
      );
    }
  }

  Future<void> review(Json row, String decision) async {
    final note = TextEditingController();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('$decision leave?'),
        content: TextField(
          controller: note,
          maxLength: 1000,
          decoration: const InputDecoration(labelText: 'Review note'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Back'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text(decision),
          ),
        ],
      ),
    );
    final message = note.text;
    note.dispose();
    if (confirmed == true) {
      await action('OfficeLeave/review', {
        'leaveId': row['id'],
        'decision': decision,
        'note': message,
      });
    }
  }

  Future<void> chooseDate(bool start) async {
    final chosen = await showDatePicker(
      context: context,
      initialDate: start ? data.from : data.to,
      firstDate: DateTime(2020),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (chosen == null || !mounted) return;
    if (start) {
      data.from = chosen;
      if (data.to.isBefore(chosen)) data.to = chosen;
    } else {
      data.to = chosen;
      if (data.from.isAfter(chosen)) data.from = chosen;
    }
    await data.load();
  }

  @override
  Widget build(BuildContext context) {
    final feature = widget.feature;
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        title: Text(
          feature == WorkFeature.visits ? 'Visit history' : feature.title,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
        ),
        actions: [
          IconButton(
            tooltip: widget.controller.isDarkMode ? 'Light mode' : 'Dark mode',
            icon: Icon(
              widget.controller.isDarkMode
                  ? Icons.light_mode_rounded
                  : Icons.dark_mode_rounded,
            ),
            onPressed: () => widget.controller.toggleDarkMode(),
          ),
          IconButton(
            tooltip: 'Refresh',
            onPressed: data.loading || data.saving ? null : () => data.load(),
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      floatingActionButton: feature == WorkFeature.offices
          ? FloatingActionButton.extended(
              onPressed: () => Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) =>
                      OfficeLocationRequestPage(controller: widget.controller),
                ),
              ),
              icon: const Icon(Icons.add_location_alt_outlined),
              label: const Text('Add office location'),
            )
          : feature == WorkFeature.visits
          ? FloatingActionButton.extended(
              onPressed: () => Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => VisitsPage(controller: widget.controller),
                ),
              ),
              icon: const Icon(Icons.add_location_alt_outlined),
              label: const Text("Start / manage visits"),
            )
          : data.canCreate
          ? FloatingActionButton.extended(
              onPressed: data.loading || data.saving ? null : () => edit(),
              icon: const Icon(Icons.add),
              label: Text(
                feature == WorkFeature.leave
                    ? 'Apply leave'
                    : feature == WorkFeature.intimation
                    ? 'Notify late arrival'
                    : 'Add',
              ),
            )
          : null,
      body: RefreshIndicator(
        onRefresh: () => data.load(),
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
          children: [
            if (feature.teamSupported && data.managers.isNotEmpty)
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Team view'),
                subtitle: const Text('Only offices you manage'),
                value: data.team,
                onChanged: data.loading
                    ? null
                    : (value) {
                        data.team = value;
                        data.officeId = null;
                        data.load();
                      },
              ),
            if (feature == WorkFeature.intimation && !data.team)
              Card(
                child: ListTile(
                  leading: const Icon(
                    Icons.schedule_send_outlined,
                    color: Color(0xff1c6799),
                  ),
                  title: const Text('Let your team know in advance'),
                  subtitle: const Text(
                    'Send your expected arrival time and a reason.',
                  ),
                  onTap: data.loading ? null : () => edit(),
                ),
              ),
            if (data.needsOffice && data.choices.isNotEmpty)
              DropdownButtonFormField<int>(
                key: ValueKey('${data.team}-${data.officeId}'),
                initialValue: data.officeId,
                isExpanded: true,
                decoration: const InputDecoration(labelText: 'Office'),
                items: data.choices
                    .map(
                      (o) => DropdownMenuItem(
                        value: o['id'] as int,
                        child: Text(
                          o['name'].toString(),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    )
                    .toList(),
                onChanged: data.loading
                    ? null
                    : (value) {
                        data.officeId = value;
                        data.load();
                      },
              ),
            if ([
                  WorkFeature.history,
                  WorkFeature.locations,
                  WorkFeature.leave,
                  WorkFeature.activity,
                  WorkFeature.intimation,
                  WorkFeature.tasks,
                  WorkFeature.visits,
                  WorkFeature.orders,
                ].contains(feature) ||
                data.team)
              WorkflowDateFields(
                from: data.from,
                to: data.to,
                single: [
                  WorkFeature.visits,
                  WorkFeature.orders,
                  WorkFeature.locations,
                ].contains(feature),
                onFrom: data.loading ? null : () => chooseDate(true),
                onTo: data.loading ? null : () => chooseDate(false),
              ),
            if (feature == WorkFeature.reminder)
              const Padding(
                padding: EdgeInsets.all(12),
                child: Text(
                  'Reminders follow the office time zone and arrive in your workspace inbox. They are not phone alarms.',
                ),
              ),
            if (feature.writable &&
                !data.loading &&
                data.profile != null &&
                data.members.isEmpty &&
                ![WorkFeature.leave, WorkFeature.intimation].contains(feature))
              const Card(
                child: Padding(
                  padding: EdgeInsets.all(20),
                  child: Text(
                    'Contact your administrator to enable this feature.',
                  ),
                ),
              ),
            if (data.error != null)
              Card(
                color: const Color(0xffffece8),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(data.error!),
                      TextButton(
                        onPressed: () => data.load(),
                        child: const Text('Try again'),
                      ),
                    ],
                  ),
                ),
              ),
            if (data.loading)
              const Padding(
                padding: EdgeInsets.all(20),
                child: Center(child: CircularProgressIndicator()),
              ),
            if (!data.loading && data.error == null && data.rows.isEmpty)
              const Padding(
                padding: EdgeInsets.all(32),
                child: Column(
                  children: [
                    Icon(
                      Icons.inbox_outlined,
                      size: 44,
                      color: Colors.blueGrey,
                    ),
                    SizedBox(height: 12),
                    Text(
                      'No records for this view yet.',
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            if (feature == WorkFeature.history &&
                data.rows.isNotEmpty &&
                data.error == null)
              Padding(
                padding: const EdgeInsets.only(bottom: 16),
                child: SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 13, horizontal: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                      side: BorderSide(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? const Color(0xff334155)
                            : const Color(0xffcbd5e1),
                      ),
                      foregroundColor: Theme.of(context).brightness == Brightness.dark
                          ? const Color(0xff38bdf8)
                          : const Color(0xff0284c7),
                    ),
                    onPressed: exporting || data.loading ? null : export,
                    icon: const Icon(Icons.download_rounded, size: 18),
                    label: Text(
                      exporting ? 'Saving records…' : 'Export loaded records (CSV)',
                      style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
                    ),
                  ),
                ),
              ),
            if (feature == WorkFeature.locations && data.error == null)
              PunchLocationMap(rows: data.rows),
            if (data.error == null)
              for (final row in data.rows) recordCard(row),
            if (data.more && !data.loading)
              TextButton(
                onPressed: () {
                  data.page++;
                  data.load(append: true);
                },
                child: const Text('Load more'),
              ),
          ],
        ),
      ),
    );
  }

  Widget recordCard(Json row) {
    final feature = widget.feature;
    String title = '', badge = '';
    Map<String, String> details = {};
    switch (feature) {
      case WorkFeature.history:
        final dateStr = recordDate(row['workDate']);
        title = 'Attendance · $dateStr';

        final hasPunchIn = row['punchInUtc'] != null && row['punchInUtc'].toString().trim().isNotEmpty;
        final hasPunchOut = row['punchOutUtc'] != null && row['punchOutUtc'].toString().trim().isNotEmpty;
        final mode = valueOf(row, 'attendanceMode', '').trim();
        final modeLabel = (mode.isNotEmpty && mode != '—' && mode != '-') ? mode : '';

        if (hasPunchIn && !hasPunchOut) {
          badge = modeLabel.isNotEmpty ? '$modeLabel · Punched in' : 'Punched in';
        } else if (hasPunchIn && hasPunchOut) {
          badge = modeLabel.isNotEmpty ? '$modeLabel · Completed' : 'Completed';
        } else if (modeLabel.isNotEmpty) {
          badge = modeLabel;
        } else {
          badge = '';
        }

        final isLate = row['isLate'] == true;
        final isEarly = row['isEarly'] == true;
        final isAutoOut = row['isAutoPunchOut'] == true;

        details = {
          'Punch in': localTimeOnly(row['punchInUtc']),
          'Punch out': hasPunchOut ? localTimeOnly(row['punchOutUtc']) : 'Pending',
          if (hasPunchOut)
            'Punch out by': isAutoOut ? 'System (Auto)' : 'User (Self)',
          'Timing status': (isLate && isEarly)
              ? 'Late arrival & Early exit'
              : isLate
                  ? 'Late arrival'
                  : isEarly
                      ? 'Early exit'
                      : 'On time',
          if (data.team) 'Employee': valueOf(row, 'userId'),
        };
      case WorkFeature.leave:
        final portion = leavePortionLabel(valueOf(row, 'portion'));
        title = '$portion leave';
        badge = valueOf(row, 'status');
        details = {
          'From': recordDate(row['fromDate']),
          'To': recordDate(row['toDate']),
          'Reason': valueOf(row, 'reasonName', valueOf(row, 'reason')),
          if (valueOf(row, 'reasonName', '').isNotEmpty)
            'Remarks': valueOf(row, 'reason'),
          if (row['submittedAtUtc'] != null)
            'Submitted': localStamp(row['submittedAtUtc']),
          if (row['reviewNote'] != null)
            'Review note': valueOf(row, 'reviewNote'),
          if (data.team) 'Employee': valueOf(row, 'userId'),
        };
      case WorkFeature.activity:
        title = valueOf(row, 'title');
        badge = valueOf(row, 'status');
        details = {
          'Date': recordDate(row['activityDate']),
          'Time spent': '${valueOf(row, 'minutesSpent')} min',
          'Planned work': valueOf(row, 'plannedWork', ''),
          'Completed work': valueOf(row, 'completedWork', ''),
          'Notes': valueOf(row, 'notes', ''),
          if (data.team) 'Employee': valueOf(row, 'userId'),
        };
      case WorkFeature.reminder:
        title = valueOf(row, 'title');
        badge = row['isEnabled'] == true ? 'Enabled' : 'Disabled';
        final days = valueOf(row, 'daysOfWeekCsv', '')
            .split(',')
            .map((v) => int.tryParse(v))
            .whereType<int>()
            .where((v) => v >= 1 && v <= 7)
            .map(
              (v) => ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][v - 1],
            )
            .join(', ');
        details = {'Time': valueOf(row, 'localTime'), 'Days': days};
      case WorkFeature.intimation:
        title = 'Late arrival notice';
        badge = 'Sent';
        details = {
          'Expected arrival': localStamp(row['expectedArrivalUtc']),
          'Reason': valueOf(row, 'reason'),
          if (row['submittedAtUtc'] != null)
            'Submitted': localStamp(row['submittedAtUtc']),
          if (data.team) 'Employee': valueOf(row, 'userId'),
        };
      case WorkFeature.locations:
        title = valueOf(row, 'label');
        details = {
          'Captured': localStamp(row['capturedAtUtc']),
          'Latitude': valueOf(row, 'latitude'),
          'Longitude': valueOf(row, 'longitude'),
          'Accuracy': '${valueOf(row, 'accuracyMeters')} m',
        };
      case WorkFeature.inbox:
        title = valueOf(row, 'title');
        badge = row['isRead'] == true ? 'Read' : 'Unread';
        details = {
          'Message': valueOf(row, 'message'),
          'Received': localStamp(row['createdAtUtc']),
        };
      case WorkFeature.visits:
        final kind = row['kind']?.toString() ??
            row['visitKind']?.toString() ??
            'Open';
        final regular = kind.toLowerCase() == 'regular';
        final rawTitle = row['shopName'] ??
            row['clientName'] ??
            row['Customer'] ??
            row['partyName'] ??
            valueOf(row, regular ? 'rtlname' : 'shopname', '');
        title = rawTitle.toString().trim().isNotEmpty
            ? rawTitle.toString().trim()
            : (regular ? 'Retailer visit' : 'Open visit');

        final inProgress = (row['checkOutUtc'] == null ||
                row['checkOutUtc'] == '') &&
            (row['checkout'] == null ||
                row['checkout'] == '' ||
                row['checkout'] == '00:00') &&
            (row['outtime'] == null || row['outtime'] == '');
        final isOffline =
            row['isOffline'] == true || row['syncState'] == 'pending';

        badge = isOffline
            ? (inProgress ? 'Pending • In progress' : 'Pending sync')
            : (inProgress
                ? 'In progress'
                : (regular ? 'Retailer visit' : 'Open visit'));

        final rawAddr = row['address'] ??
            row['Location'] ??
            row['addbymap'] ??
            row['ADD_BY_MAP'] ??
            valueOf(row, regular ? 'address' : 'addbymap', '');
        final displayAddr = rawAddr.toString().trim().isNotEmpty
            ? cleanAddress(rawAddr.toString())
            : 'Recorded via GPS';

        // Punch in
        final rawIn = row['checkInUtc'] ??
            row['CheckIn'] ??
            row['checkin'] ??
            row['intime'] ??
            row['IN_TIME'];
        final punchInTime = localTimeOnly(rawIn);

        // Punch out
        final rawOut = row['checkOutUtc'] ??
            row['CheckOut'] ??
            row['checkout'] ??
            row['outtime'] ??
            row['OUT_TIME'];
        final punchOutTime = inProgress
            ? 'Active / In progress'
            : (rawOut != null &&
                    rawOut.toString().isNotEmpty &&
                    rawOut != '00:00'
                ? localTimeOnly(rawOut)
                : '—');

        details = {
          'Address': displayAddr,
          'Punch in': punchInTime,
          'Punch out': punchOutTime,
          if (row['remark'] != null &&
              row['remark'].toString().trim().isNotEmpty)
            'Remark': row['remark'].toString().trim(),
        };
      case WorkFeature.orders:
        title = 'Order ${valueOf(row, 'ordno')}';
        badge = valueOf(row, 'approved', '');
        details = {
          'Customer': valueOf(row, 'partyname'),
          'Date': recordDate(row['orddate']),
          'Amount': 'INR ${valueOf(row, 'ordamt')}',
        };
      case WorkFeature.tasks:
        title = valueOf(row, 'taskname');
        badge = valueOf(row, 'status');
        details = {
          'Details': valueOf(row, 'taskdetails'),
          'Deadline': recordDate(row['deadlinedate']),
        };
      case WorkFeature.offices:
        title = valueOf(row, 'name');
        badge = row['isEnabled'] == true ? 'Enabled' : 'Disabled';
        details = {
          'Shift starts': valueOf(row, 'shiftStart'),
          'Shift ends': valueOf(row, 'shiftEnd'),
          'Time zone': valueOf(row, 'timeZoneId'),
          'Office radius': '${valueOf(row, 'radiusMeters')} m',
          'Late grace': '${valueOf(row, 'lateGraceMinutes')} min',
        };
    }
    final own = valueOf(row, 'userId', '') == widget.controller.employeeId;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final cardBg = isDark ? const Color(0xff1e1e1e) : Colors.white;
    final cardBorder = isDark
        ? const Color(0xff2d3135)
        : const Color(0xffe5ecf4);
    final cardTitleColor = isDark ? Colors.white : const Color(0xff102c4a);
    final cardIconBg = isDark
        ? const Color(0xff0f172a)
        : const Color(0xffe5f1f7);
    final cardIconColor = isDark
        ? const Color(0xff38bdf8)
        : const Color(0xff1c6799);

    return Card(
      color: cardBg,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: BorderSide(color: cardBorder),
      ),
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: cardIconBg,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(feature.icon, size: 21, color: cardIconColor),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.w700,
                          color: cardTitleColor,
                        ),
                      ),
                      if (badge.isNotEmpty && badge != '—' && badge != '-')
                        Padding(
                          padding: const EdgeInsets.only(top: 8),
                          child: RecordStatusBadge(status: badge),
                        ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            RecordDetails(fields: details),
            if (feature == WorkFeature.history && row['hasSelfie'] == true)
              Padding(
                padding: const EdgeInsets.only(top: 14),
                child: SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      side: BorderSide(
                        color: isDark ? const Color(0xff334155) : const Color(0xffcbd5e1),
                      ),
                      foregroundColor: isDark ? const Color(0xff38bdf8) : const Color(0xff0284c7),
                    ),
                    icon: const Icon(Icons.photo_camera_rounded, size: 18),
                    label: const Text(
                      'View punch-in selfie',
                      style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
                    ),
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute<void>(
                        builder: (_) => AttendanceSelfiePage(
                          controller: widget.controller,
                          mode: row['attendanceMode']?.toString() ?? '',
                          attendanceId: (row['id'] as num?)?.toInt() ?? int.tryParse('${row['id']}') ?? 0,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            if (feature == WorkFeature.visits) ...[
              Builder(
                builder: (context) {
                  final vid = visitIdOf(row);
                  final hasArr = row['hasArrivalSelfie'] == true ||
                      row['photoBase64'] != null ||
                      row['photo'] != null ||
                      row['Photo'] != null;
                  final hasDep = row['hasDepartureSelfie'] == true ||
                      row['departureSelfieBase64'] != null ||
                      row['outPhoto'] != null ||
                      row['OutPhoto'] != null;
                  if (!hasArr && !hasDep) return const SizedBox.shrink();
                  return Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: Row(
                      children: [
                        if (hasArr)
                          Expanded(
                            child: OutlinedButton.icon(
                              style: OutlinedButton.styleFrom(
                                padding: const EdgeInsets.symmetric(
                                  vertical: 10,
                                  horizontal: 8,
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                side: BorderSide(
                                  color: isDark
                                      ? const Color(0xff334155)
                                      : const Color(0xffcbd5e1),
                                ),
                                foregroundColor: isDark
                                    ? const Color(0xff38bdf8)
                                    : const Color(0xff0284c7),
                              ),
                              icon: const Icon(
                                Icons.photo_camera_rounded,
                                size: 16,
                              ),
                              label: const Text(
                                'Arrival selfie',
                                style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  fontSize: 12,
                                ),
                              ),
                              onPressed: () => Navigator.push(
                                context,
                                MaterialPageRoute<void>(
                                  builder: (_) => AttendanceSelfiePage.visit(
                                    controller: widget.controller,
                                    visitId: vid,
                                    phase: 'in',
                                    visitRecord: row,
                                    title: 'Arrival selfie',
                                  ),
                                ),
                              ),
                            ),
                          ),
                        if (hasArr && hasDep) const SizedBox(width: 8),
                        if (hasDep)
                          Expanded(
                            child: OutlinedButton.icon(
                              style: OutlinedButton.styleFrom(
                                padding: const EdgeInsets.symmetric(
                                  vertical: 10,
                                  horizontal: 8,
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                side: BorderSide(
                                  color: isDark
                                      ? const Color(0xff334155)
                                      : const Color(0xffcbd5e1),
                                ),
                                foregroundColor: isDark
                                    ? const Color(0xfff59e0b)
                                    : const Color(0xffd97706),
                              ),
                              icon: const Icon(
                                Icons.photo_camera_back_rounded,
                                size: 16,
                              ),
                              label: const Text(
                                'Departure selfie',
                                style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  fontSize: 12,
                                ),
                              ),
                              onPressed: () => Navigator.push(
                                context,
                                MaterialPageRoute<void>(
                                  builder: (_) => AttendanceSelfiePage.visit(
                                    controller: widget.controller,
                                    visitId: vid,
                                    phase: 'out',
                                    visitRecord: row,
                                    title: 'Departure selfie',
                                  ),
                                ),
                              ),
                            ),
                          ),
                      ],
                    ),
                  );
                },
              ),
            ],
            if ([
                  WorkFeature.activity,
                  WorkFeature.reminder,
                ].contains(feature) &&
                own &&
                !data.team)
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                  onPressed: data.saving || row['syncState'] == 'pending'
                      ? null
                      : () => edit(row),
                  child: const Text('Edit'),
                ),
              ),
            if (feature == WorkFeature.inbox && row['isRead'] != true)
              TextButton(
                onPressed: data.saving
                    ? null
                    : () => action('WorkforceInbox/read', {
                        'notificationId': row['id'],
                      }),
                child: const Text('Mark read'),
              ),
            if (feature == WorkFeature.leave &&
                row['legacy'] != true &&
                ['Pending', 'Approved'].contains(row['status']))
              Wrap(
                spacing: 8,
                children: [
                  if (own)
                    TextButton(
                      onPressed: data.saving
                          ? null
                          : () async {
                              final yes = await showDialog<bool>(
                                context: context,
                                builder: (context) => AlertDialog(
                                  title: const Text(
                                    'Cancel this leave request?',
                                  ),
                                  actions: [
                                    TextButton(
                                      onPressed: () =>
                                          Navigator.pop(context, false),
                                      child: const Text('Keep request'),
                                    ),
                                    FilledButton(
                                      onPressed: () =>
                                          Navigator.pop(context, true),
                                      child: const Text('Cancel leave'),
                                    ),
                                  ],
                                ),
                              );
                              if (yes == true) {
                                await action('OfficeLeave/cancel', {
                                  'leaveId': row['id'],
                                });
                              }
                            },
                      child: const Text('Cancel request'),
                    ),
                  if (data.team && !own && row['status'] == 'Pending') ...[
                    TextButton(
                      onPressed: data.saving
                          ? null
                          : () => review(row, 'Approved'),
                      child: const Text('Approve'),
                    ),
                    TextButton(
                      onPressed: data.saving
                          ? null
                          : () => review(row, 'Rejected'),
                      child: const Text('Reject'),
                    ),
                  ],
                ],
              ),
          ],
        ),
      ),
    );
  }
}

class WorkspaceForm extends StatefulWidget {
  final WorkspaceData data;
  final Json? row;
  const WorkspaceForm({super.key, required this.data, this.row});
  @override
  State<WorkspaceForm> createState() => _WorkspaceFormState();
}

class _WorkspaceFormState extends State<WorkspaceForm> {
  final form = GlobalKey<FormState>();
  final fields = <String, TextEditingController>{};
  late int? officeId;
  String portion = 'FullDay', status = 'Planned';
  List<Json> leaveReasons = [];
  int? reasonId;
  bool reasonsLoading = false;
  Future<void> loadReasons() async {
    setState(() {
      reasonsLoading = true;
      error = null;
    });
    try {
      final result = jsonRows(await widget.data.request("OfficeLeave/reasons"));
      if (mounted) setState(() => leaveReasons = result);
    } catch (e) {
      if (mounted) {
        setState(
          () => error = e is ApiFailure
              ? e.toString()
              : "Unable to load leave reasons.",
        );
      }
    } finally {
      if (mounted) setState(() => reasonsLoading = false);
    }
  }

  static DateTime defaultArrival([DateTime? current]) {
    final now = current ?? DateTime.now();
    final candidate = now.add(const Duration(hours: 1));
    if (DateUtils.isSameDay(candidate, now) && candidate.isAfter(now)) {
      return candidate;
    }
    final endOfDay = DateTime(now.year, now.month, now.day, 23, 59, 59);
    if (endOfDay.isAfter(now)) {
      return endOfDay;
    }
    return now.add(const Duration(minutes: 5));
  }

  DateTime from = DateTime.now(),
      to = DateTime.now(),
      arrival = defaultArrival();
  TimeOfDay reminderTime = const TimeOfDay(hour: 8, minute: 45);
  Set<int> weekdays = {1, 2, 3, 4, 5};
  bool enabled = true, saving = false;
  String? error;
  WorkFeature get feature => widget.data.feature;
  @override
  void initState() {
    super.initState();
    if (feature == WorkFeature.leave) loadReasons();
    if (feature == WorkFeature.intimation &&
        (!DateUtils.isSameDay(arrival, DateTime.now()) ||
            !arrival.isAfter(DateTime.now()))) {
      arrival = defaultArrival();
    }
    final row = widget.row;
    officeId =
        (row?['officeId'] ??
                widget.data.officeId ??
                widget.data.members.firstOrNull?['id'])
            as int?;
    if (!widget.data.members.any((o) => o['id'] == officeId)) {
      officeId = widget.data.members.firstOrNull?['id'] as int?;
    }
    for (final key in [
      'title',
      'reason',
      'plannedWork',
      'completedWork',
      'notes',
      'minutesSpent',
    ]) {
      fields[key] = TextEditingController(
        text: row?[key]?.toString() ?? (key == 'minutesSpent' ? '0' : ''),
      );
    }
    if (row != null) {
      status = row['status']?.toString() ?? 'Planned';
      from = DateTime.tryParse(row['activityDate']?.toString() ?? '') ?? from;
      final time = row['localTime']?.toString().split(':');
      if (time != null && time.length >= 2) {
        reminderTime = TimeOfDay(
          hour: int.parse(time[0]),
          minute: int.parse(time[1]),
        );
      }
      weekdays = (row['daysOfWeekCsv']?.toString() ?? '1,2,3,4,5')
          .split(',')
          .map(int.parse)
          .toSet();
      enabled = row['isEnabled'] != false;
    }
  }

  @override
  void dispose() {
    for (final controller in fields.values) {
      controller.dispose();
    }
    super.dispose();
  }

  Widget input(
    String key,
    String label, {
    bool required = true,
    int max = 200,
    bool number = false,
  }) => Padding(
    padding: const EdgeInsets.only(bottom: 16),
    child: TextFormField(
      controller: fields[key],
      enabled: !saving,
      decoration: InputDecoration(
        labelText: label,
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
      ),
      maxLength: max,
      keyboardType: number ? TextInputType.number : TextInputType.text,
      maxLines: max > 200 ? 3 : 1,
      validator: (v) {
        if (required && (v?.trim().isEmpty ?? true)) return 'Enter $label';
        if (key == 'reason' && (v?.trim().length ?? 0) < 3) {
          return 'Enter at least 3 characters';
        }
        if (number &&
            (int.tryParse(v ?? '') == null ||
                int.parse(v!) < 0 ||
                int.parse(v) > 1440)) {
          return 'Enter 0–1440 minutes';
        }
        return null;
      },
    ),
  );
  Future<void> pickDate(String target) async {
    final today = DateUtils.dateOnly(DateTime.now());
    final initial = target == 'to'
        ? to
        : target == 'arrival'
        ? arrival
        : from;
    final restricted = feature == WorkFeature.leave || target == 'arrival';
    final chosen = await showDatePicker(
      context: context,
      initialDate: target == 'arrival'
          ? today
          : restricted && initial.isBefore(today)
          ? today
          : initial,
      firstDate: restricted ? today : today.subtract(const Duration(days: 365)),
      lastDate: target == 'arrival'
          ? today
          : today.add(const Duration(days: 365)),
      helpText: target == 'arrival'
          ? 'Expected arrival date'
          : target == 'to'
          ? 'Leave end date'
          : 'Select date',
    );
    if (chosen == null || !mounted) return;
    var value = chosen;
    if (target == 'arrival') {
      final picked = await showTimePicker(
        context: context,
        initialTime: TimeOfDay.fromDateTime(arrival),
      );
      if (picked == null || !mounted) return;
      value = DateTime(
        chosen.year,
        chosen.month,
        chosen.day,
        picked.hour,
        picked.minute,
      );
      if (!arrivalAllowed(value, DateTime.now())) {
        setState(() => error = 'Choose a future arrival time for today.');
        return;
      }
    }
    setState(() {
      error = null;
      if (target == 'to') {
        to = value;
        if (feature == WorkFeature.leave && from.isAfter(to)) from = to;
      } else if (target == 'arrival') {
        arrival = value;
      } else {
        from = value;
        if (feature == WorkFeature.leave &&
            (portion != 'FullDay' || to.isBefore(from))) {
          to = from;
        }
      }
      if (feature == WorkFeature.leave && portion != 'FullDay') to = from;
    });
  }

  Future<void> save() async {
    if (saving || !form.currentState!.validate()) return;
    if (feature == WorkFeature.leave &&
        dateOnly(to).compareTo(dateOnly(from)) < 0) {
      setState(() => error = 'End date must be on or after start date.');
      return;
    }
    if (feature == WorkFeature.leave && reasonId == null) {
      setState(() => error = 'Choose a leave reason.');
      return;
    }
    if (feature == WorkFeature.reminder && weekdays.isEmpty) {
      setState(() => error = 'Choose at least one reminder day.');
      return;
    }
    if (feature == WorkFeature.intimation &&
        !arrivalAllowed(arrival, DateTime.now())) {
      setState(() => error = 'Choose a future arrival time for today.');
      return;
    }
    setState(() {
      saving = true;
      error = null;
    });
    final body = <String, dynamic>{if (officeId != null) 'officeId': officeId};
    String route;
    switch (feature) {
      case WorkFeature.leave:
        route = 'OfficeLeave/apply';
        body.addAll({
          'fromDate': dateOnly(from),
          'toDate': dateOnly(to),
          'portion': portion,
          'reasonId': reasonId,
          'reason': fields['reason']!.text.trim(),
        });
      case WorkFeature.activity:
        route = 'OfficeActivities/save';
        body.addAll({
          'activityId': widget.row?['id'],
          'version': widget.row?['version'],
          'activityDate': dateOnly(from),
          'title': fields['title']!.text.trim(),
          'status': status,
          'plannedWork': fields['plannedWork']!.text,
          'completedWork': fields['completedWork']!.text,
          'notes': fields['notes']!.text,
          'minutesSpent': int.parse(fields['minutesSpent']!.text),
        });
      case WorkFeature.reminder:
        route = 'OfficeReminders/save';
        body.addAll({
          'reminderId': widget.row?['id'],
          'version': widget.row?['version'],
          'title': fields['title']!.text.trim(),
          'localTime':
              '${reminderTime.hour.toString().padLeft(2, '0')}:${reminderTime.minute.toString().padLeft(2, '0')}',
          'daysOfWeekCsv': (weekdays.toList()..sort()).join(','),
          'isEnabled': enabled,
        });
      case WorkFeature.intimation:
        route = 'OfficePreIntimation/submit';
        body.addAll({
          'expectedArrivalUtc': arrival.toUtc().toIso8601String(),
          'reason': fields['reason']!.text.trim(),
        });
      default:
        return;
    }
    try {
      await widget.data.request(route, body: body);
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (!mounted) return;
      if (!widget.data.session.loggedIn) {
        Navigator.popUntil(context, (r) => r.isFirst);
        return;
      }
      setState(
        () => error = e is ApiFailure
            ? e.toString()
            : 'Unable to save. Refresh records before retrying.',
      );
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  @override
  Widget build(BuildContext context) => PopScope(
    canPop: !saving,
    child: Scaffold(
      appBar: AppBar(
        title: Text(
          '${widget.row == null ? 'Add' : 'Edit'} ${feature.title.toLowerCase()}',
        ),
      ),
      body: Form(
        key: form,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            if (widget.data.members.isNotEmpty)
              DropdownButtonFormField<int>(
                initialValue: officeId,
                isExpanded: true,
                decoration: const InputDecoration(labelText: 'Office / team'),
                items: widget.data.members
                    .map(
                      (o) => DropdownMenuItem(
                        value: o['id'] as int,
                        child: Text(
                          o['name'].toString(),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    )
                    .toList(),
                onChanged: saving || widget.row != null
                    ? null
                    : (id) {
                        if (id != null) setState(() => officeId = id);
                      },
              ),
            const SizedBox(height: 20),
            if (feature == WorkFeature.leave) ...[
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: const Color(0xffe5f1f7),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(
                      Icons.event_available_rounded,
                      color: Color(0xff1c6799),
                      size: 30,
                    ),
                    SizedBox(height: 10),
                    Text(
                      'Plan your time off',
                      style: TextStyle(
                        fontSize: 23,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      'Choose your dates, leave duration and reason. Track approval here after submitting.',
                    ),
                  ],
                ),
              ),
              WorkflowDateFields(
                from: from,
                to: to,
                onFrom: saving ? null : () => pickDate('from'),
                onTo: saving || portion != 'FullDay'
                    ? null
                    : () => pickDate('to'),
              ),
              DropdownButtonFormField<String>(
                initialValue: portion,
                decoration: const InputDecoration(labelText: 'Leave duration'),
                items: const [
                  DropdownMenuItem(value: 'FullDay', child: Text('Full day')),
                  DropdownMenuItem(
                    value: 'FirstHalf',
                    child: Text('First half'),
                  ),
                  DropdownMenuItem(
                    value: 'SecondHalf',
                    child: Text('Second half'),
                  ),
                ],
                onChanged: saving
                    ? null
                    : (v) => setState(() {
                        portion = v!;
                        if (portion != 'FullDay') to = from;
                      }),
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<int>(
                initialValue: reasonId,
                isExpanded: true,
                decoration: const InputDecoration(labelText: 'Leave reason'),
                items: leaveReasons
                    .map(
                      (r) => DropdownMenuItem(
                        value: int.parse('${r['id']}'),
                        child: Text(
                          '${r['name']}',
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    )
                    .toList(),
                onChanged: saving || reasonsLoading
                    ? null
                    : (value) => setState(() => reasonId = value),
                validator: (v) => v == null ? 'Choose a leave reason' : null,
              ),
              if (reasonsLoading) const LinearProgressIndicator(),
              if (!reasonsLoading && leaveReasons.isEmpty)
                TextButton(
                  onPressed: loadReasons,
                  child: const Text('Reload leave reasons'),
                ),
              const SizedBox(height: 16),
              input('reason', 'Remarks / details', max: 1000),
            ],
            if (feature == WorkFeature.activity) ...[
              OutlinedButton(
                onPressed: saving ? null : () => pickDate('from'),
                child: Text('Activity date ${dateOnly(from)}'),
              ),
              const SizedBox(height: 16),
              input('title', 'Title'),
              DropdownButtonFormField<String>(
                initialValue: status,
                decoration: const InputDecoration(labelText: 'Status'),
                items: ['Planned', 'InProgress', 'Completed', 'Cancelled']
                    .map((s) => DropdownMenuItem(value: s, child: Text(s)))
                    .toList(),
                onChanged: saving ? null : (v) => setState(() => status = v!),
              ),
              const SizedBox(height: 16),
              input('minutesSpent', 'Minutes spent', max: 4, number: true),
              input('plannedWork', 'Planned work', required: false, max: 2000),
              input(
                'completedWork',
                'Completed work',
                required: false,
                max: 2000,
              ),
              input('notes', 'Notes', required: false, max: 2000),
            ],
            if (feature == WorkFeature.reminder) ...[
              input('title', 'Reminder title'),
              Text(
                'Schedule uses ${widget.data.members.firstWhere((o) => o['id'] == officeId)['timeZoneId']}. Delivery is to the workspace inbox.',
              ),
              OutlinedButton(
                onPressed: saving
                    ? null
                    : () async {
                        final picked = await showTimePicker(
                          context: context,
                          initialTime: reminderTime,
                        );
                        if (picked != null && mounted) {
                          setState(() => reminderTime = picked);
                        }
                      },
                child: Text('Reminder time ${reminderTime.format(context)}'),
              ),
              Wrap(
                spacing: 8,
                children: [
                  for (var i = 1; i <= 7; i++)
                    FilterChip(
                      label: Text(
                        ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][i -
                            1],
                      ),
                      selected: weekdays.contains(i),
                      onSelected: saving
                          ? null
                          : (selected) => setState(() {
                              if (selected) {
                                weekdays.add(i);
                              } else {
                                weekdays.remove(i);
                              }
                            }),
                    ),
                ],
              ),
              SwitchListTile(
                title: const Text('Reminder enabled'),
                value: enabled,
                onChanged: saving ? null : (v) => setState(() => enabled = v),
              ),
            ],
            if (feature == WorkFeature.intimation) ...[
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: const Color(0xffe5f3f5),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(
                      Icons.schedule_send_outlined,
                      color: Color(0xff1c6799),
                      size: 32,
                    ),
                    SizedBox(height: 12),
                    Text(
                      'Running late?',
                      style: TextStyle(
                        fontSize: 23,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      'Let your team know when you expect to arrive and what caused the delay.',
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              WorkflowPickerField(
                label: 'Expected arrival',
                value:
                    '${readableDate(arrival)}  ${TimeOfDay.fromDateTime(arrival).format(context)}',
                onTap: saving ? null : () => pickDate('arrival'),
              ),
              const SizedBox(height: 16),
              Wrap(
                spacing: 8,
                children: [
                  for (final reason in [
                    'Traffic delay',
                    'Travel disruption',
                    'Personal emergency',
                  ])
                    ActionChip(
                      label: Text(reason),
                      onPressed: saving
                          ? null
                          : () =>
                                setState(() => fields['reason']!.text = reason),
                    ),
                ],
              ),
              const SizedBox(height: 12),
              input('reason', 'Reason', max: 1000),
              const Text(
                'Your message will be visible to your manager or administrator.',
              ),
            ],
            if (error != null)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 16),
                child: Text(error!, style: const TextStyle(color: Colors.red)),
              ),
            FilledButton(
              onPressed: saving ? null : save,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Text(
                  saving
                      ? 'Saving...'
                      : feature == WorkFeature.intimation
                      ? 'Send pre-intimation'
                      : feature == WorkFeature.leave
                      ? 'Apply leave'
                      : 'Save',
                ),
              ),
            ),
          ],
        ),
      ),
    ),
  );
}
