import 'timeline_reconciliation.dart';
import 'error_logger.dart';
import 'dart:convert';
import 'dart:async';
import 'package:uuid/uuid.dart';
import 'local_workspace.dart';
import 'package:flutter/foundation.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart' hide ServiceStatus;
import 'api.dart';
import 'punch_telemetry.dart';
import 'selfie.dart';
import 'accurate_location.dart';
import 'duty_tracking.dart';

Future<Json> freshLocation() async {
  if (!await Geolocator.isLocationServiceEnabled()) {
    throw const ApiFailure(
      'GPS_DISABLED',
      'Turn on location services to mark attendance.',
    );
  }
  var permission = await Geolocator.checkPermission();
  if (permission == LocationPermission.denied) {
    permission = await Geolocator.requestPermission();
  }
  if (permission == LocationPermission.deniedForever) {
    throw const ApiFailure(
      'LOCATION_PERMISSION',
      'Allow precise location in app settings, then try again.',
    );
  }
  if (permission == LocationPermission.denied) {
    throw const ApiFailure(
      'LOCATION_PERMISSION',
      'Location permission is required for attendance.',
    );
  }
  if (!kIsWeb && defaultTargetPlatform == TargetPlatform.android) {
    if (permission != LocationPermission.always) {
      final bg = await Permission.locationAlways.status;
      if (!bg.isGranted) {
        final res = await Permission.locationAlways.request();
        if (!res.isGranted) {
          throw const ApiFailure(
            'BACKGROUND_LOCATION_REQUIRED',
            'Duty tracking requires "Allow all the time" location permission. Please select "Allow all the time" in App Settings.',
          );
        }
      }
    }
  }
  final position = await accurateLocation(
    current: () => Geolocator.getCurrentPosition(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high,
        timeLimit: Duration(seconds: 25),
      ),
    ),
    updates: () => Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 0,
      ),
    ),
  );
  return {
    'latitude': position.latitude,
    'longitude': position.longitude,
    'accuracyMeters': position.accuracy,
    'capturedAtUtc': position.timestamp.toUtc().toIso8601String(),
    'telemetry': await PunchTelemetryCollector().collect(
      position.latitude,
      position.longitude,
    ),
  };
}

class TrackyuController extends ChangeNotifier {
  LocalWorkspace? local;
  bool _disposed = false, _savingPunch = false;
  int _workspaceRevision = 0;
  Timer? _localTimer;
  bool _localReading = false;
  bool restoreOffered = false, restoring = false;
  DateTime? _menusChecked;
  bool _menusBusy = false;
  Json syncStatus = {};
  Json? activeVisit;
  bool isSyncing = false;
  int get pendingCount =>
      (syncStatus['pending'] as num? ?? 0).toInt() +
      pendingPunches.length +
      pendingVisits.length;
  int legacyPendingReview = 0;
  String get localDay => LocalWorkspace.day(
    DateTime.now().toUtc().add(const Duration(minutes: 330)),
  );
  String get dayKey => 'day:$localDay';
  Future<Json> localDayData([String? day]) async =>
      await local?.read('day:${day ?? localDay}') ?? {};
  Future<Json> routeDayData(String day) async =>
      await local?.readSummary('day:$day') ?? {};
  String get visitCacheScope => '${api.baseUrl}|$employeeId';
  Future<List<Json>> scopedVisitCache() async {
    final scope = visitCacheScope;
    try {
      final raw = await vault.readCachedVisits();
      final value = raw == null ? null : jsonDecode(raw);
      if (visitCacheScope == scope && value is Map && value['scope'] == scope) {
        return rowsOf(value['rows']);
      }
    } catch (e, stack) {
      await ErrorLogger.record(e, stack, context: 'timeline.visitCache');
    }
    return [];
  }

  Future<void> _openLocal(String token) async {
    if (!LocalWorkspace.available) return;
    _workspaceRevision++;
    local ??= LocalWorkspace();
    try {
      await local!.configure(api, employeeId, token);
    legacyPendingReview = 0;
    // Old global queues did not record their employee/workspace owner. Preserve
    // them for reconciliation instead of replaying another account's activity.
    for (final raw in [
      await vault.readPendingPunches(),
      await vault.readPendingVisits(),
    ]) {
      if (raw != null) {
        try {
          final rows = jsonDecode(raw);
          if (rows is List) legacyPendingReview += rows.length;
        } catch (_) {}
      }
    }
    final profile = await local!.read('profile');
    restoreOffered = false;
    if (profile != null) {
      isField = profile['isField'] == true;
      offices = (profile['offices'] as List? ?? [])
          .map((e) => Map<String, dynamic>.from(e))
          .toList();
      officeId = (profile['officeId'] as num?)?.toInt();
      enabledMenus = (profile['enabledMenus'] as List?)
          ?.map((e) => e.toString())
          .toSet();
      stateKnown = true;
    }
    await readLocal();
    _localTimer?.cancel();
    _localTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      unawaited(_pollLocal());
    });
    } catch (e, stack) {
      await ErrorLogger.record(e, stack, context: 'openLocal');
    }
  }

  Future<void> _pollLocal() async {
    if (!loggedIn || local == null || _localReading) return;
    _localReading = true;
    try {
      await readLocal();
      await local!.sync();
      if (!_menusBusy &&
          (_menusChecked == null ||
              DateTime.now().difference(_menusChecked!) >
                  const Duration(minutes: 5))) {
        _menusBusy = true;
        _menusChecked = DateTime.now();
        unawaited(() async {
          try {
            await refreshMenus();
            await _seedLocal();
          } catch (_) {
          } finally {
            _menusBusy = false;
          }
        }());
      }
    } catch (_) {
      notice = 'Phone data is saved. Sync will retry.';
    } finally {
      _localReading = false;
    }
  }

  Future<void> readLocal() async {
    final workspace = local, revision = _workspaceRevision;
    if (workspace == null || _disposed) return;
    final values = await Future.wait([
      workspace.read(dayKey),
      workspace.syncState(),
    ]);
    if (_disposed ||
        revision != _workspaceRevision ||
        !identical(workspace, local)) {
      return;
    }
    final day = values.first ?? <String, dynamic>{};
    if (day['attendance'] is Map) {
      attendance = Map<String, dynamic>.from(day['attendance']);
    } else if (day.containsKey('attendance') ||
        (stateKnown && workDate != localDay)) {
      attendance = null;
    }
    if (day.containsKey('visits')) {
      final visits = rowsOf(day['visits']);
      activeVisit = onDuty
          ? visits
              .where((r) =>
                  r['checkOutUtc'] == null &&
                  (r['workDate'] == null ||
                      r['workDate'] == '' ||
                      r['workDate'] == localDay))
              .firstOrNull
          : null;
    } else if (!onDuty) {
      activeVisit = null;
    }
    workDate = localDay;
    syncStatus = values[1] ?? {};
    final blockedCount = (syncStatus['blocked'] as num? ?? 0);
    final syncErr = (syncStatus['error'] ?? '').toString().trim();
    if (blockedCount > 0) {
      notice = 'Sync needs review: ${syncStatus['error'] ?? 'activity retained on phone'}';
    } else if (syncErr.isNotEmpty) {
      if (syncErr.contains('Sign in') && api.authorized) {
        local?.sync();
        notice = '';
      } else {
        notice = syncErr;
      }
    } else {
      if (api.authorized && blockedCount == 0) {
        offline = false;
      }
      if (notice.contains('failed') ||
          notice.contains('Sync needs review') ||
          notice.contains('Sign in') ||
          notice.contains('database operation')) {
        notice = '';
      }
    }
    notifyListeners();
  }

  Future<void> _seedLocal() async {
    if (local == null) return;
    await local!.write('profile', {
      'isField': isField,
      'offices': offices,
      'officeId': officeId,
      'enabledMenus': enabledMenus?.toList(),
    });
    final current = await localDayData();
    if (!current.containsKey('attendance')) {
      await local!.write(dayKey, {
        ...current,
        'attendance': workDate == localDay ? attendance : null,
      });
    }
  }

  Future<void> commitLocal(Json day, Json operation) async {
    if (restoring) {
      throw const ApiFailure(
        'RESTORE_RUNNING',
        'Wait for restore to finish before saving an activity.',
      );
    }
    final key = operation['recordKey']?.toString() ?? dayKey;
    await local!.commit(key, day, {...operation, 'recordKey': key});
    if (day.containsKey('visits')) {
      final visits = rowsOf(day['visits']);
      activeVisit = onDuty
          ? visits
              .where((r) =>
                  r['checkOutUtc'] == null &&
                  (r['workDate'] == null ||
                      r['workDate'] == '' ||
                      r['workDate'] == localDay))
              .firstOrNull
          : null;
    } else if (!onDuty) {
      activeVisit = null;
    }
    notice = 'Saved on this phone. Sync runs automatically.';
    unawaited(local!.sync().catchError((Object _) {}));
    notifyListeners();
  }

  Future<dynamic> workspaceRequest(String route, {Json? body}) async {
    if (local == null) return api.request(route, body: body);
    const personalReads = {
      'OfficeLeave/mine',
      'OfficeActivities/mine',
      'OfficeReminders/mine',
      'OfficePreIntimation/personal',
    };
    if (personalReads.contains(route)) {
      final collection = await local!.read(
        'collection:$route:${body?['officeId'] ?? ''}',
      );
      if (collection != null) {
        var rows = (collection['rows'] as List? ?? [])
            .map((r) => Map<String, dynamic>.from(r))
            .where((r) {
              final date = '${r['activityDate'] ?? r['workDate'] ?? ''}'
                  .split('T')
                  .first;
              return date.isEmpty ||
                  body == null ||
                  (date.compareTo('${body['fromDate']}') >= 0 &&
                      date.compareTo('${body['toDate']}') <= 0);
            })
            .toList();
        if (body != null) {
          rows = rows
              .skip(
                (((body['page'] as num?)?.toInt() ?? 1) - 1) *
                    ((body['pageSize'] as num?)?.toInt() ?? 50),
              )
              .take((body['pageSize'] as num?)?.toInt() ?? 50)
              .toList();
        }
        return rows;
      }
    }
    if (route == 'Portal/attendance' || route == 'Portal/team-attendance') {
      final from = DateTime.tryParse('${body?['fromDate']}') ?? DateTime.now();
      final to = DateTime.tryParse('${body?['toDate']}') ?? from;
      final records = <Json>[];
      for (
        var date = from;
        !date.isAfter(to);
        date = date.add(const Duration(days: 1))
      ) {
        final day = await localDayData(LocalWorkspace.day(date));
        if (day['attendance'] is Map) {
          records.add({
            ...Map<String, dynamic>.from(day['attendance']),
            'mode':
                (day['attendance'] as Map)['mode'] ??
                (isField ? 'Field' : 'Office'),
            'workDate': LocalWorkspace.day(date),
          });
        }
      }
      if (records.isNotEmpty) {
        return {'rows': records.reversed.toList()};
      }
      if (!offline) {
        try {
          final serverRes = await api.request(route, body: body);
          if (serverRes is Map && serverRes['rows'] is List) {
            final serverRows = (serverRes['rows'] as List)
                .whereType<Map>()
                .map((r) => Map<String, dynamic>.from(r))
                .toList();
            // Also merge today's local attendance if present and not in serverRows
            final todayStr = LocalWorkspace.day(DateTime.now());
            final todayDay = await localDayData(todayStr);
            if (todayDay['attendance'] is Map) {
              final hasToday = serverRows.any(
                (r) => '${r['workDate']}'.startsWith(todayStr),
              );
              if (!hasToday) {
                serverRows.insert(0, {
                  ...Map<String, dynamic>.from(todayDay['attendance'] as Map),
                  'mode':
                      (todayDay['attendance'] as Map)['mode'] ??
                      (isField ? 'Field' : 'Office'),
                  'workDate': todayStr,
                });
              }
            }
            return {'rows': serverRows};
          }
        } catch (_) {}
      }
      return {'rows': records.reversed.toList()};
    }
    const writes = {
      'OfficeLeave/apply',
      'OfficeActivities/save',
      'OfficeReminders/save',
      'OfficePreIntimation/submit',
    };
    if (body != null && writes.contains(route)) {
      final id = const Uuid().v4();
      final day = await localDayData();
      final activities = List<dynamic>.from(day['activities'] as List? ?? []);
      activities.add({
        'operationId': id,
        'route': route,
        'body': body,
        'atUtc': DateTime.now().toUtc().toIso8601String(),
        'syncState': 'pending',
      });
      await commitLocal(
        {...day, 'activities': activities},
        {'id': id, 'route': route, 'body': body},
      );
      return {'id': id, 'savedOnPhone': true};
    }
    final key = 'response:$route:${jsonEncode(body)}';
    final cached = await local!.read(key);
    if (cached != null) return cached['value'];
    if (offline) {
      if (route == 'Portal/profile') return {'offices': offices};
      if (route.contains('attendance') || route == 'Portal/visits') {
        return {'rows': [], 'regular': [], 'open': []};
      }
      return <Json>[];
    }
    final value = await api.request(route, body: body);
    await local!.write(key, {'value': value});
    return value;
  }

  @override
  void dispose() {
    _disposed = true;
    _workspaceRevision++;
    _localTimer?.cancel();
    super.dispose();
  }

  @override
  void notifyListeners() {
    if (!_disposed) super.notifyListeners();
  }

  final TrackyuApi api;
  final SessionVault vault;
  final Future<Json> Function() locate;
  final Future<String?> Function() takeSelfie;
  DateTime? _serverAnchor;
  DateTime? _serverAnchorRecordedAt;
  final Stopwatch _sinceSync = Stopwatch();

  DateTime get currentUtc {
    if (_serverAnchor != null && _serverAnchorRecordedAt != null) {
      final wallElapsed = DateTime.now().toUtc().difference(
        _serverAnchorRecordedAt!,
      );
      if (!wallElapsed.isNegative) {
        return _serverAnchor!.add(wallElapsed);
      }
    }
    return DateTime.now().toUtc();
  }

  void syncServerTime(dynamic value) {
    final parsed = DateTime.tryParse(value?.toString() ?? '')?.toUtc();
    if (parsed == null) return;
    serverTime = value.toString();
    _serverAnchor = parsed;
    _serverAnchorRecordedAt = DateTime.now().toUtc();
    _sinceSync
      ..reset()
      ..start();
  }

  Duration? get workingDuration {
    if (!stateKnown) return null;
    if (attendance == null) return Duration.zero;
    final start = DateTime.tryParse(
      attendance!['punchInUtc']?.toString() ?? '',
    )?.toUtc();
    final out = DateTime.tryParse(
      attendance!['punchOutUtc']?.toString() ?? '',
    )?.toUtc();
    final end = out ?? currentUtc;
    if (start == null) return null;
    final elapsed = end.difference(start);
    return elapsed.isNegative ? Duration.zero : elapsed;
  }

  TrackyuController(
    this.api, {
    SessionVault? vault,
    Future<Json> Function()? locate,
    Future<String?> Function()? takeSelfie,
  }) : vault = vault ?? SecureSessionVault(),
       locate = locate ?? freshLocation,
       takeSelfie = takeSelfie ?? capturePunchSelfie;
  Json? user, attendance, lastLocation, punchOutLocation;
  List<Json> offices = [];
  int? officeId;
  String workDate = '', serverTime = '', notice = '';
  String? outSelfieBase64;
  Future<void> saveOutSelfie(String base64) async {
    outSelfieBase64 = base64;
    await _cache();
    notifyListeners();
  }

  bool stateKnown = false;
  bool offline = false;
  bool isDarkMode = false;
  final ValueNotifier<bool> darkModeNotifier = ValueNotifier<bool>(false);
  Future<void> toggleDarkMode() async {
    isDarkMode = !isDarkMode;
    darkModeNotifier.value = isDarkMode;
    await vault.writeTheme(isDarkMode ? 'dark' : 'light');
    notifyListeners();
  }

  void setOffline(bool value) {
    if (offline != value) {
      offline = value;
      notifyListeners();
    }
  }

  Set<String>? enabledMenus;
  bool menuEnabled(String key) => enabledMenus?.contains(key) ?? false;
  bool get canVisit => onDuty && !dutyCutoffReached;
  List<Map<String, dynamic>> pendingPunches = [];
  List<Map<String, dynamic>> pendingVisits = [];

  Future<void> queuePendingVisit({
    required bool finish,
    required Json body,
  }) async {
    pendingVisits.add({
      'scope': '${api.baseUrl}|$employeeId',
      'finish': finish,
      'body': body,
      'time': DateTime.now().toUtc().toIso8601String(),
    });
    await _preservePendingVisits();
    notifyListeners();
  }

  Future<void> _preservePendingVisits() async {
    try {
      await vault.writePendingVisits(
        pendingVisits.isEmpty ? null : jsonEncode(pendingVisits),
      );
    } catch (_) {}
  }

  Future<void> _restorePreservedPendingVisits() async {
    try {
      final raw = await vault.readPendingVisits();
      if (raw != null && raw.isNotEmpty) {
        final decoded = jsonDecode(raw);
        if (decoded is List) {
          for (final item in decoded) {
            if (item is Map) {
              final map = Map<String, dynamic>.from(item);
              if (!pendingVisits.any((p) => p['time'] == map['time'])) {
                pendingVisits.add(map);
              }
            }
          }
        }
      }
    } catch (_) {}
  }

  Future<void> syncPendingVisits() async {
    if (pendingVisits.isEmpty) return;
    final queue = List<Map<String, dynamic>>.from(pendingVisits);
    for (final item in queue) {
      if (item['scope'] != '${api.baseUrl}|$employeeId') continue;
      try {
        final finish = item['finish'] == true;
        final body = Map<String, dynamic>.from(item['body'] as Map);
        await api.request(
          'MobileVisits/${finish ? 'finish' : 'start'}',
          body: body,
        );
        pendingVisits.remove(item);
      } catch (e) {
        if (e is ApiFailure) {
          if (e.status == null ||
              e.status! >= 500 ||
              e.code == 'CONNECTION_FAILED' ||
              e.code == 'CONNECTION_TIMEOUT') {
            break;
          }
          notice = 'Visit sync needs review. The phone copy is retained.';
          break;
        }
      }
    }
    if (pendingVisits.isEmpty) {
      await vault.writePendingVisits(null);
    } else {
      await _preservePendingVisits();
    }
  }

  Future<void> _preservePendingPunches() async {
    try {
      await vault.writePendingPunches(
        pendingPunches.isEmpty ? null : jsonEncode(pendingPunches),
      );
    } catch (_) {}
  }

  Future<void> _restorePreservedPendingPunches() async {
    try {
      final raw = await vault.readPendingPunches();
      if (raw != null && raw.isNotEmpty) {
        final decoded = jsonDecode(raw);
        if (decoded is List) {
          for (final item in decoded) {
            if (item is Map) {
              final map = Map<String, dynamic>.from(item);
              if (!pendingPunches.any((p) => p['time'] == map['time'])) {
                pendingPunches.add(map);
              }
            }
          }
        }
      }
    } catch (_) {}
  }

  Future<void> refreshMenus() async {
    final rows = await api.request('MobileMenus');
    if (rows is List) {
      enabledMenus = rows
          .where((r) => r is Map && r['enabled'] == true)
          .map((r) => r['key'].toString())
          .toSet();
      if (local != null) {
        final profile = (await local!.read('profile')) ?? <String, dynamic>{};
        await local!.write('profile', {
          ...profile,
          'enabledMenus': enabledMenus?.toList(),
        });
      }
      notifyListeners();
    }
  }

  void requireVisitDuty() {
    if (!canVisit) {
      throw const ApiFailure(
        'PUNCH_IN_REQUIRED',
        'Punch in before starting or completing a visit.',
      );
    }
  }

  Future<void> _tracking() async {
    try {
      if (local != null && attendance != null) {
        final start =
            (DateTime.tryParse('${attendance!['punchInUtc']}') ??
                    DateTime.now().toUtc())
                .toUtc();
        final cutoff = start.add(const Duration(hours: 24));
        await local!.offlineTracking({
          'baseUrl': api.baseUrl,
          'userId': employeeId,
          'mode': isField ? 'Field' : 'Office',
          'attendanceId': int.tryParse('${attendance!['id']}') ?? 1,
          'requestId':
              attendance!['requestId'] ??
              'server:${isField ? 'Field' : 'Office'}:${attendance!['id']}',
          'serverId':
              attendance!['serverId'] ??
              (attendance!['requestId'] == null ? attendance!['id'] : null),
          'active': onDuty && !dutyCutoffReached,
          'serverTimeUtc': currentUtc.toIso8601String(),
          'dutyCutoffUtc': cutoff.toIso8601String(),
        });
        return;
      }
      await DutyTracker.reconcile(
        api,
        isField ? 'Field' : 'Office',
        attendance,
        userId: employeeId,
      );
    } catch (_) {
      notice += ' Location tracking needs attention. Open tracking status.';
    }
  }

  Future<void> _cache() async {
    try {
      final raw = await vault.read();
      if (raw == null) return;
      final saved = decodeSession(raw);
      saved['attendanceCache'] = {
        'enabledMenus': enabledMenus?.toList(),
        'attendance': attendance,
        'offices': offices,
        'officeId': officeId,
        'isField': isField,
        'workDate': workDate,
        'serverTime': serverTime,
        'outSelfie': outSelfieBase64,
        'lastLocation': lastLocation,
        'punchOutLocation': punchOutLocation,
        'pendingPunches': pendingPunches,
      };
      await vault.write(jsonEncode(saved));
    } catch (_) {
      notice += ' Unable to cache attendance on this phone.';
    }
  }

  bool isField = false;
  bool get loggedIn => user != null;
  bool get onDuty => attendance != null && attendance!['punchOutUtc'] == null;
  bool get dutyCutoffReached {
    final start = DateTime.tryParse('${attendance?['punchInUtc']}')?.toUtc();
    if (!onDuty || start == null) return false;
    final india = start.add(const Duration(minutes: 330));
    final end = DateTime.utc(
      india.year,
      india.month,
      india.day,
      23,
    ).subtract(const Duration(minutes: 330));
    final now = currentUtc;
    if (start.isBefore(end)) {
      return !now.isBefore(end);
    }
    return now.difference(start) >= const Duration(hours: 14);
  }

  bool get dayChanged {
    if (!onDuty) return false;
    final punchIn = DateTime.tryParse('${attendance?['punchInUtc']}')?.toUtc();
    if (punchIn == null) return false;
    return currentUtc.difference(punchIn) >= const Duration(hours: 24);
  }

  Future<void> checkDayChangeAndCutoff() async {
    if (!onDuty) return;
    if (dutyCutoffReached || dayChanged) {
      await DutyTracker.stop();
      if (local != null) {
        // The server applies the same cutoff. Never invent a fresh GPS fix.
        final start =
            (DateTime.tryParse('${attendance!['punchInUtc']}') ??
                    DateTime.now().toUtc())
                .toUtc();
        final india = start.add(const Duration(minutes: 330));
        var end = DateTime.utc(
          india.year,
          india.month,
          india.day,
          23,
        ).subtract(const Duration(minutes: 330));
        if (!start.isBefore(end)) end = start.add(const Duration(hours: 12));
        final day = LocalWorkspace.day(india);
        final record = await localDayData(day);
        attendance = {
          ...attendance!,
          'punchOutUtc': end.toIso8601String(),
          'autoPunchOut': true,
        };
        await local!.write('day:$day', {...record, 'attendance': attendance});
        notifyListeners();
        return;
      }
      final nowUtc = DateTime.now().toUtc().toIso8601String();
      final loc = lastLocation ?? await locate();
      final attId = (attendance?['id'] is int && (attendance!['id'] as int) > 0)
          ? attendance!['id'] as int
          : (int.tryParse('${attendance?['id']}') ??
                DateTime.now().millisecondsSinceEpoch);
      final payload = <String, dynamic>{
        if (!isField) 'officeId': officeId,
        ...loc,
        'attendanceId': attId,
        'earlyReason': 'Auto punch-out on day cutoff',
      };
      attendance = {
        ...?attendance,
        'punchOutUtc': nowUtc,
        'punchOutLat': loc['latitude'],
        'punchOutLng': loc['longitude'],
        'punchOutAddress': loc['address'],
        'autoPunchOut': true,
      };
      punchOutLocation ??= loc;
      pendingPunches.add({
        'out': true,
        'payload': payload,
        'time': nowUtc,
        'autoPunchOut': true,
      });
      offline = true;
      notice = 'Shift automatically punched out due to day cutoff.';
      await _cache();
      await _preservePendingPunches();
      notifyListeners();
    }
  }

  Future<void> checkDutyCutoff() async {
    await checkDayChangeAndCutoff();
  }

  bool get completed =>
      attendance != null && attendance!['punchOutUtc'] != null;
  Json? get office => offices.where((o) => o['id'] == officeId).firstOrNull;
  String get name =>
      user?['name']?.toString() ?? user?['NAME']?.toString() ?? 'Employee';
  String get employeeId =>
      user?['sM_USER_ID']?.toString() ??
      user?['SM_USER_ID']?.toString() ??
      user?['sm_USER_ID']?.toString() ??
      user?['userId']?.toString() ??
      '';

  static Map<String, dynamic> decodeSession(String raw) =>
      Map<String, dynamic>.from(jsonDecode(raw) as Map);

  Future<void> initialize() async {
    final savedTheme = await vault.readTheme();
    if (savedTheme != null) {
      isDarkMode = savedTheme == 'dark';
      darkModeNotifier.value = isDarkMode;
      notifyListeners();
    }
    final raw = await vault.read();
    if (raw == null) return;
    try {
      final saved = decodeSession(raw);
      final server = saved['server'] as String?;
      final token = saved['token'] as String?;
      if (server != api.baseUrl || token == null || token.isEmpty) {
        await vault.write(null);
        return;
      }
      final parts = token.split('.');
      if (parts.length != 3) {
        await vault.write(null);
        return;
      }
      final payload = jsonDecode(
        utf8.decode(base64Url.decode(base64Url.normalize(parts[1]))),
      );
      final exp = payload['exp'];
      if (exp is! num ||
          DateTime.fromMillisecondsSinceEpoch(
            (exp * 1000).round(),
            isUtc: true,
          ).isBefore(DateTime.now().toUtc())) {
        // Keep the encrypted phone workspace available offline; sync needs login.
        notice = 'Sign in again to resume server sync. Phone data is retained.';
      }
      user = Map<String, dynamic>.from(saved['user'] as Map);
      api.authorize(token);
      await _openLocal(token);
      final cache = saved['attendanceCache'];
      if (cache is Map) {
        enabledMenus = (cache['enabledMenus'] as List?)
            ?.map((e) => e.toString())
            .toSet();
        attendance = cache['attendance'] is Map
            ? Map<String, dynamic>.from(cache['attendance'])
            : null;
        offices = (cache['offices'] as List? ?? [])
            .map((o) => Map<String, dynamic>.from(o))
            .toList();
        officeId = cache['officeId'] as int?;
        isField = cache['isField'] == true;
        workDate = '${cache['workDate'] ?? ''}';
        offline = true;
        stateKnown = true;
        if (cache['lastLocation'] is Map) {
          lastLocation = Map<String, dynamic>.from(
            cache['lastLocation'] as Map,
          );
        }
        if (cache['punchOutLocation'] is Map) {
          punchOutLocation = Map<String, dynamic>.from(
            cache['punchOutLocation'] as Map,
          );
        }
        if (cache['pendingPunches'] is List) {
          pendingPunches = (cache['pendingPunches'] as List)
              .whereType<Map>()
              .map((e) => Map<String, dynamic>.from(e))
              .toList();
        }
      }
      if (local == null) {
        await _restorePreservedPendingPunches();
        await _restorePreservedPendingVisits();
      }
      if (local != null) await readLocal();
      await checkDayChangeAndCutoff();
      try {
        await DutyTracker.prepareUser(employeeId, api.baseUrl);
        await DutyTracker.resume(userId: employeeId, baseUrl: api.baseUrl);
        final tracking = await DutyTracker.status();
        if (tracking['clockAnchored'] == true &&
            tracking['userId'] == employeeId &&
            tracking['baseUrl'] == api.baseUrl) {
          syncServerTime(tracking['serverTimeUtc']);
        }
      } catch (_) {
        notice = 'Check tracking access in phone settings.';
      }
    } catch (_) {
      await signOut(autoPunchOut: false);
      return;
    }
    try {
      await refresh();
    } on ApiFailure catch (e) {
      if (e.status == 401 && local == null) {
        await signOut(autoPunchOut: false);
      } else {
        notice = e.toString();
      }
    }
  }

  Future<void> login(String username, String password) async {
    final response = await api.login(username, password);
    final token = response['token'];
    if (token is! String || token.isEmpty || response['user'] is! Map) {
      throw const ApiFailure(
        'INVALID_RESPONSE',
        'The login response did not contain a valid session.',
      );
    }
    final identity = Map<String, dynamic>.from(response['user'] as Map);
    await vault.write(
      jsonEncode({'server': api.baseUrl, 'token': token, 'user': identity}),
    );
    user = identity;
    api.authorize(token);
    await _openLocal(token);
    try {
      await DutyTracker.prepareUser(employeeId, api.baseUrl);
    } catch (_) {
      notice = 'Check tracking access in phone settings.';
    }
    notifyListeners();
    try {
      await refresh();
    } on ApiFailure catch (e) {
      notice = e.toString();
      notifyListeners();
    }
  }

  Future<void> signOut({bool autoPunchOut = false}) async {
    _workspaceRevision++;
    final usesLocal = local != null;
    if (local != null) {
      if (autoPunchOut && onDuty) await recordOfflinePunch();
      await DutyTracker.stop();
      await local!.pause();
      _localTimer?.cancel();
      local = null;
    }
    if (autoPunchOut && onDuty) {
      try {
        final nowUtc = DateTime.now().toUtc().toIso8601String();
        final loc = lastLocation ?? await locate();
        final attId =
            (attendance?['id'] is int && (attendance!['id'] as int) > 0)
            ? attendance!['id'] as int
            : (int.tryParse('${attendance?['id']}') ??
                  DateTime.now().millisecondsSinceEpoch);
        final payload = <String, dynamic>{
          if (!isField) 'officeId': officeId,
          ...loc,
          'attendanceId': attId,
          'earlyReason': 'Sign out auto punch-out',
        };
        pendingPunches.add({
          'out': true,
          'payload': payload,
          'time': nowUtc,
          'autoPunchOut': true,
        });
        await DutyTracker.stop();
      } catch (_) {}
    }
    if (!usesLocal) {
      await _preservePendingPunches();
      await _preservePendingVisits();
    }
    await vault.write(null);
    api.authorize(null);
    user = null;
    enabledMenus = null;
    attendance = null;
    offices = [];
    officeId = null;
    isField = false;
    stateKnown = false;
    lastLocation = null;
    outSelfieBase64 = null;
    pendingPunches = [];
    pendingVisits = [];
    notice = '';
    _serverAnchor = null;
    _serverAnchorRecordedAt = null;
    _sinceSync
      ..stop()
      ..reset();
    notifyListeners();
  }

  Future<void> refresh({int? selectedOffice}) async {
    if (local != null && stateKnown) {
      officeId = selectedOffice ?? officeId;
      unawaited(refreshMenus().catchError((Object _) {}));
      await _seedLocal();
      await readLocal();
      if (activeVisit == null && !offline && onDuty) {
        try {
          final state = await api.fieldState();
          if (state['activeVisit'] is Map && onDuty) {
            final av = Map<String, dynamic>.from(state['activeVisit'] as Map);
            final avDate = av['workDate']?.toString();
            if (avDate == null || avDate.isEmpty || avDate == localDay) {
              activeVisit = av;
            }
          }
        } catch (_) {}
      } else if (!onDuty) {
        activeVisit = null;
      }
      await checkDayChangeAndCutoff();
      await _tracking();
      unawaited(local!.sync().catchError((Object _) {}));
      return;
    }
    final previous = attendance;
    final previousMode = isField,
        previousOffices = offices,
        previousOfficeId = officeId;
    final known = stateKnown;
    notice = '';
    notifyListeners();
    try {
      final profile = await api.attendanceProfile();
      try {
        await refreshMenus();
      } catch (_) {
        enabledMenus ??= {
          'history',
          'locations',
          'leave',
          'activity',
          'reminder',
          'intimation',
          'inbox',
          'visits',
          'orders',
          'tasks',
          'offices',
        };
      }
      if (profile['mode'] != 'Field' && profile['mode'] != 'Office') {
        throw const ApiFailure(
          'INVALID_RESPONSE',
          'The server did not return a supported attendance mode.',
        );
      }
      isField = profile['mode'] == 'Field';
      if (isField) {
        offices = [];
        officeId = null;
        final state = await api.fieldState();
        attendance = state['attendance'] == null
            ? null
            : Map<String, dynamic>.from(state['attendance'] as Map);
        if (onDuty && state['activeVisit'] is Map) {
          final av = Map<String, dynamic>.from(state['activeVisit'] as Map);
          final avDate = av['workDate']?.toString();
          if (avDate == null || avDate.isEmpty || avDate == localDay) {
            activeVisit = av;
          } else {
            activeVisit = null;
          }
        } else {
          activeVisit = null;
        }
        workDate = state['workDate'].toString();
        syncServerTime(state['serverTimeUtc']);
        stateKnown = true;
        offline = false;
        if (local == null) {
          await syncPendingPunches();
          await syncPendingVisits();
        }
        await _tracking();
        await _cache();
        await _seedLocal();
        return;
      }
      offices = await api.offices();
      officeId = selectedOffice ?? officeId;
      if (!offices.any((o) => o['id'] == officeId)) {
        officeId =
            offices.where((o) => o['isEnabled'] == true).firstOrNull?['id']
                as int?;
        officeId ??= offices.firstOrNull?['id'] as int?;
      }
      if (officeId == null) {
        notice =
            'No office is assigned. Ask your administrator to configure your office and employee membership.';
        return;
      }
      var state = await api.state(officeId!);
      final record = state['attendance'];
      if (record is Map &&
          record['punchOutUtc'] == null &&
          record['officeId'] != officeId) {
        final openOfficeId = record['officeId'] as int;
        if (!offices.any((o) => o['id'] == openOfficeId)) {
          throw const ApiFailure(
            'OFFICE_ACCESS_DENIED',
            'Your open attendance belongs to an office you can no longer access. Contact your administrator.',
          );
        }
        officeId = openOfficeId;
        state = await api.state(officeId!);
      }
      attendance = state['attendance'] == null
          ? null
          : Map<String, dynamic>.from(state['attendance'] as Map);
      workDate = state['workDate'].toString();
      syncServerTime(state['serverTimeUtc']);
      stateKnown = true;
      offline = false;
      if (local == null) {
        await syncPendingPunches();
        await syncPendingVisits();
      }
      await _tracking();
      await _cache();
      await _seedLocal();
    } on ApiFailure catch (e) {
      if (e.status == 401 && local == null) {
        await signOut(autoPunchOut: false);
      } else {
        attendance = previous;
        isField = previousMode;
        offices = previousOffices;
        officeId = previousOfficeId;
        stateKnown = known;
        offline = true;
        notice = 'Saved locally. Will sync when online.';
      }
      rethrow;
    } finally {
      notifyListeners();
    }
  }

  Future<bool> syncData() async {
    isSyncing = true;
    notifyListeners();
    try {
      if (local != null) {
      unawaited(refreshMenus().catchError((Object _) {}));
      await readLocal();
      await local!.sync();
      // Poll sync status up to 5 seconds for background network executor to finish
      for (int i = 0; i < 10; i++) {
        await Future<void>.delayed(const Duration(milliseconds: 500));
        await readLocal();
        final p = (syncStatus['pending'] as num? ?? 0);
        final b = (syncStatus['blocked'] as num? ?? 0);
        if (p == 0 && b == 0) break;
      }
      try {
        await refresh();
      } catch (_) {}
      final hasPending = (syncStatus['pending'] as num? ?? 0) > 0;
      final hasBlocked = (syncStatus['blocked'] as num? ?? 0) > 0;
      final hasError = '${syncStatus['error'] ?? ''}'.isNotEmpty;
      if (hasBlocked) {
        offline = true;
        notice =
            'Sync needs review: ${syncStatus['error'] ?? 'All phone records are retained.'}';
      } else if (hasError) {
        offline = true;
        notice = '${syncStatus['error']}';
      } else if (hasPending) {
        notice = 'Syncing phone data with workspace...';
      } else {
        offline = false;
        notice = 'All phone data is synced with workspace.';
      }
      notifyListeners();
      return !hasPending && !hasBlocked && !hasError;
      }
    } finally {
      isSyncing = false;
      notifyListeners();
    }
    try {
      await DutyTracker.sync();
    } catch (_) {}

    try {
      final profile = await api.attendanceProfile();
      try {
        await refreshMenus();
      } catch (_) {
        enabledMenus ??= {
          'history',
          'locations',
          'leave',
          'activity',
          'reminder',
          'intimation',
          'inbox',
          'visits',
          'orders',
          'tasks',
          'offices',
        };
      }
      isField = profile['mode'] == 'Field';
      if (isField) {
        final state = await api.fieldState();
        attendance = state['attendance'] == null
            ? null
            : Map<String, dynamic>.from(state['attendance'] as Map);
        workDate = state['workDate'].toString();
        syncServerTime(state['serverTimeUtc']);
      } else {
        offices = await api.offices();
        if (officeId != null && offices.any((o) => o['id'] == officeId)) {
          final state = await api.state(officeId!);
          attendance = state['attendance'] == null
              ? null
              : Map<String, dynamic>.from(state['attendance'] as Map);
          workDate = state['workDate'].toString();
          syncServerTime(state['serverTimeUtc']);
        }
      }
      stateKnown = true;
      offline = false;
      if (local == null) {
        await syncPendingPunches();
        await syncPendingVisits();
      }
      await _tracking();
      await _cache();
      notice = 'Data synced successfully with workspace.';
      notifyListeners();
      return true;
    } on ApiFailure catch (_) {
      offline = true;
      notice = 'Saved locally. Will sync when online.';
      notifyListeners();
      return false;
    } catch (_) {
      offline = true;
      notice = 'Saved locally. Will sync when online.';
      notifyListeners();
      return false;
    }
  }

  Future<void> syncPendingPunches() async {
    if (pendingPunches.isEmpty) return;
    final queue = List<Map<String, dynamic>>.from(pendingPunches);
    for (final item in queue) {
      try {
        final out = item['out'] == true;
        final payload = Map<String, dynamic>.from(item['payload'] as Map);
        final saved = isField
            ? await api.fieldPunch(out, payload)
            : await api.punch(out, payload);
        pendingPunches.remove(item);
        attendance = saved;
        syncServerTime(saved['serverTimeUtc']);
        await _cache();
      } catch (_) {
        break;
      }
    }
    if (pendingPunches.isEmpty) {
      await vault.writePendingPunches(null);
    } else {
      await _preservePendingPunches();
    }
  }

  Future<Json> _quickFallbackLocation() async {
    try {
      final last = await Geolocator.getLastKnownPosition();
      if (last != null) {
        return {
          'latitude': last.latitude,
          'longitude': last.longitude,
          'accuracy': last.accuracy,
          'capturedAtUtc': last.timestamp.toUtc().toIso8601String(),
        };
      }
    } catch (_) {}
    return {
      'latitude': lastLocation?['latitude'] ?? 0.0,
      'longitude': lastLocation?['longitude'] ?? 0.0,
      'accuracy': lastLocation?['accuracy'] ?? 999.0,
      'capturedAtUtc': DateTime.now().toUtc().toIso8601String(),
    };
  }

  Future<void> recordOfflinePunch({
    String? reason,
    String? photo,
    Json? location,
  }) async {
    final revision = _workspaceRevision, initialUser = employeeId;
    if (local != null) {
      final out = onDuty;
      photo ??= out ? null : await takeSelfie();
      if (!out && photo == null) return;
      if (location == null) {
        try {
          location = await locate().timeout(const Duration(seconds: 15));
        } catch (_) {
          if (out) {
            location = lastLocation ?? await _quickFallbackLocation();
          } else {
            rethrow;
          }
        }
      }
      lastLocation = location;
      if (_disposed ||
          revision != _workspaceRevision ||
          initialUser != employeeId) {
        throw const ApiFailure(
          'SESSION_CHANGED',
          'Your session changed. Open attendance and try again.',
        );
      }
      final captured =
          location['capturedAtUtc']?.toString() ??
          DateTime.now().toUtc().toIso8601String();
      final id = const Uuid().v4();
      final localId = out
          ? attendance!['localId'] ?? attendance!['id']
          : DateTime.now().microsecondsSinceEpoch;
      final next = out
          ? <String, dynamic>{
              ...attendance!,
              'punchOutUtc': captured,
              'punchOutLat': location['latitude'],
              'punchOutLng': location['longitude'],
              'syncState': 'pending',
            }
          : <String, dynamic>{
              'id': localId,
              'localId': localId,
              'requestId': id,
              'workDate': localDay,
              'punchInUtc': captured,
              'punchInLat': location['latitude'],
              'punchInLng': location['longitude'],
              'punchInPhotoBase64': photo,
              if (!isField) 'officeId': officeId,
              'syncState': 'pending',
            };
      final body = <String, dynamic>{
        ...location,
        if (!isField) 'officeId': officeId,
        if (!out) 'selfieBase64': photo,
        if (out) 'attendanceId': attendance!['id'],
        if (reason != null) (out ? 'earlyReason' : 'lateReason'): reason.trim(),
      };
      final refs = <String, dynamic>{};
      if (out &&
          attendance!['serverId'] == null &&
          attendance!['requestId'] != null) {
        refs['attendanceId'] = {
          'operationId': attendance!['requestId'],
          'field': 'id',
        };
      }
      final day = await localDayData();
      await commitLocal(
        {...day, 'attendance': next},
        {
          'id': id,
          'route':
              '${isField ? 'Field' : 'Office'}Attendance/punch-${out ? 'out' : 'in'}',
          'body': body,
          'localId': localId,
          'refs': refs,
        },
      );
      attendance = next;
      lastLocation = location;
      if (out) {
        punchOutLocation = location;
        await DutyTracker.stop();
      } else {
        syncServerTime(captured);
        await _tracking();
      }
      await _cache();
      notifyListeners();
      return;
    }
    final out = onDuty;
    final attId = (attendance?['id'] is int && (attendance!['id'] as int) > 0)
        ? attendance!['id'] as int
        : (int.tryParse('${attendance?['id']}') ??
              DateTime.now().millisecondsSinceEpoch);
    photo ??= out ? null : await takeSelfie();
    if (!out && photo == null) return;
    location ??= await locate();
    lastLocation = location;
    final payload = <String, dynamic>{
      if (!isField) 'officeId': officeId,
      ...location,
      if (!out) 'selfieBase64': photo,
      if (out) 'attendanceId': attId,
      if (!isField && reason != null)
        (out ? 'earlyReason' : 'lateReason'): reason.trim(),
    };
    offline = true;
    final nowUtc = DateTime.now().toUtc().toIso8601String();
    if (out) {
      attendance = {
        ...?attendance,
        'punchOutUtc': nowUtc,
        'punchOutLat': location['latitude'],
        'punchOutLng': location['longitude'],
        'punchOutAddress': location['address'],
      };
      punchOutLocation ??= location;
      await DutyTracker.stop();
      notice =
          'Punch-out saved offline on phone. Will sync when server is reachable.';
    } else {
      attendance = {
        'id': DateTime.now().millisecondsSinceEpoch,
        'workDate': workDate.isNotEmpty
            ? workDate
            : DateTime.now().toLocal().toIso8601String().substring(0, 10),
        'punchInUtc': nowUtc,
        'punchInLat': location['latitude'],
        'punchInLng': location['longitude'],
        'punchInAddress': location['address'],
        'punchInPhotoBase64': photo,
        if (!isField) 'officeId': officeId,
      };
      lastLocation = location;
      notice =
          'Punch-in saved offline on phone. Tracking active. Will sync when server is reachable.';
      await _tracking();
    }
    pendingPunches.add({'out': out, 'payload': payload, 'time': nowUtc});
    await _cache();
    await _preservePendingPunches();
    notifyListeners();
  }

  Future<void> punch({String? reason, String? selfieBase64}) async {
    if (_savingPunch || _disposed) return;
    _savingPunch = true;
    try {
      await _performPunch(reason: reason, selfieBase64: selfieBase64);
    } finally {
      _savingPunch = false;
    }
  }

  Future<void> _performPunch({String? reason, String? selfieBase64}) async {
    if (!stateKnown || (!isField && officeId == null) || completed) {
      throw const ApiFailure(
        'REFRESH_REQUIRED',
        'Attendance cannot be recorded until workspace is initialized.',
      );
    }
    if (offline || local != null) {
      await recordOfflinePunch(reason: reason, photo: selfieBase64);
      return;
    }
    final out = onDuty;
    final attId = (attendance?['id'] is int && (attendance!['id'] as int) > 0)
        ? attendance!['id'] as int
        : (int.tryParse('${attendance?['id']}') ??
              DateTime.now().millisecondsSinceEpoch);
    final photo = out ? null : selfieBase64 ?? await takeSelfie();
    if (!out && photo == null) return;
    Json location;
    try {
      location = await locate().timeout(const Duration(seconds: 15));
    } catch (_) {
      if (out) {
        location = lastLocation ?? await _quickFallbackLocation();
      } else {
        rethrow;
      }
    }
    lastLocation = location;
    final payload = <String, dynamic>{
      if (!isField) 'officeId': officeId,
      ...location,
      if (!out) 'selfieBase64': photo,
      if (out) 'attendanceId': attId,
      if (!isField && reason != null)
        (out ? 'earlyReason' : 'lateReason'): reason.trim(),
    };
    try {
      final saved = isField
          ? await api.fieldPunch(out, payload)
          : await api.punch(out, payload);
      if (out) await DutyTracker.stop();
      attendance = saved;
      syncServerTime(saved['serverTimeUtc']);
      stateKnown = true;
      notice = out
          ? 'Punch-out confirmed by server.'
          : 'Punch-in confirmed by server.';
      offline = false;
      await _tracking();
      await _cache();
      final telemetry = location['telemetry'];
      if (telemetry is Map) {
        final missing = [
          if (telemetry['batteryPercent'] == null) 'battery',
          if (telemetry['deviceInfo'] == null) 'phone details',
          if (telemetry['city'] == null) 'city/address',
        ];
        if (missing.isNotEmpty) {
          notice += ' ${missing.join(', ')} unavailable for this punch.';
        }
      }
    } on ApiFailure catch (e) {
      if (e.status == null || e.status! >= 500 || e.status == 409) {
        try {
          await refresh();
        } catch (_) {
          /* Keep state unknown on failed reconciliation. */
        }
      }
      if (e.status == 401) await signOut(autoPunchOut: false);
      rethrow;
    } finally {
      notifyListeners();
    }
  }

  Future<bool> restoreDataFromServer() async {
    if (restoring) return false;
    restoring = true;
    final workspace = local, revision = _workspaceRevision;
    final owner = employeeId, baseUrl = api.baseUrl;
    bool same() =>
        !_disposed &&
        revision == _workspaceRevision &&
        identical(workspace, local) &&
        owner == employeeId &&
        baseUrl == api.baseUrl;
    void ensure() {
      if (!same()) {
        throw const ApiFailure(
          'SESSION_CHANGED',
          'Workspace changed during restore.',
        );
      }
    }

    var restored = 0;
    final failures = <String>[];
    try {
      if (workspace == null) {
        await refresh();
        ensure();
        notice = 'Workspace refreshed. Daily restore requires phone storage.';
        return false;
      }
      final state = await workspace.syncState();
      ensure();
      if ((state['pending'] as num? ?? 0) + (state['blocked'] as num? ?? 0) >
          0) {
        notice = 'Sync pending phone activities before restoring server data.';
        return false;
      }
      try {
        final value = await api.request('Portal/profile');
        ensure();
        if (value is Map) {
          final profile = Map<String, dynamic>.from(value);
          await workspace.write('response:Portal/profile:null', {
            'value': profile,
          });
          ensure();
          if (profile.containsKey('mode') || profile.containsKey('isField')) {
            isField = profile['mode'] == 'Field' || profile['isField'] == true;
          }
          if (profile['offices'] is List) offices = rowsOf(profile['offices']);
          if (!isField) {
            final office = offices
                .where((o) => o['isEnabled'] == true && o['isMember'] == true)
                .firstOrNull;
            officeId = (office?['id'] as num?)?.toInt();
          }
        }
      } catch (e, stack) {
        ensure();
        failures.add('profile');
        await ErrorLogger.record(e, stack, context: 'restore.profile');
      }
      final today = DateTime.parse(localDay);
      // Two concurrent downloads, separate date keys; never guess a date for the legacy day: record.
      var next = 0;
      Future<void> worker() async {
        while (next < 7) {
          ensure();
          final offset = next++;
          final day = LocalWorkspace.day(
            today.subtract(Duration(days: offset)),
          );
          try {
            final response = await api.request(
              'DutyTracking/day',
              body: {'date': day, 'includeRaw': true},
            );
            ensure();
            if (response is! Map) {
              throw const FormatException('Invalid daily report response');
            }
            final report = Map<String, dynamic>.from(response);
            if (!rowBelongs(report, owner, baseUrl) ||
                report['date'] != null &&
                    '${report['date']}'.substring(0, 10) != day) {
              throw const FormatException('Daily report owner/date mismatch');
            }
            final visitsResponse = await api.request(
              'MobileVisits/mine?date=$day',
            );
            ensure();
            if (visitsResponse is! List &&
                !(visitsResponse is Map && visitsResponse['rows'] is List)) {
              throw const FormatException('Invalid visit response');
            }
            final previous = await workspace.read('day:$day') ?? {};
            ensure();
            final old = previous['report'] is Map
                ? Map<String, dynamic>.from(previous['report'])
                : <String, dynamic>{};
            final visits = reconcileVisits(
              [
                ...rowsOf(old['visits']),
                ...rowsOf(report['visits']),
                ...rowsOf(visitsResponse),
                ...rowsOf(previous['visits']),
              ],
              [],
              day,
              owner,
              baseUrl,
            );
            final localAtt = previous['attendance'] is Map
                ? Map<String, dynamic>.from(previous['attendance'])
                : null;
            final serverAtt = rowsOf(report['attendance'])
                .where(
                  (r) =>
                      businessDay(
                        instant(r['punchInUtc']) ?? DateTime.utc(1970),
                      ) ==
                      day,
                )
                .firstOrNull;
            final attendance = reconcileAttendance(serverAtt, localAtt);
            final mergedReport = <String, dynamic>{
              ...old,
              ...report,
              'recordedPoints': mergePoints(
                [
                  ...rowsOf(old['recordedPoints']),
                  ...rowsOf(report['recordedPoints']),
                ],
                day,
                owner,
                baseUrl,
              ),
              'events': dayEvents([
                ...rowsOf(old['events']),
                ...rowsOf(report['events']),
                ...attendanceEvents([if (attendance != null) attendance], day),
              ], day),
              'visits': visits,
            };
            ensure();
            await workspace.write('day:$day', {
              ...previous,
              'report': mergedReport,
              'visits': visits,
              if (attendance != null) 'attendance': attendance,
            });
            ensure();
            restored++;
          } catch (e, stack) {
            ensure();
            failures.add(day);
            await ErrorLogger.record(e, stack, context: 'restore.day');
          }
        }
      }

      await Future.wait([worker(), worker()]);
      ensure();
      final range = <String, dynamic>{
        'fromDate': LocalWorkspace.day(
          today.subtract(const Duration(days: 30)),
        ),
        'toDate': localDay,
        'page': 1,
        'pageSize': 100,
      };
      for (final route in [
        'OfficeLeave/mine',
        'OfficeReminders/mine',
        'OfficePreIntimation/personal',
      ]) {
        ensure();
        try {
          final response = await api.request(
            route,
            body: route.endsWith('/personal') ? range : null,
          );
          ensure();
          if (response is! List) {
            throw const FormatException('Invalid request history response');
          }
          await workspace.write('collection:$route:', {'rows': response});
          ensure();
        } catch (e, stack) {
          ensure();
          failures.add(route);
          await ErrorLogger.record(e, stack, context: 'restore.requests');
        }
      }
      for (final office in offices.where(
        (o) => o['isMember'] == true && o['isEnabled'] == true,
      )) {
        ensure();
        final rows = <dynamic>[];
        var complete = false;
        try {
          for (var page = 1; page <= 100; page++) {
            final response = await api.request(
              'OfficeActivities/mine',
              body: {...range, 'officeId': office['id'], 'page': page},
            );
            ensure();
            if (response is! List) {
              throw const FormatException('Invalid activities response');
            }
            rows.addAll(response);
            if (response.length < 100) {
              complete = true;
              break;
            }
          }
          if (!complete) {
            throw const FormatException(
              'Activity history exceeds restore limit',
            );
          }
          await workspace.write(
            'collection:OfficeActivities/mine:${office['id']}',
            {'rows': rows},
          );
          ensure();
        } catch (e, stack) {
          ensure();
          failures.add('activities');
          await ErrorLogger.record(e, stack, context: 'restore.activities');
        }
      }
      await readLocal();
      ensure();
      restoreOffered = false;
      notice = failures.isEmpty
          ? '$restored daily timelines restored. Request/activity history covers the last 31 days.'
          : 'Restored $restored of 7 daily timelines; ${failures.length} downloads failed. Phone records are retained. Retry restore.';
      return failures.isEmpty && restored == 7;
    } catch (e, stack) {
      await ErrorLogger.record(e, stack, context: 'restore.interrupted');
      if (same()) {
        notice =
            'Restore interrupted. Downloaded days are retained; retry restore.';
      }
      return false;
    } finally {
      restoring = false;
      notifyListeners();
    }
  }
}
