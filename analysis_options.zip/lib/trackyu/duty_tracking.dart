import 'dart:async';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'api.dart';

/// Native foreground service owns encrypted persistence and uploads without Dart.
class DutyTracker {
  static const channel = MethodChannel('trackyu/duty_tracking');
  @visibleForTesting
  static bool? platformOverride;
  static bool get supported =>
      platformOverride ?? (!kIsWeb && Platform.isAndroid);
  static Future<Json> status() async => supported
      ? Map<String, dynamic>.from(
          await channel.invokeMapMethod<String, dynamic>('status') ?? {},
        )
      : {};
  static Future<void> resume({String? userId, String? baseUrl}) async {
    if (!supported) return;
    final saved = await status();
    if ((userId == null || saved['userId'] == userId) &&
        (baseUrl == null || saved['baseUrl'] == baseUrl)) {
      await channel.invokeMethod<void>('resume');
    }
  }

  static Future<void> prepareUser(String userId, String baseUrl) async {
    if (!supported) return;
    final saved = await status();
    if (saved['active'] == true &&
        (saved['userId'] != userId || saved['baseUrl'] != baseUrl)) {
      await stop();
    }
  }

  static Future<void> stop() async {
    try {
      if (supported) await channel.invokeMethod<void>('stop');
    } catch (_) {}
  }

  static Future<void> sync() async {
    if (supported) await channel.invokeMethod<void>('sync');
  }

  static Future<void> requestFreshFix({
    required String userId,
    required String baseUrl,
  }) async {
    if (!supported) return;
    await channel.invokeMethod<void>('refreshFix', {
      'userId': userId,
      'baseUrl': baseUrl,
    });
  }

  static Future<void> batterySettings() async {
    if (supported) await channel.invokeMethod<void>('batterySettings');
  }

  static Future<void> reconcile(
    TrackyuApi api,
    String mode,
    Json? attendance, {
    String? userId,
  }) async {
    if (!supported) return;
    if (userId != null) await prepareUser(userId, api.baseUrl);
    final native = await status();
    if (attendance == null) {
      // No session is only authoritative after a successful state response.
      if (native['active'] == true &&
          native['baseUrl'] == api.baseUrl &&
          (userId == null || native['userId'] == userId)) {
        await stop();
      }
      return;
    }
    final active = attendance['punchOutUtc'] == null;
    final expires = DateTime.tryParse('${native['expiresAtUtc']}');
    final same =
        native['baseUrl'] == api.baseUrl &&
        (userId == null || native['userId'] == userId) &&
        native['mode'] == mode &&
        native['attendanceId'] == attendance['id'];
    if (same &&
        '${native['dutyCutoffUtc'] ?? ''}'.isNotEmpty &&
        expires != null &&
        expires.isAfter(DateTime.now().toUtc().add(const Duration(days: 1)))) {
      if (active) {
        await resume();
      } else {
        await stop();
      }
      await sync();
      return;
    }
    if (!active && native['userId'] == null) return;
    try {
      final lease = Map<String, dynamic>.from(
        await api.request(
              'DutyTracking/lease',
              body: {'mode': mode, 'attendanceId': attendance['id']},
            )
            as Map,
      );
      final device = await api.currentDevice();
      await channel.invokeMethod<void>('configure', {
        'baseUrl': api.baseUrl,
        'userId': lease['userId'],
        'trackingKey': lease['trackingKey'],
        'deviceId': device['deviceId'],
        'mode': mode,
        'attendanceId': attendance['id'],
        'active': active,
        'expiresAtUtc': lease['expiresAtUtc'],
        'dutyCutoffUtc': lease['dutyCutoffUtc'],
        'serverTimeUtc': lease['serverTimeUtc'],
        'trackingMode': lease['trackingMode'] ?? lease['mode'],
        'intervalSeconds': lease['intervalSeconds'] ?? 60,
        'distanceFilterMeters': lease['distanceFilterMeters'] ?? 30,
        'uploadSeconds': lease['uploadSeconds'] ?? 60,
        'maxAccuracyMeters': lease['maxAccuracyMeters'] ?? 50,
        'geocodeBreadcrumbs': lease['geocodeBreadcrumbs'] ?? false,
      });
    } catch (_) {
      // Offline fallback: keep existing tracking active or stop when off-duty
      if (active) {
        await resume(userId: userId, baseUrl: api.baseUrl);
      } else {
        await stop();
      }
    }
  }

  static Future<List<Json>> route(
    String userId,
    DateTime date, {
    String? baseUrl,
    bool fullResolution = false,
    void Function(List<Json>)? onPage,
    bool Function()? isCancelled,
    int pageSize = 250,
  }) async {
    if (!supported || userId.trim().isEmpty) return [];
    final start = DateTime.utc(
      date.year,
      date.month,
      date.day,
    ).subtract(const Duration(minutes: 330));
    final rows = <Json>[];
    var offset = 0;
    do {
      if (isCancelled?.call() == true) break;
      List<dynamic>? result;
      try {
        result = await channel
            .invokeListMethod<dynamic>('route', {
              'userId': userId,
              if (baseUrl != null) 'baseUrl': baseUrl,
              'from': start.millisecondsSinceEpoch,
              'to': start.add(const Duration(days: 1)).millisecondsSinceEpoch,
              if (fullResolution) 'timeline': true,
              if (fullResolution) 'offset': offset,
              if (fullResolution) 'pageSize': pageSize,
            })
            .timeout(const Duration(seconds: 8));
      } catch (_) {
        break;
      }
      if (isCancelled?.call() == true) break;
      final page = (result ?? [])
          .map((v) => Map<String, dynamic>.from(v as Map))
          .toList();
      rows.addAll(page);
      onPage?.call(List<Json>.unmodifiable(rows));
      if (!fullResolution || page.length < pageSize) break;
      offset += page.length;
    } while (true);
    return rows;
  }
}
