import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'device_identity.dart';

typedef Json = Map<String, dynamic>;

class ApiFailure implements Exception {
  final String code, message;
  final String? traceId;
  final int? status;
  const ApiFailure(this.code, this.message, {this.traceId, this.status});
  @override
  String toString() =>
      traceId == null ? message : '$message\nReference: $traceId';
}

abstract class SessionVault {
  Future<String?> read();
  Future<void> write(String? value);
  Future<String?> readPendingPunches() async => null;
  Future<void> writePendingPunches(String? value) async {}
  Future<String?> readPendingVisits() async => null;
  Future<void> writePendingVisits(String? value) async {}
  Future<String?> readCachedVisits() async => null;
  Future<void> writeCachedVisits(String? value) async {}
  Future<String?> readTheme() async => null;
  Future<void> writeTheme(String? value) async {}
}

class SecureSessionVault implements SessionVault {
  static const _storage = FlutterSecureStorage();
  static const _key = 'trackyu.live.session.v1';
  static const _pendingKey = 'trackyu.pending_punches.v1';
  static const _pendingVisitsKey = 'trackyu.pending_visits.v1';
  static const _cachedVisitsKey = 'trackyu.cached_visits.v1';
  static const _themeKey = 'trackyu.theme_mode.v1';
  @override
  Future<String?> read() => _storage.read(key: _key);
  @override
  Future<void> write(String? value) => value == null
      ? _storage.delete(key: _key)
      : _storage.write(key: _key, value: value);
  @override
  Future<String?> readPendingPunches() => _storage.read(key: _pendingKey);
  @override
  Future<void> writePendingPunches(String? value) => value == null
      ? _storage.delete(key: _pendingKey)
      : _storage.write(key: _pendingKey, value: value);
  @override
  Future<String?> readPendingVisits() => _storage.read(key: _pendingVisitsKey);
  @override
  Future<void> writePendingVisits(String? value) => value == null
      ? _storage.delete(key: _pendingVisitsKey)
      : _storage.write(key: _pendingVisitsKey, value: value);
  @override
  Future<String?> readCachedVisits() => _storage.read(key: _cachedVisitsKey);
  @override
  Future<void> writeCachedVisits(String? value) => value == null
      ? _storage.delete(key: _cachedVisitsKey)
      : _storage.write(key: _cachedVisitsKey, value: value);
  @override
  Future<String?> readTheme() => _storage.read(key: _themeKey);
  @override
  Future<void> writeTheme(String? value) => value == null
      ? _storage.delete(key: _themeKey)
      : _storage.write(key: _themeKey, value: value);
}

class TrackyuApi {
  final Dio dio;
  final String baseUrl;
  final Future<Json> Function() deviceIdentity;
  Json? _device;
  TrackyuApi(String url, {Dio? client, Future<Json> Function()? deviceIdentity})
    : baseUrl = validateUrl(url),
      deviceIdentity = deviceIdentity ?? mobileDeviceIdentity,
      dio = client ?? Dio() {
    dio.options = BaseOptions(
      baseUrl: '$baseUrl/',
      connectTimeout: const Duration(seconds: 10),
      receiveTimeout: const Duration(seconds: 20),
      sendTimeout: const Duration(seconds: 20),
    );
  }
  static String validateUrl(String value) {
    final url = value.trim().replaceFirst(RegExp(r'/+$'), '');
    final uri = Uri.tryParse(url);
    const allowHttp = bool.fromEnvironment('ALLOW_LOCAL_HTTP');
    if (uri == null ||
        !uri.hasAuthority ||
        uri.host.isEmpty ||
        uri.userInfo.isNotEmpty ||
        uri.hasQuery ||
        uri.hasFragment ||
        !(uri.scheme == 'https' ||
            (kDebugMode && allowHttp && uri.scheme == 'http')) ||
        !uri.path.endsWith('/api')) {
      throw const ApiFailure(
        'API_CONFIGURATION',
        'Set API_BASE_URL to your Trackyu server URL ending in /api. HTTPS is required.',
      );
    }
    return url;
  }

  bool get authorized => dio.options.headers.containsKey('Authorization');

  void authorize(String? token) {
    dio.options.headers.remove('Authorization');
    if (token != null) dio.options.headers['Authorization'] = 'Bearer $token';
  }

  Future<dynamic> request(String route, {Json? body}) async {
    if (dio.options.headers.containsKey('Authorization')) {
      final identity = await currentDevice();
      dio.options.headers['X-Device-ID'] = identity['deviceId'];
    }
    try {
      final r = body == null
          ? await dio.get(route)
          : await dio.post(route, data: body);
      if (r.data is! Map) {
        throw const ApiFailure(
          'INVALID_RESPONSE',
          'Unexpected response from the API.',
        );
      }
      final envelope = Map<String, dynamic>.from(r.data as Map);
      if (envelope['success'] != true) {
        throw ApiFailure(
          envelope['errorCode']?.toString() ?? 'REQUEST_FAILED',
          envelope['message']?.toString() ??
              'The API could not complete this request.',
          traceId: envelope['traceId']?.toString(),
          status: r.statusCode,
        );
      }
      return envelope['data'];
    } on DioException catch (e) {
      final data = e.response?.data;
      final json = data is Map ? data : const {};
      final status = e.response?.statusCode;
      final punch = route.contains('Attendance/punch-');
      final visitWrite =
          route == 'MobileVisits/start' || route == 'MobileVisits/finish';
      final retryHelp = punch
          ? 'A punch may already have reached the server. Reload attendance before trying again.'
          : visitWrite
          ? 'The visit may already have been saved. Reload visits before trying again.'
          : body != null && route != 'Auth/login'
          ? 'Reload this screen to check the result before retrying.'
          : 'Check your connection and try again.';
      throw ApiFailure(
        json['errorCode']?.toString() ??
            (status == 401
                ? 'UNAUTHORIZED'
                : e.type == DioExceptionType.connectionTimeout ||
                      e.type == DioExceptionType.receiveTimeout ||
                      e.type == DioExceptionType.sendTimeout
                ? 'CONNECTION_TIMEOUT'
                : 'CONNECTION_FAILED'),
        validationMessage(json) ??
            json['message']?.toString() ??
            (status == 401
                ? 'Your login expired. Please sign in again.'
                : e.type == DioExceptionType.connectionTimeout ||
                      e.type == DioExceptionType.receiveTimeout ||
                      e.type == DioExceptionType.sendTimeout
                ? 'The connection is taking too long. $retryHelp'
                : 'Cannot reach your workspace. $retryHelp'),
        traceId: json['traceId']?.toString(),
        status: status,
      );
    }
  }

  static String? validationMessage(Map json) {
    if (json['errorCode'] != 'VALIDATION_ERROR' || json['errors'] is! Map) {
      return null;
    }
    final fields = (json['errors'] as Map).keys
        .map((k) => k.toString().split('.').last.toLowerCase())
        .toSet();
    if (fields.contains('accuracymeters')) {
      return 'GPS is not accurate enough. Enable precise location, move near a window or outdoors, and retry.';
    }
    if (fields.contains('capturedatutc') ||
        fields.contains('latitude') ||
        fields.contains('longitude')) {
      return 'A fresh GPS reading is required. Reload your location and try again.';
    }
    if (fields.contains('attendanceid')) {
      return 'Reload attendance before punching out. The attendance record is missing or invalid.';
    }
    if (fields.contains('officeid')) {
      return 'Your office assignment is missing or invalid. Reload attendance or contact your administrator.';
    }
    return null;
  }

  Future<Json> login(String username, String password) async =>
      Map<String, dynamic>.from(
        await request(
              'Auth/login',
              body: {
                'username': username.trim(),
                'userPassword': password,
                'clientType': 'mobile',
                ...await currentDevice(),
              },
            )
            as Map,
      );
  Future<Json> currentDevice() async => _device ??= await deviceIdentity();
  Future<Uint8List> attendanceSelfie(String mode, int id) async {
    final normalized = mode.toLowerCase() == 'office' ? 'Office' : 'Field';
    if (id < 1) {
      throw const ApiFailure('SELFIE_NOT_FOUND', 'Selfie not found.');
    }
    return privatePhoto('AttendanceSelfies/$normalized/$id');
  }

  Future<Uint8List> visitPhoto(int id, {String phase = 'in'}) {
    if (id < 1) throw const ApiFailure('VISIT_NOT_FOUND', 'Visit not found.');
    return privatePhoto('MobileVisits/$id/photo?phase=$phase');
  }

  Future<Uint8List> privatePhoto(String route) async {
    dio.options.headers['X-Device-ID'] = (await currentDevice())['deviceId'];
    try {
      final response = await dio.get<List<int>>(
        route,
        options: Options(responseType: ResponseType.bytes),
      );
      return Uint8List.fromList(response.data!);
    } on DioException catch (e) {
      throw ApiFailure(
        'SELFIE_LOAD_FAILED',
        e.response?.statusCode == 401
            ? 'Your login expired. Sign in again.'
            : 'Unable to load this photo. Check access and retry.',
        status: e.response?.statusCode,
        traceId: e.response?.headers.value('X-Correlation-ID'),
      );
    }
  }

  Future<Json> deviceChange(
    String username,
    String password, {
    String? reason,
  }) async => Map<String, dynamic>.from(
    await request(
          'DeviceBindings/${reason == null ? 'request-status' : 'request-change'}',
          body: {
            'username': username.trim(),
            'userPassword': password,
            'clientType': 'mobile',
            ...await currentDevice(),
            if (reason != null) 'reason': reason,
          },
        )
        as Map,
  );
  Future<List<Json>> offices() async =>
      (await request('WorkforceOffices/mine') as List)
          .map((e) => Map<String, dynamic>.from(e as Map))
          .toList();
  Future<Json> attendanceProfile() async =>
      Map<String, dynamic>.from(await request('AttendanceProfile/mine') as Map);
  Future<Json> fieldState() async =>
      Map<String, dynamic>.from(await request('FieldAttendance/state') as Map);
  Future<Json> fieldPunch(bool out, Json payload) async =>
      Map<String, dynamic>.from(
        await request(
              'FieldAttendance/${out ? 'punch-out' : 'punch-in'}',
              body: payload,
            )
            as Map,
      );
  Future<Json> state(int officeId) async => Map<String, dynamic>.from(
    await request('OfficeAttendance/state', body: {'officeId': officeId})
        as Map,
  );
  Future<Json> punch(bool out, Json payload) async => Map<String, dynamic>.from(
    await request(
          'OfficeAttendance/${out ? 'punch-out' : 'punch-in'}',
          body: payload,
        )
        as Map,
  );
}

Json decodeSession(String raw) =>
    Map<String, dynamic>.from(jsonDecode(raw) as Map);
