import 'dart:async';
import 'tracking_status.dart';
import 'visits.dart';
import 'network_speed.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'api.dart';
import 'controller.dart';
import 'readiness.dart';
import 'workspace.dart';
import 'visuals.dart';
import 'attendance_summary.dart';
import 'field_location_card.dart';
import 'error_logger.dart';

const trackyuBlue = Color(0xff1c6799);
const appVersion = 'v1.0.26';
const apiBaseUrl = String.fromEnvironment(
  'API_BASE_URL',
  defaultValue: 'https://trackyu.runasp.net/api',
);

class TrackyuApp extends StatefulWidget {
  final TrackyuController? controller;
  final DeviceReadiness? readiness;
  const TrackyuApp({super.key, this.controller, this.readiness});
  @override
  State<TrackyuApp> createState() => _TrackyuAppState();
}

class _TrackyuAppState extends State<TrackyuApp> {
  TrackyuController? controller;
  late Future<void> boot;
  DeviceReadiness? readiness;
  @override
  void initState() {
    super.initState();
    controller = widget.controller ?? TrackyuController(TrackyuApi(apiBaseUrl));
    controller!.addListener(_onControllerThemeChanged);
    boot = initialize();
    readiness =
        widget.readiness ??
        (widget.controller == null
            ? DeviceReadiness(
                PhoneReadiness(
                  controller!.api,
                  offlineAllowed: () => controller!.loggedIn,
                  cameraRequired: () =>
                      !controller!.onDuty && !controller!.completed,
                ),
              )
            : null);
    readiness?.addListener(() {
      if (controller != null && readiness != null) {
        final isDown = readiness!.checks.any(
          (c) =>
              (c.item == SetupItem.network || c.item == SetupItem.server) &&
              !c.ready,
        );
        if (isDown) {
          controller!.setOffline(true);
        } else if (readiness!.ready && controller!.offline) {
          controller!.setOffline(false);
          controller!.syncData();
        }
      }
    });
    readiness?.start();
  }

  Future<void> initialize() async {
    controller ??=
        widget.controller ?? TrackyuController(TrackyuApi(apiBaseUrl));
    await controller!.initialize().timeout(const Duration(seconds: 15));
    ErrorLogger.currentUserId = controller!.employeeId;
  }

  void _onControllerThemeChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    controller?.removeListener(_onControllerThemeChanged);
    if (widget.controller == null) controller?.dispose();
    readiness?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = controller;
    final themeListenable = c?.darkModeNotifier ?? ValueNotifier<bool>(false);
    return ValueListenableBuilder<bool>(
      valueListenable: themeListenable,
      builder: (context, isDark, _) {
        return MaterialApp(
          title: 'Trackyu',
          navigatorKey: ErrorLogger.navigatorKey,
          scaffoldMessengerKey: ErrorLogger.messengerKey,
          builder: (context, child) => readiness == null
              ? child!
              : AnimatedBuilder(
                  animation: readiness!,
                  builder: (_, _) => Stack(
                    children: [
                      child!,
                      if (readiness!.blocking)
                        Positioned.fill(
                          child: PopScope(
                            canPop: false,
                            child: SetupChecklist(
                              monitor: readiness!,
                              isDark: isDark,
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
          debugShowCheckedModeBanner: false,
          themeMode: isDark ? ThemeMode.dark : ThemeMode.light,
          theme: ThemeData(
            useMaterial3: true,
            brightness: Brightness.light,
            colorScheme: ColorScheme.fromSeed(
              seedColor: trackyuBlue,
              primary: trackyuBlue,
              brightness: Brightness.light,
            ),
            scaffoldBackgroundColor: const Color(0xfff3f6fb),
            appBarTheme: const AppBarTheme(
              backgroundColor: Color(0xfff3f6fb),
              foregroundColor: Color(0xff102c4a),
              elevation: 0,
              scrolledUnderElevation: 0,
            ),
            inputDecorationTheme: InputDecorationTheme(
              filled: true,
              fillColor: Colors.white,
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 18,
                vertical: 19,
              ),
              labelStyle: const TextStyle(color: Color(0xff64748b)),
              prefixIconColor: trackyuBlue,
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: const BorderSide(color: Color(0xffdce4ee)),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: const BorderSide(color: trackyuBlue, width: 1.5),
              ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
              ),
            ),
          ),
          darkTheme: ThemeData(
            useMaterial3: true,
            brightness: Brightness.dark,
            colorScheme: ColorScheme.fromSeed(
              seedColor: trackyuBlue,
              primary: const Color(0xff26c6da),
              brightness: Brightness.dark,
            ),
            scaffoldBackgroundColor: const Color(0xff121212),
            appBarTheme: const AppBarTheme(
              backgroundColor: Color(0xff121212),
              foregroundColor: Colors.white,
              elevation: 0,
              scrolledUnderElevation: 0,
            ),
            cardTheme: const CardThemeData(color: Color(0xff1e1e1e)),
            inputDecorationTheme: InputDecorationTheme(
              filled: true,
              fillColor: const Color(0xff1e1e1e),
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 18,
                vertical: 19,
              ),
              labelStyle: const TextStyle(color: Color(0xff94a3b8)),
              prefixIconColor: Color(0xff26c6da),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: const BorderSide(color: Color(0xff2d3135)),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: const BorderSide(
                  color: Color(0xff26c6da),
                  width: 1.5,
                ),
              ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
              ),
            ),
          ),
          home: FutureBuilder<void>(
            future: boot,
            builder: (context, snapshot) {
              if (snapshot.hasError) {
                return Scaffold(
                  body: Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(
                            Icons.refresh_rounded,
                            color: trackyuBlue,
                            size: 36,
                          ),
                          const SizedBox(height: 16),
                          const Text(
                            'Unable to open your workspace. Please try again.',
                            textAlign: TextAlign.center,
                          ),
                          const SizedBox(height: 20),
                          FilledButton(
                            onPressed: () {
                              setState(() {
                                boot = initialize();
                              });
                            },
                            child: const Text('Try again'),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              }
              if (snapshot.connectionState != ConnectionState.done) {
                return const Scaffold(
                  body: Center(child: CircularProgressIndicator()),
                );
              }
              return AnimatedBuilder(
                animation: controller!,
                builder: (_, _) => controller!.loggedIn
                    ? AttendancePage(
                        controller: controller!,
                        openSetup: readiness?.showChecklist,
                      )
                    : LegacyLogin(controller: controller!),
              );
            },
          ),
        );
      },
    );
  }
}

Future<void> showFailure(BuildContext context, Object error) {
  ErrorLogger.record(error, StackTrace.current, context: 'showFailure');
  final errorText = error is ApiFailure ? error.toString() : error.toString();
  return showDialog<void>(
    context: context,
    builder: (context) => AlertDialog(
      title: const Row(
        children: [
          Icon(Icons.error_outline_rounded, color: Color(0xffe11d48), size: 22),
          SizedBox(width: 8),
          Text('Trackyu Error'),
        ],
      ),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SelectableText(
              errorText,
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500),
            ),
          ],
        ),
      ),
      actions: [
        TextButton.icon(
          onPressed: () {
            Clipboard.setData(ClipboardData(text: error.toString()));
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('Error copied to clipboard'),
                duration: Duration(seconds: 2),
              ),
            );
          },
          icon: const Icon(Icons.copy_rounded, size: 16),
          label: const Text('Copy'),
        ),
        FilledButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('OK'),
        ),
      ],
    ),
  );
}

class LegacyLogin extends StatefulWidget {
  final TrackyuController controller;
  const LegacyLogin({super.key, required this.controller});
  @override
  State<LegacyLogin> createState() => _LegacyLoginState();
}

class _LegacyLoginState extends State<LegacyLogin> {
  final form = GlobalKey<FormState>();
  final username = TextEditingController(), password = TextEditingController();
  bool busy = false, obscure = true;
  bool deviceBlocked = false;
  String? deviceMessage;
  Future<void> deviceAction({bool status = false}) async {
    if (busy || !form.currentState!.validate()) return;
    setState(() => busy = true);
    try {
      String? reason;
      if (!status) {
        var text = '';
        final reasonForm = GlobalKey<FormState>();
        reason = await showDialog<String>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Request a phone change'),
            content: Form(
              key: reasonForm,
              child: TextFormField(
                autofocus: true,
                maxLines: 3,
                maxLength: 1000,
                onChanged: (v) => text = v,
                decoration: const InputDecoration(labelText: 'Reason'),
                validator: (v) => (v?.trim().length ?? 0) < 3
                    ? 'Enter a reason (at least 3 characters)'
                    : null,
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Cancel'),
              ),
              FilledButton(
                onPressed: () {
                  if (reasonForm.currentState!.validate()) {
                    Navigator.pop(context, text.trim());
                  }
                },
                child: const Text('Send request'),
              ),
            ],
          ),
        );
        if (reason == null) return;
      }
      final response = await widget.controller.api.deviceChange(
        username.text,
        password.text,
        reason: reason,
      );
      if (!mounted) return;
      setState(
        () => deviceMessage = response['status'] == 'Approved'
            ? 'Approved. Sign in again to bind this phone.'
            : response['status'] == 'Rejected'
            ? 'Rejected: ${response['reviewNote'] ?? 'Contact your administrator.'}'
            : response['status'] == 'None'
            ? 'No request from this phone yet.'
            : 'Request #${response['id']} is pending administrator approval.',
      );
    } catch (e) {
      if (mounted) await showFailure(context, e);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  void dispose() {
    username.dispose();
    password.dispose();
    super.dispose();
  }

  Future<void> login() async {
    if (busy || !form.currentState!.validate()) return;
    setState(() {
      busy = true;
      deviceBlocked = false;
      deviceMessage = null;
    });
    try {
      await widget.controller.login(username.text, password.text);
    } catch (e) {
      if (mounted) {
        if (e is ApiFailure && e.code == 'DEVICE_CHANGE_REQUIRED') {
          setState(() {
            deviceBlocked = true;
            deviceMessage = e.message;
          });
        } else {
          await showFailure(context, e);
        }
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      backgroundColor: isDark ? const Color(0xff121212) : const Color(0xfff3f6fb),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          IconButton(
            tooltip: isDark ? 'Switch to light mode' : 'Switch to dark mode',
            icon: Icon(
              isDark ? Icons.wb_sunny_rounded : Icons.nightlight_round,
              color: isDark ? const Color(0xffe2e8f0) : const Color(0xff475569),
            ),
            onPressed: () => widget.controller.toggleDarkMode(),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) => Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 460),
              child: AutofillGroup(
                child: Form(
                  key: form,
                  child: ListView(
                    padding: const EdgeInsets.fromLTRB(24, 0, 24, 28),
                    children: [
                      const LoginMasthead(),
                      const SizedBox(height: 30),
                      Text(
                        'Welcome back',
                        style: TextStyle(
                          fontSize: 27,
                          color: isDark ? Colors.white : const Color(0xff102c4a),
                          fontWeight: FontWeight.w700,
                          letterSpacing: -.7,
                        ),
                      ),
                      const SizedBox(height: 7),
                      Text(
                        'Your day starts here. Sign in to your workspace.',
                        style: TextStyle(
                          color: isDark ? const Color(0xff94a3b8) : const Color(0xff64748b),
                          height: 1.5,
                        ),
                      ),
                      const SizedBox(height: 24),
                    TextFormField(
                      controller: username,
                      enabled: !busy,
                      autofillHints: const [AutofillHints.username],
                      textInputAction: TextInputAction.next,
                      autocorrect: false,
                      enableSuggestions: false,
                      decoration: const InputDecoration(
                        labelText: 'User name',
                        prefixIcon: Icon(Icons.person_outline, size: 21),
                      ),
                      validator: (v) => v == null || v.trim().isEmpty
                          ? 'Enter your user name'
                          : null,
                    ),
                    const SizedBox(height: 18),
                    TextFormField(
                      controller: password,
                      enabled: !busy,
                      obscureText: obscure,
                      autofillHints: const [AutofillHints.password],
                      textInputAction: TextInputAction.done,
                      onFieldSubmitted: (_) => login(),
                      decoration: InputDecoration(
                        labelText: 'Password',
                        prefixIcon: const Icon(Icons.lock_outline, size: 21),
                        suffixIcon: IconButton(
                          onPressed: busy
                              ? null
                              : () => setState(() => obscure = !obscure),
                          tooltip: obscure ? 'Show password' : 'Hide password',
                          icon: Icon(
                            obscure
                                ? Icons.visibility_outlined
                                : Icons.visibility_off_outlined,
                            size: 21,
                          ),
                        ),
                      ),
                      validator: (v) =>
                          v == null || v.isEmpty ? 'Enter your password' : null,
                    ),
                    const SizedBox(height: 24),
                    FilledButton(
                      onPressed: busy ? null : login,
                      style: FilledButton.styleFrom(
                        minimumSize: const Size.fromHeight(56),
                        backgroundColor: trackyuBlue,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                      ),
                      child: busy
                          ? const SizedBox(
                              width: 22,
                              height: 22,
                              child: CircularProgressIndicator(
                                color: Colors.white,
                                strokeWidth: 2,
                              ),
                            )
                          : const Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  'Login',
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                                SizedBox(width: 12),
                                Icon(Icons.arrow_forward_rounded, size: 20),
                              ],
                            ),
                    ),
                    if (deviceBlocked) ...[
                      const SizedBox(height: 18),
                      Text(
                        deviceMessage ??
                            'Administrator approval is required for this phone.',
                        style: const TextStyle(color: Color(0xff9a5a12)),
                      ),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: [
                          TextButton(
                            onPressed: busy ? null : () => deviceAction(),
                            child: const Text('Request device change'),
                          ),
                          TextButton(
                            onPressed: busy
                                ? null
                                : () => deviceAction(status: true),
                            child: const Text('Check request status'),
                          ),
                        ],
                      ),
                    ],
                    const SizedBox(height: 26),
                    const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.lock_outline_rounded,
                          size: 14,
                          color: Color(0xff8292a6),
                        ),
                        SizedBox(width: 7),
                        Flexible(
                          child: Text(
                            'Connected. Wherever work takes you.',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 12,
                              color: Color(0xff8292a6),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    ),
  );
  }
}

class AttendancePage extends StatefulWidget {
  final TrackyuController controller;
  final VoidCallback? openSetup;
  const AttendancePage({super.key, required this.controller, this.openSetup});
  @override
  State<AttendancePage> createState() => _AttendancePageState();
}

class _AttendancePageState extends State<AttendancePage>
    with WidgetsBindingObserver {
  bool busy = false;
  Timer? _cutoffCheck;
  late final NetworkQualityMonitor network;
  TrackyuController get c => widget.controller;
  @override
  void initState() {
    super.initState();
    network = NetworkQualityMonitor.instance(c.api)..start();
    WidgetsBinding.instance.addObserver(this);
    _cutoffCheck = Timer.periodic(const Duration(seconds: 30), (_) {
      if (c.dutyCutoffReached && !busy) run(c.checkDutyCutoff);
    });
  }

  @override
  void dispose() {
    _cutoffCheck?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && !busy) {
      c.refresh().catchError((_) {});
    }
  }

  Future<void> run(Future<void> Function() action) async {
    if (busy) return;
    setState(() => busy = true);
    try {
      await action().timeout(
        const Duration(seconds: 35),
        onTimeout: () {
          throw const ApiFailure(
            'OPERATION_TIMEOUT',
            'Attendance request timed out. Please retry.',
          );
        },
      );
    } catch (e) {
      if (mounted) await showFailure(context, e);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<String?> reason(bool early) async {
    var text = '';
    final form = GlobalKey<FormState>();
    final value = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          early ? 'Early punch-out reason' : 'Late attendance reason',
        ),
        content: Form(
          key: form,
          child: TextFormField(
            onChanged: (value) => text = value,
            autofocus: true,
            minLines: 2,
            maxLines: 5,
            maxLength: 1000,
            decoration: const InputDecoration(labelText: 'Reason'),
            validator: (v) =>
                v == null || v.trim().isEmpty ? 'Please enter a reason' : null,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              if (form.currentState!.validate()) {
                Navigator.pop(context, text.trim());
              }
            },
            child: const Text('Submit'),
          ),
        ],
      ),
    );
    return value;
  }

  Future<void> syncNow() async {
    if (busy) return;
    setState(() => busy = true);
    try {
      final success = await c.syncData();
      if (mounted) {
        final message = success
            ? 'Data synced successfully with workspace!'
            : (c.notice.isNotEmpty ? c.notice : 'Data saved locally on phone.');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                Icon(
                  success ? Icons.cloud_done_rounded : Icons.cloud_sync_rounded,
                  color: Colors.white,
                  size: 20,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    message,
                    style: const TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
            backgroundColor: success
                ? const Color(0xff059669)
                : const Color(0xff1e40af),
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
            duration: const Duration(seconds: 3),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> punch() => run(() async {
    if (c.onDuty) {
      final duration = c.workingDuration;
      if (duration != null && duration < const Duration(hours: 9)) {
        final hours = duration.inHours;
        final minutes = duration.inMinutes.remainder(60);
        final timeStr = hours > 0 ? '$hours hr $minutes min' : '$minutes min';
        final confirm = await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('Early Punch-out?'),
            content: Text(
              'Aapne abhi tak 9 hours complete nahi kiye hain ($timeStr completed).\n\nKya aap sach me punch-out karna chahte hain?',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('Cancel'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('Confirm Punch-out'),
              ),
            ],
          ),
        );
        if (confirm != true) return;
      }
    }
    final photo = await c.takeSelfie();
    if (photo == null) return;
    if (c.onDuty) {
      await c.saveOutSelfie(photo);
    }
    try {
      await c.punch(selfieBase64: c.onDuty ? null : photo);
    } on ApiFailure catch (e) {
      if (e.code != 'LATE_REASON_REQUIRED' &&
          e.code != 'EARLY_REASON_REQUIRED') {
        final isNetwork =
            (e.status != null &&
                (e.status! >= 500 || e.status == 403 || e.status == 408)) ||
            e.code == 'CONNECTION_FAILED' ||
            e.code == 'CONNECTION_TIMEOUT' ||
            e.code == 'OPERATION_TIMEOUT' ||
            c.offline;
        if (isNetwork) {
          await c.recordOfflinePunch(photo: photo);
          return;
        }
        rethrow;
      }
      if (!mounted) return;
      final answer = await reason(e.code == 'EARLY_REASON_REQUIRED');
      if (answer != null) {
        try {
          await c.punch(reason: answer, selfieBase64: c.onDuty ? null : photo);
        } on ApiFailure catch (err) {
          final isNetwork =
              (err.status != null &&
                  (err.status! >= 500 ||
                      err.status == 403 ||
                      err.status == 408)) ||
              err.code == 'CONNECTION_FAILED' ||
              err.code == 'CONNECTION_TIMEOUT' ||
              err.code == 'OPERATION_TIMEOUT' ||
              c.offline;
          if (isNetwork) {
            await c.recordOfflinePunch(reason: answer, photo: photo);
            return;
          }
          rethrow;
        }
      }
    }
  });
  String clock(dynamic value) {
    final time = DateTime.tryParse(value?.toString() ?? '')?.toLocal();
    return time == null
        ? (c.stateKnown ? 'Not yet' : 'â€”')
        : '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}';
  }

  Widget timeCard(String label, dynamic value, IconData icon, Color tone) {
    final hasValue = value != null;
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: hasValue
                ? tone.withValues(alpha: 0.25)
                : const Color(0xffe2e8f0),
            width: hasValue ? 1.2 : 1.0,
          ),
          boxShadow: [
            BoxShadow(
              color: const Color(0xff102c4a).withValues(alpha: 0.03),
              blurRadius: 10,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding: const EdgeInsets.all(7),
                  decoration: BoxDecoration(
                    color: tone.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(icon, size: 18, color: tone),
                ),
                if (hasValue)
                  Container(
                    width: 7,
                    height: 7,
                    decoration: BoxDecoration(
                      color: tone,
                      shape: BoxShape.circle,
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              label.toUpperCase(),
              style: const TextStyle(
                color: Color(0xff64748b),
                fontSize: 11,
                fontWeight: FontWeight.w600,
                letterSpacing: 0.8,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              hasValue ? clock(value) : '— : —',
              style: TextStyle(
                color: hasValue
                    ? const Color(0xff0f172a)
                    : const Color(0xff94a3b8),
                fontSize: 22,
                fontWeight: FontWeight.w700,
                letterSpacing: -0.8,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final canPunch =
        !busy &&
        c.stateKnown &&
        !c.completed &&
        (c.isField ||
            (c.office != null && (c.onDuty || c.office!['isEnabled'] == true)));
    final status = !c.stateKnown
        ? 'Attendance not loaded'
        : c.completed
        ? 'Work is completed'
        : c.onDuty
        ? 'Punched in'
        : 'Ready to punch in';
    final isDark = c.isDarkMode;
    return Scaffold(
      backgroundColor: isDark
          ? const Color(0xff121212)
          : const Color(0xfff3f6fb),
      drawer: WorkspaceDrawer(controller: c, openSetup: widget.openSetup),
      appBar: AppBar(
        backgroundColor: isDark
            ? const Color(0xff121212)
            : const Color(0xfff3f6fb),
        title: FittedBox(
          fit: BoxFit.scaleDown,
          alignment: Alignment.centerLeft,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 30,
                height: 30,
                padding: const EdgeInsets.all(5),
                decoration: BoxDecoration(
                  color: const Color(0xff102c4a),
                  borderRadius: BorderRadius.circular(9),
                ),
                child: Image.asset('assets/legacy/logo.png'),
              ),
              const SizedBox(width: 6),
              const Text(
                'Trackyu',
                style: TextStyle(
                  fontWeight: FontWeight.w700,
                  letterSpacing: -.7,
                ),
              ),
              const SizedBox(width: 4),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                decoration: BoxDecoration(
                  color: isDark
                      ? const Color(0xff1e293b)
                      : const Color(0xffe2e8f0),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text(
                  appVersion,
                  style: TextStyle(
                    color: isDark
                        ? const Color(0xff94a3b8)
                        : const Color(0xff334155),
                    fontSize: 9.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
        ),
        actions: [
          ListenableBuilder(
            listenable: Listenable.merge([c, network]),
            builder: (context, _) => Padding(
              padding: const EdgeInsets.only(right: 6),
              child: Center(
                child: SyncNetworkAppBarPill(
                  controller: c,
                  network: network,
                  busy: busy,
                  onSync: () => syncNow(),
                ),
              ),
            ),
          ),
          IconButton(
            tooltip: isDark ? 'Switch to light mode' : 'Switch to dark mode',
            icon: Icon(
              isDark ? Icons.wb_sunny_rounded : Icons.nightlight_round,
            ),
            onPressed: () => c.toggleDarkMode(),
          ),
          PopupMenuButton<String>(
            enabled: !busy,
            onSelected: (val) => run(() async {
              if (val == 'theme') {
                await c.toggleDarkMode();
                return;
              }
              final confirm = await showDialog<bool>(
                context: context,
                builder: (context) => AlertDialog(
                  title: Text(
                    c.onDuty
                        ? 'Duty Active: Punch-out & Sign out?'
                        : 'Sign out?',
                  ),
                  content: Text(
                    c.onDuty
                        ? 'Aapki duty active hai. Logout karne par aapka offline punch-out automatically record ho jaega aur tracking stop ho jaegi. Sign out karein?'
                        : 'You can sign in again with your employee account.',
                  ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(context, false),
                      child: const Text('Cancel'),
                    ),
                    FilledButton(
                      onPressed: () => Navigator.pop(context, true),
                      child: Text(
                        c.onDuty ? 'Punch-out & Sign out' : 'Sign out',
                      ),
                    ),
                  ],
                ),
              );
              if (confirm == true) await c.signOut(autoPunchOut: true);
            }),
            itemBuilder: (_) => [
              PopupMenuItem(
                value: 'theme',
                child: Row(
                  children: [
                    Icon(
                      isDark ? Icons.wb_sunny_rounded : Icons.nightlight_round,
                      size: 18,
                    ),
                    const SizedBox(width: 8),
                    Text(isDark ? 'Light theme' : 'Dark theme'),
                  ],
                ),
              ),
              const PopupMenuItem(value: 'logout', child: Text('Sign out')),
            ],
          ),
        ],
      ),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 560),
            child: Column(
              children: [
                if (busy) const LinearProgressIndicator(minHeight: 2),
                Expanded(
                  child: RefreshIndicator(
                    onRefresh: () => syncNow(),
                    child: ListView(
                      physics: const AlwaysScrollableScrollPhysics(),
                      padding: const EdgeInsets.fromLTRB(22, 16, 22, 20),
                      children: [
                        Row(
                          children: [
                            CircleAvatar(
                              radius: 24,
                              backgroundColor: isDark
                                  ? const Color(0xff1e293b)
                                  : const Color(0xffe0eaf5),
                              child: Icon(
                                Icons.person_outline_rounded,
                                color: isDark
                                    ? const Color(0xff38bdf8)
                                    : trackyuBlue,
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Welcome, ${c.name}',
                                    style: TextStyle(
                                      color: isDark
                                          ? Colors.white
                                          : const Color(0xff102c4a),
                                      fontWeight: FontWeight.w600,
                                      fontSize: 17,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Wrap(
                                    spacing: 8,
                                    runSpacing: 4,
                                    crossAxisAlignment:
                                        WrapCrossAlignment.center,
                                    children: [
                                      if (c.employeeId.isNotEmpty)
                                        Container(
                                          padding: const EdgeInsets.symmetric(
                                            horizontal: 7,
                                            vertical: 2,
                                          ),
                                          decoration: BoxDecoration(
                                            color: isDark
                                                ? const Color(0xff1e293b)
                                                : const Color(0xffe8eef6),
                                            borderRadius: BorderRadius.circular(
                                              5,
                                            ),
                                            border: Border.all(
                                              color: isDark
                                                  ? const Color(0xff334155)
                                                  : const Color(0xffc9d8ea),
                                              width: 0.8,
                                            ),
                                          ),
                                          child: Text(
                                            'User ID: ${c.employeeId}',
                                            style: TextStyle(
                                              color: isDark
                                                  ? const Color(0xff93c5fd)
                                                  : const Color(0xff1b4d7e),
                                              fontWeight: FontWeight.w600,
                                              fontSize: 11,
                                            ),
                                          ),
                                        ),
                                      Text(
                                        c.workDate.isEmpty
                                            ? 'Your attendance workspace'
                                            : c.workDate,
                                        style: TextStyle(
                                          color: isDark
                                              ? const Color(0xff94a3b8)
                                              : const Color(0xff74849b),
                                          fontSize: 12,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 24),
                        if (c.offices.isNotEmpty) ...[
                          DropdownButtonFormField<int>(
                            key: ValueKey(c.officeId),
                            initialValue: c.officeId,
                            isExpanded: true,
                            decoration: const InputDecoration(
                              labelText: 'Office',
                              prefixIcon: Icon(Icons.business_outlined),
                            ),
                            items: c.offices
                                .map(
                                  (o) => DropdownMenuItem<int>(
                                    value: o['id'] as int,
                                    child: Text(
                                      o['name'].toString(),
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                )
                                .toList(),
                            onChanged: busy || c.onDuty
                                ? null
                                : (id) {
                                    if (id != null) {
                                      run(() => c.refresh(selectedOffice: id));
                                    }
                                  },
                          ),
                          const SizedBox(height: 20),
                        ],
                        AttendanceSummary(controller: c, status: status),
                        const SizedBox(height: 16),
                        TrackingStatusCard(controller: c),
                        const SizedBox(height: 16),
                        ListenableBuilder(
                          listenable: Listenable.merge([c, network]),
                          builder: (context, _) => NetworkSyncStatusCard(
                            controller: c,
                            network: network,
                            onSync: () => syncNow(),
                          ),
                        ),
                        const SizedBox(height: 16),
                        if (c.onDuty || c.menuEnabled('visits')) ...[
                          SalesmanVisitShortcut(
                            controller: c,
                            enabled: !busy,
                          ),
                          const SizedBox(height: 16),
                        ],
                        if (c.isField)
                          FieldAttendanceLocationCard(controller: c),
                        if (c.office != null)
                          Container(
                            padding: const EdgeInsets.all(18),
                            decoration: BoxDecoration(
                              color: isDark
                                  ? const Color(0xff1e1e1e)
                                  : const Color(0xffe9eff7),
                              borderRadius: BorderRadius.circular(18),
                              border: Border.all(
                                color: isDark
                                    ? const Color(0xff2d3135)
                                    : const Color(0xffdce4ee),
                              ),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Icon(
                                  Icons.business_outlined,
                                  color: isDark
                                      ? const Color(0xff38bdf8)
                                      : trackyuBlue,
                                  size: 20,
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Text(
                                    '${c.office!['shiftStart'].toString().split(':').take(2).join(':')} – ${c.office!['shiftEnd'].toString().split(':').take(2).join(':')} • ${c.office!['timeZoneId']}\n${c.office!['radiusMeters']} m office radius • ${c.office!['lateGraceMinutes']} min late grace',
                                    style: TextStyle(
                                      color: isDark
                                          ? const Color(0xffcbd5e1)
                                          : const Color(0xff475b75),
                                      fontSize: 12,
                                      height: 1.8,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        if (c.notice.isNotEmpty &&
                            !c.notice.toLowerCase().contains('connection') &&
                            !c.notice.toLowerCase().contains('cannot reach') &&
                            !c.notice.toLowerCase().contains('unavailable') &&
                            !c.notice.toLowerCase().contains('network') &&
                            !c.notice.toLowerCase().contains(
                              'sync will retry',
                            ) &&
                            !c.notice.toLowerCase().contains(
                              'sync requested',
                            ) &&
                            !c.notice.toLowerCase().contains(
                              'phone data remains available',
                            ) &&
                            !c.notice.toLowerCase().contains('retained'))
                          Padding(
                            padding: const EdgeInsets.only(top: 14),
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 14,
                                vertical: 12,
                              ),
                              decoration: BoxDecoration(
                                color: c.notice.contains('confirmed')
                                    ? const Color(0xffecfdf5)
                                    : const Color(0xfffffbeb),
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(
                                  color: c.notice.contains('confirmed')
                                      ? const Color(0xffa7f3d0)
                                      : const Color(0xfffde68a),
                                ),
                              ),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Icon(
                                    c.notice.contains('confirmed')
                                        ? Icons.check_circle_outline_rounded
                                        : Icons.info_outline_rounded,
                                    size: 18,
                                    color: c.notice.contains('confirmed')
                                        ? const Color(0xff059669)
                                        : const Color(0xffd97706),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: SelectableText(
                                      c.notice,
                                      style: TextStyle(
                                        color: c.notice.contains('confirmed')
                                            ? const Color(0xff065f46)
                                            : const Color(0xff92400e),
                                        fontSize: 12,
                                        fontWeight: FontWeight.w500,
                                        height: 1.4,
                                      ),
                                    ),
                                  ),
                                  if (!c.notice.contains('confirmed'))
                                    InkWell(
                                      onTap: busy ? null : () => syncNow(),
                                      borderRadius: BorderRadius.circular(8),
                                      child: const Padding(
                                        padding: EdgeInsets.symmetric(
                                          horizontal: 4,
                                        ),
                                        child: Icon(
                                          Icons.refresh_rounded,
                                          size: 18,
                                          color: Color(0xffd97706),
                                        ),
                                      ),
                                    ),
                                ],
                              ),
                            ),
                          ),
                        if (!c.stateKnown)
                          Padding(
                            padding: const EdgeInsets.only(top: 14),
                            child: OutlinedButton.icon(
                              onPressed: busy
                                  ? null
                                  : () => run(() => c.refresh()),
                              icon: const Icon(Icons.refresh),
                              label: const Text('Reload attendance'),
                            ),
                          ),
                        if (c.lastLocation != null)
                          Padding(
                            padding: const EdgeInsets.only(top: 14),
                            child: Text(
                              'Location accuracy: ${(c.lastLocation!['accuracyMeters'] as num).toStringAsFixed(0)} m',
                              style: TextStyle(
                                color: isDark
                                    ? const Color(0xff94a3b8)
                                    : const Color(0xff74849b),
                                fontSize: 12,
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
                if (!c.completed)
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 10, 16, 20),
                    child: SlidePunch(
                      enabled: canPunch,
                      hint: c.onDuty
                          ? 'Selfie and GPS required for punch-out'
                          : 'Selfie and GPS required for punch-in',
                      label: busy
                          ? 'Confirming attendance...'
                          : c.onDuty
                          ? 'Slide to punch out'
                          : 'Slide to punch in',
                      onSubmit: punch,
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class SlidePunch extends StatefulWidget {
  final bool enabled;
  final String label;
  final String? hint;
  final Future<void> Function() onSubmit;
  const SlidePunch({
    super.key,
    required this.enabled,
    required this.label,
    this.hint,
    required this.onSubmit,
  });
  @override
  State<SlidePunch> createState() => _SlidePunchState();
}

class _SlidePunchState extends State<SlidePunch> {
  double progress = 0;
  bool submitting = false;
  Future<void> submit() async {
    if (!widget.enabled || submitting) return;
    setState(() {
      progress = 0;
      submitting = true;
    });
    try {
      await widget.onSubmit();
    } finally {
      if (mounted) setState(() => submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final active = widget.enabled && !submitting;
    final large = MediaQuery.textScalerOf(context).scale(16) > 22;
    return Semantics(
      label: widget.label,
      button: true,
      enabled: active,
      onTap: active ? submit : null,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            height: large ? 92 : 76,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: active
                    ? [const Color(0xff1d789f), const Color(0xff155375)]
                    : [const Color(0xff97aab7), const Color(0xff8298a9)],
              ),
              borderRadius: BorderRadius.circular(40),
              border: Border.all(color: Colors.white.withValues(alpha: .3)),
              boxShadow: active
                  ? [
                      BoxShadow(
                        color: trackyuBlue.withValues(alpha: .22),
                        blurRadius: 22,
                        offset: const Offset(0, 8),
                      ),
                    ]
                  : [],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(40),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Positioned.fill(
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: FractionallySizedBox(
                        widthFactor: progress,
                        child: Container(
                          color: const Color(0xff75d5b3).withValues(alpha: .3),
                        ),
                      ),
                    ),
                  ),
                  if (!submitting)
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 66),
                      child: AnimatedOpacity(
                        duration: const Duration(milliseconds: 120),
                        opacity: (1 - progress * 1.4).clamp(0, 1),
                        child: Text(
                          widget.label,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w600,
                            fontSize: 15,
                            letterSpacing: .1,
                          ),
                        ),
                      ),
                    ),
                  if (!submitting)
                    const Positioned(
                      right: 22,
                      child: Icon(
                        Icons.keyboard_double_arrow_right_rounded,
                        color: Colors.white38,
                        size: 26,
                      ),
                    ),
                  if (submitting)
                    const Padding(
                      padding: EdgeInsets.only(left: 76, right: 20),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 2,
                            ),
                          ),
                          SizedBox(width: 10),
                          Flexible(
                            child: Text(
                              'Confirming...',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w600,
                                fontSize: 15,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  SliderTheme(
                    data: SliderTheme.of(context).copyWith(
                      trackHeight: 0,
                      inactiveTrackColor: Colors.transparent,
                      activeTrackColor: Colors.transparent,
                      overlayColor: Colors.transparent,
                      thumbColor: Colors.white,
                      disabledThumbColor: const Color(0xffe5edf1),
                      thumbShape: const _PunchThumb(),
                      trackShape: const _PunchTrack(),
                    ),
                    child: Slider(
                      value: progress,
                      padding: EdgeInsets.zero,
                      allowedInteraction: SliderInteraction.slideOnly,
                      onChanged: active
                          ? (v) => setState(() => progress = v)
                          : null,
                      onChangeEnd: active
                          ? (v) {
                              if (v >= .9) {
                                submit();
                              } else {
                                setState(() => progress = 0);
                              }
                            }
                          : null,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(
                Icons.lock_outline_rounded,
                size: 12,
                color: Color(0xff8393a5),
              ),
              const SizedBox(width: 6),
              Flexible(
                child: Text(
                  submitting
                      ? 'Waiting for server confirmation'
                      : widget.hint ?? 'Swipe all the way to confirm',
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 11,
                    color: Color(0xff8393a5),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _PunchTrack extends RoundedRectSliderTrackShape {
  const _PunchTrack();
  @override
  Rect getPreferredRect({
    required RenderBox parentBox,
    Offset offset = Offset.zero,
    required SliderThemeData sliderTheme,
    bool isEnabled = false,
    bool isDiscrete = false,
  }) => Rect.fromLTWH(
    offset.dx + 36,
    offset.dy + parentBox.size.height / 2,
    (parentBox.size.width - 72).clamp(0, double.infinity),
    0,
  );
}

class _PunchThumb extends RoundSliderThumbShape {
  const _PunchThumb()
    : super(enabledThumbRadius: 27, elevation: 0, pressedElevation: 0);
  @override
  void paint(
    PaintingContext context,
    Offset center, {
    required Animation<double> activationAnimation,
    required Animation<double> enableAnimation,
    required bool isDiscrete,
    required TextPainter labelPainter,
    required RenderBox parentBox,
    required SliderThemeData sliderTheme,
    required TextDirection textDirection,
    required double value,
    required double textScaleFactor,
    required Size sizeWithOverflow,
  }) {
    super.paint(
      context,
      center,
      activationAnimation: activationAnimation,
      enableAnimation: enableAnimation,
      isDiscrete: isDiscrete,
      labelPainter: labelPainter,
      parentBox: parentBox,
      sliderTheme: sliderTheme,
      textDirection: textDirection,
      value: value,
      textScaleFactor: textScaleFactor,
      sizeWithOverflow: sizeWithOverflow,
    );
    final direction = textDirection == TextDirection.ltr ? 1.0 : -1.0;
    final arrow = Path()
      ..moveTo(center.dx - 3 * direction, center.dy - 6)
      ..lineTo(center.dx + 3 * direction, center.dy)
      ..lineTo(center.dx - 3 * direction, center.dy + 6);
    context.canvas.drawPath(
      arrow,
      Paint()
        ..color = trackyuBlue
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.5
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round,
    );
  }
}
