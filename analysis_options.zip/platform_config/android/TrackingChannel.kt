package com.fieldforce.fieldforce_hrms
import android.app.Activity
import android.content.Intent
import android.provider.Settings
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.BinaryMessenger
import org.json.JSONObject
import java.util.concurrent.Executors
class TrackingChannel(private val activity: Activity,messenger: BinaryMessenger){
 private val executor=Executors.newSingleThreadExecutor()
 init {MethodChannel(messenger,"trackyu/duty_tracking").setMethodCallHandler {call,result->try{when(call.method){
  "configure"->{TrackingRuntime.configure(activity,JSONObject(call.arguments as Map<*,*>));result.success(TrackingRuntime.jsonMap(TrackingRuntime.status(activity)))}
  "status"->{result.success(TrackingRuntime.jsonMap(TrackingRuntime.status(activity)))}
  "resume"->{TrackingRuntime.start(activity);result.success(null)}
  "stop"->{TrackingRuntime.stop(activity);result.success(null)}
  "sync"->{TrackingRuntime.schedule(activity);executor.execute {TrackingRuntime.sync(activity)};result.success(null)}
  "batterySettings"->{activity.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));result.success(null)}
  "route"->{val args=call.arguments as Map<*,*>;val cfg=TrackingRuntime.store(activity).config();require(args["userId"]==cfg.optString("userId"));val points=TrackingRuntime.store(activity).route(cfg.getString("userId"),(args["from"] as Number).toLong(),(args["to"] as Number).toLong());result.success(points.map {TrackingRuntime.jsonMap(it)})}
  else->result.notImplemented()
 }}catch(_:Exception){result.error("TRACKING_UNAVAILABLE","Unable to access duty tracking. Check location permission and phone storage.",null)}}}
}
