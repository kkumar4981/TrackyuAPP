package com.fieldforce.fieldforce_hrms

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.Network
import android.os.*
import android.provider.Settings
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability
import com.google.android.gms.location.*
import org.json.JSONObject
import java.time.Instant
import java.util.UUID
import java.util.concurrent.Executors
import kotlin.math.max

class DutyLocationService: Service(),LocationListener {
    private val handler=Handler(Looper.getMainLooper())
    private val executor=Executors.newSingleThreadExecutor()
    private val uploadQueued=java.util.concurrent.atomic.AtomicBoolean(false)
    private var fused: FusedLocationProviderClient?=null
    private var fallback=false
    private var lastElapsed=0L
    private var lastCaptured=0L
    private var lastCoarse=0L
    private var running=false
    private val callback=object: LocationCallback(){override fun onLocationResult(result: LocationResult){for(location in result.locations)accept(location,"fused")}}
    private val networkCallback=object: ConnectivityManager.NetworkCallback(){override fun onAvailable(network: Network){upload()}}
    private val tick=object:Runnable {override fun run(){if(!running)return;try{if(!TrackingRuntime.fine(this@DutyLocationService)){state("Location permission removed");stopSelf();return};if(SystemClock.elapsedRealtime()-lastElapsed>60000)fallback();upload();notification();}catch(_:Exception){state("Waiting for accurate GPS")};handler.postDelayed(this,30000)}}
    override fun onCreate(){super.onCreate();createChannel()}
    override fun onBind(intent: Intent?): IBinder?=null
    override fun onStartCommand(intent: Intent?,flags: Int,startId: Int): Int {
        try {
            if(!TrackingRuntime.store(this).config().optBoolean("active")){stopSelf();return START_NOT_STICKY}
            startForeground(417,buildNotification(),ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
            if(!running){running=true;TrackingRuntime.store(this).updateState {it.put("running",true);it.put("status","Waiting for accurate GPS")};startLocations();(getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager).registerDefaultNetworkCallback(networkCallback);handler.post(tick)}
        }catch(_:Exception){state("Open the app and allow precise background location");stopSelf();return START_NOT_STICKY}
        return START_STICKY
    }
    private fun createChannel(){(getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(NotificationChannel("trackyu_duty","On-duty location tracking",NotificationManager.IMPORTANCE_LOW))}
    private fun buildNotification(): Notification {
        val intent=PendingIntent.getActivity(this,0,Intent(this,MainActivity::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val state=try{TrackingRuntime.status(this)}catch(_:Exception){JSONObject()}
        val text=if(!TrackingRuntime.gps(this))"GPS is off - turn it on to record your route" else "${state.optInt("pendingCount")} locations pending sync. Tracking during your duty."
        return Notification.Builder(this,"trackyu_duty").setSmallIcon(android.R.drawable.ic_menu_mylocation).setContentTitle("Trackyu duty tracking").setContentText(text).setContentIntent(intent).setOngoing(true).setOnlyAlertOnce(true).build()
    }
    private fun notification(){(getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(417,buildNotification())}
    private fun state(message: String){try{TrackingRuntime.store(this).updateState {it.put("status",message.take(64));it.put("lastError",message)}}catch(_:Exception){}}
    @Suppress("MissingPermission") private fun startLocations(){
        if(!TrackingRuntime.fine(this)){throw SecurityException()}
        if(GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(this)==ConnectionResult.SUCCESS){
            try {fused=LocationServices.getFusedLocationProviderClient(this);val request=LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY,15000).setMinUpdateIntervalMillis(10000).setMaxUpdateDelayMillis(30000).setMinUpdateDistanceMeters(0f).setWaitForAccurateLocation(true).build();fused!!.requestLocationUpdates(request,callback,Looper.getMainLooper()).addOnFailureListener {fallback()}}catch(_:Exception){fallback()}
        }else{fallback()}
    }
    @Suppress("MissingPermission") private fun fallback(){
        if(fallback)return;fallback=true;val manager=getSystemService(LOCATION_SERVICE) as LocationManager
        for(provider in listOf(LocationManager.GPS_PROVIDER,LocationManager.NETWORK_PROVIDER)){try{if(manager.isProviderEnabled(provider))manager.requestLocationUpdates(provider,15000,0f,this,Looper.getMainLooper())}catch(_:Exception){state("Enable precise location and GPS")}}
        if(!TrackingRuntime.gps(this)){fallback=false;state("GPS is off")}
    }
    override fun onLocationChanged(location: Location){accept(location,location.provider?:"gps")}
    override fun onProviderEnabled(provider: String){fallback=false;fallback()}
    override fun onProviderDisabled(provider: String){state("GPS provider unavailable")}
    @Deprecated("Android legacy callback") override fun onStatusChanged(provider: String?,status: Int,extras: Bundle?){}
    private fun accept(location: Location,provider: String){
        if(!running)return
        try {
            val db=TrackingRuntime.store(this);val cfg=db.config();if(!cfg.optBoolean("active"))return
            val elapsed=SystemClock.elapsedRealtime();val age=elapsed-location.elapsedRealtimeNanos/1000000
            val mocked=if(Build.VERSION.SDK_INT>=31)location.isMock else location.isFromMockProvider
            if(mocked||!location.hasAccuracy()||!location.latitude.isFinite()||!location.longitude.isFinite()||location.accuracy<0||age !in -5000..120000){db.updateState {it.put("rejectedCount",it.optInt("rejectedCount")+1);it.put("status",if(mocked)"Mock location rejected" else "Waiting for a fresh GPS fix")};return}
            if(location.elapsedRealtimeNanos/1000000<=lastCaptured)return
            if(location.accuracy>50&&elapsed-lastCoarse<60000)return
            val sameBoot=cfg.optInt("bootCount")==Settings.Global.getInt(contentResolver,Settings.Global.BOOT_COUNT,-2)
            val captured=if(sameBoot)cfg.getLong("anchorUtc")+(location.elapsedRealtimeNanos/1000000-cfg.getLong("anchorElapsed")) else location.time
            val battery=(getSystemService(BATTERY_SERVICE) as BatteryManager).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            val point=JSONObject().put("id",UUID.randomUUID().toString()).put("mode",cfg.getString("mode")).put("attendanceId",cfg.getLong("attendanceId")).put("capturedAtUtc",Instant.ofEpochMilli(captured).toString()).put("latitude",location.latitude).put("longitude",location.longitude).put("accuracyMeters",location.accuracy.toDouble()).put("isMocked",false).put("provider",provider.take(24)).put("batteryPercent",if(battery in 0..100)battery else JSONObject.NULL)
            if(location.hasSpeed())point.put("speedMps",location.speed.toDouble());if(location.hasBearing())point.put("bearing",location.bearing.toDouble())
            db.append(cfg.getString("userId"),point);lastCaptured=location.elapsedRealtimeNanos/1000000;lastElapsed=elapsed;if(location.accuracy>50)lastCoarse=elapsed
            db.updateState {s->s.put("lastPoint",point);s.put("lastFixAtUtc",point.getString("capturedAtUtc"));s.put("status",if(location.accuracy<=50)"Recording duty route" else "GPS accuracy is low");s.put("running",true)
                if(location.accuracy<=50){val anchor=s.optJSONObject("stationary");if(anchor==null||captured-anchor.optLong("last")>180000||distance(anchor.optDouble("lat"),anchor.optDouble("lng"),location.latitude,location.longitude)>50){s.put("stationary",JSONObject().put("lat",location.latitude).put("lng",location.longitude).put("start",captured).put("last",captured));s.remove("stopCandidate")}else{anchor.put("last",captured);if(captured-anchor.getLong("start")>=600000)s.put("stopCandidate",JSONObject().put("latitude",anchor.getDouble("lat")).put("longitude",anchor.getDouble("lng")).put("startUtc",Instant.ofEpochMilli(anchor.getLong("start")).toString()).put("minutes",(captured-anchor.getLong("start"))/60000))}}
            }
            upload();notification()
        }catch(_:Exception){state("Unable to save location - check phone storage")}
    }
    private fun distance(a:Double,b:Double,c:Double,d:Double):Float{val result=FloatArray(1);Location.distanceBetween(a,b,c,d,result);return result[0]}
    private fun upload(){if(!executor.isShutdown&&uploadQueued.compareAndSet(false,true))executor.execute {try{TrackingRuntime.sync(this)}finally{uploadQueued.set(false)}}}
    override fun onDestroy(){running=false;handler.removeCallbacksAndMessages(null);try{fused?.removeLocationUpdates(callback);(getSystemService(LOCATION_SERVICE) as LocationManager).removeUpdates(this);(getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager).unregisterNetworkCallback(networkCallback)}catch(_:Exception){};executor.shutdown();try{TrackingRuntime.store(this).updateState {it.put("running",false)};TrackingRuntime.schedule(this)}catch(_:Exception){};stopForeground(STOP_FOREGROUND_REMOVE);super.onDestroy()}
}
class TrackingBootReceiver: BroadcastReceiver(){override fun onReceive(context: Context,intent: Intent){try{val cfg=TrackingRuntime.store(context).config();if(cfg.optString("userId").isNotBlank()){TrackingRuntime.schedule(context);if(cfg.optBoolean("active")&&TrackingRuntime.background(context)&&TrackingRuntime.fine(context))TrackingRuntime.start(context)}}catch(_:Exception){}}}
