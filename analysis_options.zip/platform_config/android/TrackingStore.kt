package com.fieldforce.fieldforce_hrms

import android.content.Context
import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONObject
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class TrackingStore(private val context: Context, name: String = "duty_locations_v1.db", private val alias: String = "trackyu_duty_v1") : SQLiteOpenHelper(context,name,null,1) {
    private val prefs = context.getSharedPreferences(name+".state",Context.MODE_PRIVATE)
    init { setWriteAheadLoggingEnabled(true) }
    override fun onCreate(db: SQLiteDatabase) { db.execSQL("CREATE TABLE samples(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,captured INTEGER NOT NULL,ack INTEGER NOT NULL DEFAULT 0,payload TEXT NOT NULL)");db.execSQL("CREATE INDEX pending ON samples(user_id,ack,captured)") }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int,newVersion: Int) {}
    private fun key(): SecretKey { val ks=KeyStore.getInstance("AndroidKeyStore").apply { load(null) }; return (ks.getKey(alias,null) as? SecretKey) ?: KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore").run { init(KeyGenParameterSpec.Builder(alias,KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());generateKey() } }
    @Synchronized private fun encrypt(value: String): String { val cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,key());return Base64.encodeToString(cipher.iv+cipher.doFinal(value.toByteArray(Charsets.UTF_8)),Base64.NO_WRAP) }
    @Synchronized private fun decrypt(value: String): String { val bytes=Base64.decode(value,Base64.NO_WRAP);require(bytes.size>28);val cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,key(),GCMParameterSpec(128,bytes.copyOfRange(0,12)));return String(cipher.doFinal(bytes.copyOfRange(12,bytes.size)),Charsets.UTF_8) }
    @Synchronized fun config(): JSONObject = prefs.getString("config",null)?.let { JSONObject(decrypt(it)) } ?: JSONObject()
    @Synchronized fun saveConfig(value: JSONObject) { check(prefs.edit().putString("config",encrypt(value.toString())).commit()) }
    @Synchronized fun state(): JSONObject = prefs.getString("state",null)?.let { JSONObject(decrypt(it)) } ?: JSONObject()
    @Synchronized fun updateState(block: (JSONObject)->Unit) { val value=state();block(value);check(prefs.edit().putString("state",encrypt(value.toString())).commit()) }
    @Synchronized fun append(user: String, point: JSONObject) { if(total()>=100000)throw IllegalStateException("Location storage limit reached");val values=ContentValues().apply { put("id",point.getString("id"));put("user_id",user);put("captured",java.time.Instant.parse(point.getString("capturedAtUtc")).toEpochMilli());put("payload",encrypt(point.toString())) }; writableDatabase.insertWithOnConflict("samples",null,values,SQLiteDatabase.CONFLICT_IGNORE) }
    fun total(): Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM samples",null).use { it.moveToFirst();it.getInt(0) }
    fun pending(user: String): Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM samples WHERE user_id=? AND ack=0",arrayOf(user)).use {it.moveToFirst();it.getInt(0)}
    fun batch(user: String): List<JSONObject> = readableDatabase.rawQuery("SELECT payload FROM samples WHERE user_id=? AND ack=0 ORDER BY captured,id LIMIT 100",arrayOf(user)).use { cursor->buildList {while(cursor.moveToNext())add(JSONObject(decrypt(cursor.getString(0))))} }
    @Synchronized fun acknowledge(user: String, id: String, rejected: Boolean) { val v=ContentValues().apply {put("ack",if(rejected)2 else 1)};writableDatabase.update("samples",v,"user_id=? AND id=? AND ack=0",arrayOf(user,id)) }
    fun route(user: String, from: Long,to: Long): List<JSONObject> = readableDatabase.rawQuery("SELECT payload FROM samples WHERE user_id=? AND captured>=? AND captured<? AND ack<>2 ORDER BY captured LIMIT 10000",arrayOf(user,from.toString(),to.toString())).use {cursor->buildList {while(cursor.moveToNext())add(JSONObject(decrypt(cursor.getString(0))))} }
    @Synchronized fun prune(now: Long) { val expired=readableDatabase.rawQuery("SELECT COUNT(*) FROM samples WHERE captured<? AND ack=0",arrayOf((now-7*86400000L).toString())).use {it.moveToFirst();it.getInt(0)};writableDatabase.delete("samples","captured<?",arrayOf((now-7*86400000L).toString()));if(expired>0)updateState {it.put("rejectedCount",it.optInt("rejectedCount")+expired);it.put("lastError","Some locations exceeded the seven-day offline window.")} }
}
