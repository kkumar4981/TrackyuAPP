package com.fieldforce.fieldforce_hrms

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import androidx.core.content.ContextCompat
import androidx.work.*
import org.json.JSONObject
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.time.Instant
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

object TrackingRuntime {
    @Volatile private var instance: TrackingStore?=null
    val syncing=AtomicBoolean(false)
    fun store(context: Context): TrackingStore = instance ?: synchronized(this) { instance ?: TrackingStore(context.applicationContext).also {instance=it} }
    fun fine(context: Context)=ContextCompat.checkSelfPermission(context,Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED
    fun background(context: Context)=ContextCompat.checkSelfPermission(context,Manifest.permission.ACCESS_BACKGROUND_LOCATION)==PackageManager.PERMISSION_GRANTED
    fun unrestricted(context: Context)=(context.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(context.packageName)
    fun gps(context: Context)=(context.getSystemService(Context.LOCATION_SERVICE) as LocationManager).isLocationEnabled
    fun validUrl(value: String): Boolean = try { val uri=URI(value);uri.host!=null&&uri.userInfo==null&&uri.query==null&&uri.fragment==null&&uri.path.endsWith("/api")&&(uri.scheme=="https"||(BuildConfig.DEBUG&&uri.scheme=="http"&&uri.host in listOf("localhost","127.0.0.1","10.0.2.2"))) } catch(_:Exception){false}
    @Synchronized fun configure(context: Context, value: JSONObject) {
        require(validUrl(value.getString("baseUrl"))) {"Secure workspace URL required"};require(value.getString("userId").isNotBlank());require(value.getString("trackingKey").length>=32);require(value.getString("mode") in listOf("Field","Office"));require(value.getLong("attendanceId")>0)
        val db=store(context);val old=db.config();val same=old.optString("userId")==value.getString("userId")&&old.optLong("attendanceId")==value.getLong("attendanceId")&&old.optString("mode")==value.getString("mode")
        value.put("anchorElapsed",SystemClock.elapsedRealtime());value.put("bootCount",Settings.Global.getInt(context.contentResolver,Settings.Global.BOOT_COUNT,-1));value.put("anchorUtc",Instant.parse(value.getString("serverTimeUtc")).toEpochMilli());db.saveConfig(value)
        if(!same)db.updateState {it.remove("stopCandidate");it.remove("stationary");it.remove("lastPoint");it.remove("lastFixAtUtc");it.remove("lastSyncAtUtc");it.put("rejectedCount",0);it.put("lastError","")}
        schedule(context)
        if(value.optBoolean("active")){start(context)}else{stop(context)}
    }
    @Synchronized fun start(context: Context) { val db=store(context);if(!db.config().optBoolean("active"))return;try{if(!fine(context))throw SecurityException();ContextCompat.startForegroundService(context,Intent(context,DutyLocationService::class.java))}catch(_:Exception){db.updateState {it.put("status","Permission or background start restricted");it.put("running",false)}} }
    @Synchronized fun stop(context: Context) {val db=store(context);val value=db.config();value.put("active",false);db.saveConfig(value);context.stopService(Intent(context,DutyLocationService::class.java));db.updateState {it.put("running",false);it.put("status","Duty tracking stopped")};schedule(context)}
    @Synchronized private fun stopIfCurrent(context:Context,db:TrackingStore,expected:JSONObject) {
        val latest=db.config()
        if(latest.optString("userId")==expected.optString("userId")&&latest.optLong("attendanceId")==expected.optLong("attendanceId")&&latest.optString("mode")==expected.optString("mode")&&latest.optString("trackingKey")==expected.optString("trackingKey")) {
            if(db===store(context))stop(context) else {latest.put("active",false);db.saveConfig(latest)}
        }
    }
    fun schedule(context: Context) { val manager=WorkManager.getInstance(context);val constraints=Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();manager.enqueueUniqueWork("trackyu-sync-now",ExistingWorkPolicy.KEEP,OneTimeWorkRequestBuilder<TrackingSyncWorker>().setConstraints(constraints).setBackoffCriteria(BackoffPolicy.EXPONENTIAL,30,TimeUnit.SECONDS).build());manager.enqueueUniquePeriodicWork("trackyu-sync-periodic",ExistingPeriodicWorkPolicy.KEEP,PeriodicWorkRequestBuilder<TrackingSyncWorker>(15,TimeUnit.MINUTES).setConstraints(constraints).build()) }
    private fun anchored(context:Context,cfg:JSONObject)=cfg.optLong("anchorUtc")>0&&cfg.optInt("bootCount",-1)==Settings.Global.getInt(context.contentResolver,Settings.Global.BOOT_COUNT,-2)
    private fun utcNow(context:Context,cfg:JSONObject)=if(anchored(context,cfg))cfg.getLong("anchorUtc")+SystemClock.elapsedRealtime()-cfg.getLong("anchorElapsed") else System.currentTimeMillis()
    @Synchronized private fun rememberServerTime(context:Context,db:TrackingStore,expected:JSONObject,time:String) {
        val latest=db.config()
        if(latest.optString("userId")==expected.optString("userId")&&latest.optString("trackingKey")==expected.optString("trackingKey")) {
            latest.put("anchorUtc",Instant.parse(time).toEpochMilli());latest.put("anchorElapsed",SystemClock.elapsedRealtime());latest.put("bootCount",Settings.Global.getInt(context.contentResolver,Settings.Global.BOOT_COUNT,-1));db.saveConfig(latest)
        }
    }
    fun status(context: Context, db: TrackingStore = store(context)): JSONObject {val cfg=db.config();return db.state().apply {put("clockAnchored",anchored(context,cfg));if(anchored(context,cfg))put("serverTimeUtc",Instant.ofEpochMilli(utcNow(context,cfg)).toString());put("userId",cfg.optString("userId"));put("mode",cfg.optString("mode"));put("attendanceId",cfg.optLong("attendanceId"));put("active",cfg.optBoolean("active"));put("expiresAtUtc",cfg.optString("expiresAtUtc"));put("pendingCount",db.pending(cfg.optString("userId")));put("gpsEnabled",gps(context));put("precisePermission",fine(context));put("backgroundPermission",background(context));put("batteryUnrestricted",unrestricted(context));put("baseUrl",cfg.optString("baseUrl"))} }
    fun sync(context: Context, db: TrackingStore = store(context)): Boolean {
        if(!syncing.compareAndSet(false,true))return true
        try {
            val cfg=db.config();val user=cfg.optString("userId");if(user.isBlank())return true
            db.prune(utcNow(context,cfg));val samples=db.batch(user);val state=status(context,db)
            val health=JSONObject().put("mode",cfg.getString("mode")).put("attendanceId",cfg.getLong("attendanceId")).put("trackingEnabled",state.optBoolean("running")).put("gpsEnabled",state.optBoolean("gpsEnabled")).put("precisePermission",state.optBoolean("precisePermission")).put("backgroundPermission",state.optBoolean("backgroundPermission")).put("batteryUnrestricted",state.optBoolean("batteryUnrestricted")).put("pendingCount",state.optInt("pendingCount")).put("rejectedCount",state.optInt("rejectedCount")).put("status",state.optString("status","Waiting for location").take(64))
            state.optString("lastFixAtUtc").takeIf {it.isNotBlank()}?.let {health.put("lastFixAtUtc",it)}
            val body=JSONObject().put("samples",JSONArray(samples)).put("health",health)
            val conn=URL(cfg.getString("baseUrl")+"/DutyTracking/upload").openConnection() as HttpURLConnection
            try {
                conn.requestMethod="POST";conn.connectTimeout=10000;conn.readTimeout=20000;conn.doOutput=true;conn.setRequestProperty("Content-Type","application/json");conn.setRequestProperty("X-Tracking-Key",cfg.getString("trackingKey"));conn.setRequestProperty("X-Device-ID",cfg.getString("deviceId"));conn.outputStream.use {it.write(body.toString().toByteArray(Charsets.UTF_8))}
                val code=conn.responseCode
                if(code!=200){
                    db.updateState {it.put("lastError",if(code==401)"Sign in to renew location syncing" else if(code==403)"This phone's tracking authorization was revoked" else "Upload pending; retrying automatically");it.put("status",if(code==401)"Sign-in required for sync" else "Locations saved on phone")}
                    if(code==403)stopIfCurrent(context,db,cfg)
                    return code==401||code==403
                }
                val envelope=JSONObject(conn.inputStream.bufferedReader().use {it.readText()});if(!envelope.optBoolean("success"))return false
                val data=envelope.getJSONObject("data");val acks=data.getJSONArray("acknowledgements");val sent=samples.map {it.getString("id")}.toSet();var rejected=0
                for(i in 0 until acks.length()){val ack=acks.getJSONObject(i);val id=ack.optString("id");val disposition=ack.optString("disposition");if(id in sent&&disposition in listOf("accepted","duplicate","rejected")){db.acknowledge(user,id,disposition=="rejected");if(disposition=="rejected")rejected++}}
                rememberServerTime(context,db,cfg,data.getString("serverTimeUtc"))
                db.updateState {it.put("lastSyncAtUtc",data.getString("serverTimeUtc"));it.put("lastError","");it.put("rejectedCount",it.optInt("rejectedCount")+rejected)}
                val window=data.optJSONObject("window");if(window!=null&&window.optLong("id")==cfg.optLong("attendanceId")&&window.optString("mode")==cfg.optString("mode")&&!window.isNull("punchOutUtc")){stopIfCurrent(context,db,cfg)}
                return db.pending(user)==0
            } finally {conn.disconnect()}
        } catch(_:Exception) {try{db.updateState {it.put("lastError","Connection unavailable; locations are saved on this phone")}}catch(_:Exception){};return false} finally {syncing.set(false)}
    }
    fun jsonMap(value: JSONObject): Map<String,Any?> = value.keys().asSequence().associateWith {k->when(val v=value.get(k)){JSONObject.NULL->null;is JSONObject->jsonMap(v);is JSONArray->(0 until v.length()).map {i->val item=v.get(i);if(item is JSONObject)jsonMap(item)else item};else->v}}
}
class TrackingSyncWorker(context: Context,params: WorkerParameters): Worker(context,params) {
 override fun doWork(): Result {
  val deadline=SystemClock.elapsedRealtime()+120000
  repeat(8){
   if(isStopped)return Result.retry()
   if(TrackingRuntime.sync(applicationContext))return Result.success()
   if(SystemClock.elapsedRealtime()>deadline)return Result.retry()
   try{if(TrackingRuntime.store(applicationContext).state().optString("lastError").isNotBlank())return Result.retry()}catch(_:Exception){return Result.retry()}
  }
  return Result.retry()
 }
}
